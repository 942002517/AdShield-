/* =============================================================
 * AdShield - 反广告拦截检测：控制器（隔离世界）
 *
 * 欺骗层本体跑在页面主世界（anti-detect-main.js），但它读不到 chrome.storage。
 * 这个脚本负责把"用户有没有开这个功能"翻译成一个 document 事件推过去，
 * 并在设置变化时实时同步，不用刷新页面。
 * ============================================================= */
(function () {
  'use strict';

  if (self.__adShieldAntiDetectCtl) return;
  self.__adShieldAntiDetectCtl = true;

  var S = self.AdShieldStorage;
  if (!S) return;

  var EVENT = 'adshield-anti-detect';
  var applied = null;

  /**
   * 用事件而不是 DOM 属性传状态：主世界与隔离世界共享同一个 document，
   * 事件是两者之间最干净的一条通道，也不会在页面上留下可被探测的痕迹。
   */
  function push(on) {
    on = !!on;
    if (applied === on) return;
    applied = on;
    try {
      document.dispatchEvent(new CustomEvent(EVENT, { detail: on ? '1' : '0' }));
    } catch (e) { /* 早期文档状态下可能失败，主世界默认就是开启，无碍 */ }
  }

  // 主世界脚本的默认状态是"启用"，所以这里读到设置后必须主动推一次，
  // 把用户真正关掉功能的意图传达过去。
  S.getSettings().then(function (st) {
    push(st.antiDetect !== false);
  }).catch(function () {
    push(true);
  });

  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== 'local' || !changes.settings) return;
      var nv = changes.settings.newValue || {};
      push(nv.antiDetect !== false);
    });
  } catch (e) { /* ignore */ }
})();
