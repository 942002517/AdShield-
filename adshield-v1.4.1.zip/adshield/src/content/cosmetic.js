/* =============================================================
 * AdShield - 内容脚本
 * 1) 元素隐藏（外观过滤）：把规则编译成 CSS 一次性注入，动态内容自动生效
 * 2) 点选屏蔽：交互式选择页面元素并生成屏蔽规则
 * ============================================================= */
(function () {
  'use strict';

  if (window.__adShieldLoaded) return;
  window.__adShieldLoaded = true;

  var S = self.AdShieldStorage;
  if (!S) return;

  var IS_TOP = window === window.top;
  var STYLE_ID = '__adshield_style__';
  var picked = [];

  /* ---------------- 工具 ---------------- */

  function suffixes(host) {
    var out = [];
    var parts = host.split('.');
    for (var i = 0; i < parts.length - 1; i++) {
      out.push(parts.slice(i).join('.'));
    }
    return out;
  }

  function buildCss(selectors) {
    if (!selectors.length) return '';
    var out = [];
    for (var i = 0; i < selectors.length; i++) {
      var s = selectors[i];
      if (!s) continue;
      out.push(s + '{display:none!important}');
    }
    return out.join('\n');
  }

  function injectStyle(css) {
    if (!css) return null;
    var style = document.getElementById(STYLE_ID);
    if (!style) {
      style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = css;
      var root = document.head || document.documentElement;
      if (!root) return null;
      root.appendChild(style);
    } else {
      style.textContent = css;
    }
    return style;
  }

  function countMatches(selectors, root) {
    if (!selectors.length || !root) return 0;
    var joined = selectors.join(',');
    if (joined.length > 80000) return 0;   // 太长不计数，避免阻塞渲染
    try { return root.querySelectorAll(joined).length; } catch (e) { return 0; }
  }

  function reportHidden(count) {
    if (!count) return;
    try {
      chrome.runtime.sendMessage({ type: 'reportHidden', count: count, host: location.hostname });
    } catch (e) { /* ignore */ }
  }

  function isWhitelisted(host, list) {
    if (!host || !list || !list.length) return false;
    for (var i = 0; i < list.length; i++) {
      var d = list[i];
      if (host === d || host.endsWith('.' + d)) return true;
    }
    return false;
  }

  /* ---------------- 主流程 ---------------- */

  async function collectSelectors() {
    var host = location.hostname;
    var res = await S.get([S.KEYS.COSMETIC_GENERIC, S.KEYS.COSMETIC_INDEX]);
    var index = res[S.KEYS.COSMETIC_INDEX] || [];
    var generic = res[S.KEYS.COSMETIC_GENERIC] || [];

    var indexSet = Object.create(null);
    index.forEach(function (d) { indexSet[d] = true; });

    var hosts = suffixes(host);
    var domainKeys = [];
    var noGeneric = false;
    hosts.forEach(function (h) {
      if (indexSet[h]) domainKeys.push(h);
    });

    var domainSpecific = [];
    var domainExceptions = [];
    var domainText = [];
    if (domainKeys.length) {
      var keys = domainKeys.map(function (h) { return S.KEYS.COSMETIC_DOMAIN + h; });
      var data = await S.get(keys);
      domainKeys.forEach(function (h) {
        var b = data[S.KEYS.COSMETIC_DOMAIN + h];
        if (!b) return;
        if (b.ng) noGeneric = true;
        (b.s || []).forEach(function (s) { domainSpecific.push(s); });
        (b.e || []).forEach(function (s) { domainExceptions.push(s); });
        (b.t || []).forEach(function (p) { domainText.push(p); });
      });
    }

    return {
      host: host,
      generic: generic,
      specific: domainSpecific,
      exceptions: domainExceptions,
      text: domainText,
      noGeneric: noGeneric
    };
  }

  function composeSelectors(ctx, settings) {
    var out = [];
    var textRules = [];
    var seen = Object.create(null);
    var seenText = Object.create(null);

    function push(sel) {
      if (!sel || seen[sel]) return;
      seen[sel] = 1;
      out.push(sel);
    }

    function pushText(rule) {
      var key = rule.sel + '|' + rule.src + '|' + (rule.flags || '');
      if (seenText[key]) return;
      seenText[key] = 1;
      textRules.push(rule);
    }

    // 顺序：站点专属 -> 用户自定义 -> 内置通用 -> 订阅通用
    // （前面的更可能与当前页面相关，统计计数时优先纳入）
    for (var k = 0; k < ctx.specific.length; k++) push(ctx.specific[k]);
    for (var x = 0; x < ctx.text.length; x++) pushText(ctx.text[x]);

    var custom = settings.customCosmetic || {};
    (custom['*'] || []).forEach(push);
    var hosts = suffixes(ctx.host);
    hosts.forEach(function (h) {
      (custom[h] || []).forEach(push);
    });

    if (settings.genericCosmetic && !ctx.noGeneric) {
      var defaults = (self.AdShieldDefaultCosmetic && self.AdShieldDefaultCosmetic.SELECTORS) || [];
      for (var i = 0; i < defaults.length; i++) push(defaults[i]);
      for (var j = 0; j < ctx.generic.length; j++) {
        var g = ctx.generic[j];
        if (g.x && g.x.length && isWhitelisted(ctx.host, g.x)) continue;
        if (g.t && g.t.length) {
          // 带文本条件的规则不能进 CSS，否则会无视条件误伤
          for (var m = 0; m < g.t.length; m++) {
            pushText({ sel: g.s, src: g.t[m].src, flags: g.t[m].flags });
          }
          continue;
        }
        push(g.s);
      }
    }

    // 例外规则：同时作用于 CSS 选择器与文本规则的基础选择器
    var exSet = Object.create(null);
    ctx.exceptions.forEach(function (s) { exSet[s] = true; });
    out = out.filter(function (s) { return !exSet[s]; });
    textRules = textRules.filter(function (r) { return !exSet[r.sel]; });

    return { selectors: out, textRules: textRules };
  }

  /* ---------------- 文本正则规则求值 ---------------- */

  var textState = { rules: [], observer: null, timer: null, hidden: 0 };

  function compileTextRules(list) {
    var out = [];
    list.forEach(function (r) {
      if (!r || !r.sel || !r.src) return;
      var flags = (r.flags || '').replace(/g/g, '');   // 去掉 g，避免 lastIndex 状态
      try {
        out.push({ sel: r.sel, src: r.src, re: new RegExp(r.src, flags) });
      } catch (e) { /* 非法正则直接跳过，不影响页面 */ }
    });
    return out;
  }

  /** 对每个元素取用于匹配的文本，超长截断以控制代价 */
  var TEXT_SAMPLE_LIMIT = 4000;
  var NODE_SCAN_LIMIT = 3000;

  function textOf(el) {
    var t = el.textContent || '';
    if (t.length > TEXT_SAMPLE_LIMIT) t = t.slice(0, TEXT_SAMPLE_LIMIT);
    return t;
  }

  function runTextRules() {
    if (!textState.rules.length) return 0;
    var hits = 0;
    for (var i = 0; i < textState.rules.length; i++) {
      var rule = textState.rules[i];
      var nodes;
      try { nodes = document.querySelectorAll(rule.sel); } catch (e) { continue; }
      var limit = Math.min(nodes.length, NODE_SCAN_LIMIT);
      for (var j = 0; j < limit; j++) {
        var el = nodes[j];
        if (el.__adshieldTextHidden) continue;
        if (rule.re.test(textOf(el))) {
          el.style.setProperty('display', 'none', 'important');
          el.__adshieldTextHidden = 1;
          hits++;
        }
      }
    }
    return hits;
  }

  function scheduleTextScan() {
    if (textState.timer) return;
    textState.timer = setTimeout(function () {
      textState.timer = null;
      var n = runTextRules();
      if (n) { textState.hidden += n; reportHidden(n); }
    }, 260);
  }

  function watchTextRules() {
    if (!textState.rules.length || textState.observer) return;
    try {
      textState.observer = new MutationObserver(function (records) {
        for (var i = 0; i < records.length; i++) {
          if (records[i].addedNodes && records[i].addedNodes.length) { scheduleTextScan(); return; }
        }
      });
      textState.observer.observe(document.documentElement, { childList: true, subtree: true });
    } catch (e) { /* ignore */ }
  }

  function applyTextRules(list) {
    if (textState.observer) { textState.observer.disconnect(); textState.observer = null; }
    textState.rules = compileTextRules(list);
    if (!textState.rules.length) return;

    var first = function () {
      var n = runTextRules();
      if (n) { textState.hidden += n; reportHidden(n); }
      watchTextRules();
    };
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      setTimeout(first, 260);
    } else {
      window.addEventListener('DOMContentLoaded', function () { setTimeout(first, 300); }, { once: true });
    }
  }

  async function apply() {
    var settings = await withSettings(true);
    if (!settings.enabled || !settings.cosmeticEnabled) {
      var old = document.getElementById(STYLE_ID);
      if (old) old.remove();
      if (textState.observer) { textState.observer.disconnect(); textState.observer = null; }
      textState.rules = [];
      return;
    }
    if (isWhitelisted(location.hostname, settings.whitelist)) return;

    var ctx = await collectSelectors();
    var composed = composeSelectors(ctx, settings);
    var selectors = composed.selectors;
    picked = selectors.slice();

    var css = buildCss(selectors);
    if (css) injectStyle(css);

    applyTextRules(settings.textRulesEnabled !== false ? composed.textRules : []);

    // 延迟统计（等页面渲染后再数，避免 document_start 时全是 0）
    // 选择器过多时只统计前 1500 条，避免 querySelectorAll 阻塞渲染
    var measureList = selectors.length > 1500 ? selectors.slice(0, 1500) : selectors;
    var measure = function () {
      var n = countMatches(measureList, document.documentElement);
      reportHidden(n);
    };
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      setTimeout(measure, 300);
    } else {
      window.addEventListener('DOMContentLoaded', function () { setTimeout(measure, 400); }, { once: true });
    }
  }

  /* ---------------- 点选屏蔽 ---------------- */

  function looksDynamic(cls) {
    if (cls.length > 28) return true;
    if (/^\d/.test(cls)) return true;
    if (/^[a-f0-9]{8,}$/i.test(cls)) return true;
    if (/^(css|jsx|sc|styled)-[a-z0-9]{5,}$/i.test(cls)) return true;
    if (/[A-Za-z]{0,3}\d{4,}/.test(cls)) return true;
    return false;
  }

  function escapeSel(s) {
    if (window.CSS && CSS.escape) return CSS.escape(s);
    return s.replace(/([^\w-])/g, '\\$1');
  }

  function cssPath(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el === document.documentElement || el === document.body) return '';

    var id = el.getAttribute && el.getAttribute('id');
    if (id && /^[A-Za-z][\w\-]*$/.test(id)) {
      var idSel = '#' + escapeSel(id);
      try { if (document.querySelectorAll(idSel).length === 1) return idSel; } catch (e) { /* ignore */ }
    }

    var parts = [];
    var node = el;
    var depth = 0;
    while (node && node.nodeType === 1 && depth < 6) {
      var tag = node.tagName.toLowerCase();
      if (tag === 'html' || tag === 'body') { parts.unshift(tag); break; }

      var seg = tag;
      var cls = [];
      if (typeof node.className === 'string' && node.className.trim()) {
        cls = node.className.trim().split(/\s+/).filter(function (c) {
          return c && !looksDynamic(c);
        }).slice(0, 2);
      }
      if (cls.length) {
        seg += '.' + cls.map(escapeSel).join('.');
      } else if (node.parentElement) {
        var idx = Array.prototype.indexOf.call(node.parentElement.children, node) + 1;
        seg += ':nth-child(' + idx + ')';
      }
      parts.unshift(seg);

      var candidate = parts.join(' > ');
      try {
        if (document.querySelectorAll(candidate).length === 1) return candidate;
      } catch (e) { /* ignore */ }

      node = node.parentElement;
      depth++;
    }
    var finalSel = parts.join(' > ');
    if (finalSel.length > 300) finalSel = finalSel.slice(-300).replace(/^[^>]*>/, '');
    return finalSel;
  }

  var picker = null;

  /* ---------------- 设置缓存（点选器需要主题色） ---------------- */

  var settingsCache = null;

  async function withSettings(force) {
    if (settingsCache && !force) return settingsCache;
    try {
      settingsCache = await S.getSettings();
    } catch (e) {
      settingsCache = settingsCache || {};
    }
    return settingsCache;
  }

  /** 点选器要用的颜色，取自用户当前主题；引擎缺失时用一套中性兜底 */
  function pickerPalette() {
    var TH = (typeof self !== 'undefined' ? self : globalThis).AdShieldTheme;
    var fallback = {
      hiBorder: '#ff3b30', hiFill: 'rgba(255,59,48,.14)',
      barBg: '#111827', barInk: '#ffffff',
      btnPrimary: '#2e68f9', btnInk: '#ffffff', btnGhost: '#374151', radius: 10
    };
    if (!TH) return fallback;
    try {
      return TH.pickOverlayTokens(TH.resolve(settingsCache ? settingsCache.theme : null));
    } catch (e) {
      return fallback;
    }
  }

  function highlightBox() {
    var pal = pickerPalette();
    var box = document.createElement('div');
    box.setAttribute('data-adshield-picker', 'box');
    box.style.cssText = [
      'position:fixed', 'z-index:2147483646', 'pointer-events:none',
      'border:2px solid ' + pal.hiBorder,
      'background:' + pal.hiFill,
      'border-radius:' + Math.min(6, pal.radius) + 'px',
      'transition:all .05s linear', 'display:none'
    ].join(';');
    return box;
  }

  function tipBar(text, actions) {
    var pal = pickerPalette();
    var bar = document.createElement('div');
    bar.setAttribute('data-adshield-picker', 'tip');
    bar.style.cssText = [
      'position:fixed', 'left:50%', 'top:14px', 'transform:translateX(-50%)',
      'z-index:2147483647', 'background:' + pal.barBg, 'color:' + pal.barInk,
      'font:13px/1.6 -apple-system,"Segoe UI",Roboto,"Microsoft YaHei",sans-serif',
      'padding:10px 14px', 'border-radius:' + Math.max(6, pal.radius) + 'px',
      'box-shadow:0 8px 28px rgba(0,0,0,.35)',
      'display:flex', 'align-items:center', 'gap:10px', 'pointer-events:auto',
      'max-width:86vw'
    ].join(';');
    var span = document.createElement('span');
    span.textContent = text;
    bar.appendChild(span);
    (actions || []).forEach(function (a) {
      var btn = document.createElement('button');
      btn.textContent = a.label;
      btn.style.cssText = [
        'all:unset', 'cursor:pointer', 'padding:4px 10px',
        'border-radius:' + Math.max(4, pal.radius - 4) + 'px',
        'font-size:12px',
        'background:' + (a.primary ? pal.btnPrimary : pal.btnGhost),
        'color:' + (a.primary ? pal.btnInk : pal.barInk)
      ].join(';');
      btn.addEventListener('click', function (ev) {
        ev.stopPropagation();
        ev.preventDefault();
        a.onClick();
      }, true);
      bar.appendChild(btn);
    });
    return bar;
  }

  function cleanupPicker() {
    if (!picker) return;
    if (picker.toastTimer) clearTimeout(picker.toastTimer);
    document.removeEventListener('mouseover', picker.onOver, true);
    document.removeEventListener('click', picker.onClick, true);
    document.removeEventListener('scroll', picker.onScroll, true);
    document.removeEventListener('keydown', picker.onKey, true);
    if (picker.box && picker.box.parentNode) picker.box.parentNode.removeChild(picker.box);
    if (picker.tip && picker.tip.parentNode) picker.tip.parentNode.removeChild(picker.tip);
    if (picker.toast && picker.toast.parentNode) picker.toast.parentNode.removeChild(picker.toast);
    picker = null;
  }

  function showToast(text, onUndo) {
    if (!picker) return;
    if (picker.toast && picker.toast.parentNode) picker.toast.parentNode.removeChild(picker.toast);
    var actions = [];
    if (onUndo) actions.push({ label: '撤销', onClick: function () { onUndo(); showToast('已撤销屏蔽'); } });
    actions.push({ label: '退出', primary: true, onClick: function () { cleanupPicker(); } });
    var toast = tipBar(text, actions);
    picker.toast = toast;
    document.documentElement.appendChild(toast);
    picker.toastTimer = setTimeout(function () {
      if (picker && picker.toast === toast && toast.parentNode) {
        toast.parentNode.removeChild(toast);
        picker.toast = null;
      }
    }, 5000);
  }

  function localHide(selector) {
    try {
      var style = document.getElementById(STYLE_ID);
      if (!style) style = injectStyle('/* adshield picker */');
      if (style) style.textContent = style.textContent + '\n' + selector + '{display:none!important}';
    } catch (e) { /* ignore */ }
  }

  function localUnhide(selector) {
    try {
      var st = document.getElementById(STYLE_ID);
      if (!st) return;
      st.textContent = st.textContent.split('\n').filter(function (line) {
        return line.indexOf(selector + '{display:none') === -1;
      }).join('\n');
    } catch (e) { /* ignore */ }
  }

  function onPick(target) {
    var selector = cssPath(target);
    if (!selector) { showToast('无法为该元素生成规则，请换个位置试试'); return; }
    picker.box.style.display = 'none';
    localHide(selector);

    var host = location.hostname;
    chrome.runtime.sendMessage({ type: 'savePickedElement', host: host, selector: selector }, function (resp) {
      void chrome.runtime.lastError;
      if (resp && resp.ok) {
        showToast('已屏蔽：' + selector, function () {
          localUnhide(selector);
          chrome.runtime.sendMessage({ type: 'undoPickedElement', host: host, selector: selector }, function () {
            void chrome.runtime.lastError;
          });
        });
      } else {
        showToast('保存失败：' + ((resp && resp.error) || '后台未响应'));
      }
    });
  }

  function startPicker() {
    if (!IS_TOP) return { ok: false, error: '请在最外层页面使用' };
    if (picker) return { ok: true, already: true };

    var box = highlightBox();
    document.documentElement.appendChild(box);
    picker = { box: box, tip: null, toast: null, toastTimer: null };

    picker.onOver = function (e) {
      var t = e.target;
      if (!t || t.nodeType !== 1) return;
      if (t.hasAttribute && t.hasAttribute('data-adshield-picker')) return;
      var r = t.getBoundingClientRect();
      box.style.display = 'block';
      box.style.left = Math.max(0, r.left) + 'px';
      box.style.top = Math.max(0, r.top) + 'px';
      box.style.width = Math.max(0, r.width) + 'px';
      box.style.height = Math.max(0, r.height) + 'px';
    };

    picker.onScroll = function () { box.style.display = 'none'; };

    picker.onClick = function (e) {
      var t = e.target;
      if (t && t.closest && t.closest('[data-adshield-picker]')) return;
      e.preventDefault();
      e.stopPropagation();
      if (!picker || !t || t.nodeType !== 1) return;
      if (t === document.documentElement || t === document.body) {
        showToast('请选择页面中的具体元素');
        return;
      }
      onPick(t);
    };

    picker.onKey = function (e) {
      if (e.key === 'Escape') cleanupPicker();
    };

    picker.tip = tipBar('点选要屏蔽的元素，Esc 退出', [
      { label: '退出', onClick: function () { cleanupPicker(); } }
    ]);
    document.documentElement.appendChild(picker.tip);

    document.addEventListener('mouseover', picker.onOver, true);
    document.addEventListener('click', picker.onClick, true);
    document.addEventListener('scroll', picker.onScroll, true);
    document.addEventListener('keydown', picker.onKey, true);

    return { ok: true };
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg) return;
    if (msg.type === 'startPicker') {
      // 先确保拿到设置（点选器要按用户主题上色），再启动
      withSettings().then(function () {
        try { sendResponse(startPicker()); } catch (e) { sendResponse({ ok: false, error: String(e) }); }
      });
      return true;   // 异步返回
    }
    if (msg.type === 'refreshCosmetic') {
      apply();
      sendResponse({ ok: true });
      return false;
    }
  });

  /* ---------------- 启动 ---------------- */
  apply().catch(function () { /* 静默失败，不影响页面 */ });
})();
