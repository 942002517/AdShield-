/* =============================================================
 * AdShield - 直播内容推荐屏蔽（内容脚本）
 *
 * 做法：找到指向直播域的链接 → 定位承载它的卡片 → 给卡片打上
 * `data-adshield-live` 属性 → 由一条 CSS 规则隐藏。
 *
 * 走"打属性 + CSS"而不是直接改 style.display，有两个好处：
 *   · 关掉功能时只要移除属性，页面立刻复原，不留残迹
 *   · 动态插入的内容由 MutationObserver 接管，不用逐个去改内联样式
 *
 * 刻意不碰的东西：导航栏/页眉/侧栏里的「直播」入口。那里命中直播链接
 * 是必然的，但隐藏它等于把站点功能砍掉一块，不是净化而是残缺。
 *
 * 本脚本只在 rule 库声明支持的站点上工作，其余站点直接不注册。
 * ============================================================= */
(function () {
  'use strict';

  if (self.__adShieldLiveLoaded) return;
  self.__adShieldLiveLoaded = true;

  var S = self.AdShieldStorage;
  var RULES = self.AdShieldLiveRules;
  if (!S || !RULES) return;

  var MARK = 'data-adshield-live';
  var STYLE_ID = '__adshield_live_style__';
  var SCAN_DELAY = 300;      // 动态内容合并到一次扫描，避免频繁全表遍历
  var EARLY_DELAY = 40;      // 解析期间用短防抖，别让首屏的直播卡片先露脸
  var MAX_DEPTH = 12;

  var site = null;
  var active = false;
  var observer = null;
  var scanTimer = null;

  /* ---------------- 基础工具 ---------------- */

  function classOf(el) {
    try {
      var c = el.className;
      if (typeof c === 'string') return c;
      if (c && typeof c.baseVal === 'string') return c.baseVal;      // SVG
    } catch (e) { /* ignore */ }
    var attr = el.getAttribute && el.getAttribute('class');
    return attr || '';
  }

  // 卡片级容器常见的命名片段
  var CARD_WORDS = Object.create(null);
  ('card cards item items cell entry module tile post feed videocard ' +
   'wrap wrapper box unit panel').split(' ')
    .forEach(function (w) { CARD_WORDS[w] = 1; });

  function looksLikeCard(el) {
    var cls = classOf(el);
    if (!cls) return false;
    var toks = cls.toLowerCase().split(/[^a-z0-9]+/);
    for (var i = 0; i < toks.length; i++) {
      if (toks[i] && CARD_WORDS[toks[i]]) return true;
    }
    return false;
  }

  // 站点骨架：页眉、导航、侧栏、页脚。命中的链接一律不动。
  var CHROME_RE = new RegExp(
    '(^|[-_\\s])(header|navbar|navigation|nav|topbar|top-bar|menu|sidebar|' +
    'aside|breadcrumb|footer|toolbar)([-_\\s]|$)', 'i');

  function inChrome(el) {
    var d = 0;
    while (el && el.nodeType === 1 && d < 16) {
      var tag = el.tagName;
      if (tag === 'HEADER' || tag === 'NAV' || tag === 'FOOTER' || tag === 'ASIDE') return true;
      if (el.getAttribute) {
        var role = el.getAttribute('role');
        if (role === 'navigation' || role === 'banner' || role === 'contentinfo') return true;
      }
      var cls = classOf(el);
      if (cls && CHROME_RE.test(cls)) return true;
      if (el === document.body || el === document.documentElement) return false;
      el = el.parentElement;
      d++;
    }
    return false;
  }

  /* ---------------- 站点与链接判定 ---------------- */

  function siteFor(host) {
    var parts = (host || '').split('.');
    for (var i = 0; i < parts.length - 1; i++) {
      var suffix = parts.slice(i).join('.');
      for (var j = 0; j < RULES.SITES.length; j++) {
        if (RULES.SITES[j].hosts.indexOf(suffix) !== -1) return RULES.SITES[j];
      }
    }
    return null;
  }

  function isLiveUrl(url, s) {
    if (!url || !s) return false;
    var hosts = s.liveHosts || [];
    for (var i = 0; i < hosts.length; i++) {
      if (url.indexOf(hosts[i]) !== -1) return true;
    }
    if (s.liveRe && s.liveRe.test(url)) return true;
    return false;
  }

  function isWhitelisted(host, list) {
    if (!host || !list || !list.length) return false;
    for (var i = 0; i < list.length; i++) {
      var d = list[i];
      if (host === d || host.endsWith('.' + d)) return true;
    }
    return false;
  }

  /* ---------------- 定位卡片 ---------------- */

  function cardCeiling() {
    var vh = window.innerHeight || 800;
    return Math.max(360, Math.min(Math.round(vh * 0.85), 1000));
  }

  /**
   * 从直播链接向上找承载它的卡片。
   *
   * 沿"连续匹配卡片命名"的祖先一路向上收，收到最后一个为止：这样拿到的是
   * 完整卡片外壳（如 bili-video-card），而不是卡片内部的小包装
   * （如 bili-video-card__wrap）——只藏内层会留下一块空白占位。
   *
   * 一旦某层高度超过卡片尺度，说明已经爬到列表或主容器，立即收手；
   * 全程没找到合适容器就返回 null，宁可不藏也不误伤。
   */
  function findCard(link) {
    var ceiling = cardCeiling();
    var el = link.parentElement;
    var best = null;
    var depth = 0;

    while (el && el.nodeType === 1 && el !== document.body && depth < MAX_DEPTH) {
      var h = el.offsetHeight || 0;
      if (h > ceiling) break;
      if (looksLikeCard(el)) best = el;
      else if (best) break;
      el = el.parentElement;
      depth++;
    }
    return best;
  }

  /* ---------------- 标记与样式 ---------------- */

  function markVisible() {
    var links;
    try { links = document.querySelectorAll('a[href]'); } catch (e) { return 0; }

    var added = 0;
    for (var i = 0; i < links.length; i++) {
      var a = links[i];
      if (!isLiveUrl(a.href || '', site)) continue;
      if (a.closest('[' + MARK + ']')) continue;      // 已经落在被隐藏的卡片里
      if (inChrome(a)) continue;                      // 导航入口不动
      var card = findCard(a);
      if (!card) continue;
      card.setAttribute(MARK, '1');
      added++;
    }
    return added;
  }

  function clearMarks() {
    var marked;
    try { marked = document.querySelectorAll('[' + MARK + ']'); } catch (e) { return; }
    for (var i = marked.length - 1; i >= 0; i--) marked[i].removeAttribute(MARK);
  }

  function injectStyle() {
    var css = '[' + MARK + ']{display:none!important}';
    var fixed = (site && site.fixed) || [];
    if (fixed.length) css += '\n' + fixed.join(',') + '{display:none!important}';

    var el = document.getElementById(STYLE_ID);
    if (!el) {
      el = document.createElement('style');
      el.id = STYLE_ID;
      var root = document.head || document.documentElement;
      if (!root) return;
      root.appendChild(el);
    }
    el.textContent = css;
  }

  function removeStyle() {
    var el = document.getElementById(STYLE_ID);
    if (el && el.parentNode) el.parentNode.removeChild(el);
  }

  /* ---------------- 启停 ---------------- */

  function onMutation(records) {
    if (!active) return;
    for (var i = 0; i < records.length; i++) {
      var added = records[i].addedNodes;
      for (var j = 0; j < added.length; j++) {
        var node = added[j];
        if (node.nodeType !== 1) continue;
        if (node.tagName === 'A' || (node.querySelector && node.querySelector('a[href]'))) {
          scheduleScan();
          return;
        }
      }
    }
  }

  function scheduleScan() {
    if (scanTimer) return;
    // 解析还没结束时用短防抖：此刻 DOM 正在被逐段插入，等 300ms 才扫的话，
    // 首屏那批直播卡片已经画出来了，"别让它出现"就退化成了"出现后再抹掉"。
    // 解析完成后拉长防抖，免得在瀑布流站点上反复全表遍历。
    var delay = document.readyState === 'loading' ? EARLY_DELAY : SCAN_DELAY;
    scanTimer = setTimeout(function () {
      scanTimer = null;
      rescan();
    }, delay);
  }

  // 立即补扫一次（只在功能开启时有效）
  function rescan() {
    if (!active) return;
    markVisible();
    injectStyle();          // 页面可能换了 <head>，确保样式仍在
  }

  function start() {
    if (active || !site) return;
    var root = document.documentElement;
    if (!root) {
      document.addEventListener('DOMContentLoaded', start, { once: true });
      return;
    }
    active = true;
    injectStyle();
    markVisible();
    if (typeof MutationObserver === 'function') {
      observer = new MutationObserver(onMutation);
      observer.observe(root, { childList: true, subtree: true });
    }
    // 本脚本在 document_start 注入，上面那次 markVisible 基本扫不到东西
    // （<body> 还没开始解析）。解析一结束补一次，兜住 MutationObserver 的
    // 防抖窗口；load 再兜一次，因为有些站点的首屏是脚本注入的。
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', rescan, { once: true });
      window.addEventListener('load', rescan, { once: true });
    }
  }

  function stop() {
    if (!active) return;
    active = false;
    if (observer) { observer.disconnect(); observer = null; }
    if (scanTimer) { clearTimeout(scanTimer); scanTimer = null; }
    clearMarks();
    removeStyle();
  }

  function sync() {
    return S.getSettings().then(function (st) {
      var on = st.enabled !== false &&
               st.hideLive === true &&
               !isWhitelisted(location.hostname, st.whitelist);
      if (on) start(); else stop();
    }).catch(function () { /* ignore */ });
  }

  /* ---------------- 入口 ---------------- */

  // 测试页在普通页面里跑，hostname 匹配不上任何真实站点，所以留一个显式的
  // 站点注入点。内容脚本运行在隔离世界，页面自己的 JS 读不到也改不了这个
  // 变量，因此它不构成可被站点利用的开关。
  site = self.__adShieldLiveForceSite || siteFor(location.hostname);
  if (!site) return;                 // 不在支持列表里，什么都不做

  sync();

  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== 'local' || !changes.settings) return;
      sync();                        // 切换开关立刻生效，不必刷新页面
    });
  } catch (e) { /* ignore */ }

  // 供测试页与排查使用
  self.__adShieldLive = {
    site: site,
    mark: markVisible,
    rescan: rescan,
    findCard: findCard,
    isLiveUrl: isLiveUrl,
    inChrome: inChrome,
    looksLikeCard: looksLikeCard,
    start: start,
    stop: stop,
    get active() { return active; },
    get hidden() {
      try { return document.querySelectorAll('[' + MARK + ']').length; }
      catch (e) { return 0; }
    }
  };
})();
