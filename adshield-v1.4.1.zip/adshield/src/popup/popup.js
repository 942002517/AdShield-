/* AdShield - 弹窗逻辑 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };

  function send(type, extra) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(Object.assign({ type: type }, extra || {}), function (resp) {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (!resp) { reject(new Error('后台无响应')); return; }
        if (resp.ok === false) { reject(new Error(resp.error || '执行失败')); return; }
        resolve(resp.data);
      });
    });
  }

  function fmt(n) {
    if (n === undefined || n === null) return '0';
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 10000) return (n / 1000).toFixed(1) + 'k';
    return String(n);
  }

  function fmtTime(ts) {
    if (!ts) return '尚未编译';
    var d = new Date(ts);
    var now = Date.now();
    var diff = now - ts;
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return Math.floor(diff / 60000) + ' 分钟前';
    if (diff < 86400000) return Math.floor(diff / 3600000) + ' 小时前';
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0') + ' ' +
      String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  }

  var hintTimer = null;
  function hint(text, kind) {
    var box = $('hintBox');
    box.textContent = text;
    box.className = 'hint' + (kind ? ' ' + kind : '');
    box.hidden = false;
    if (hintTimer) clearTimeout(hintTimer);
    hintTimer = setTimeout(function () { box.hidden = true; }, 4000);
  }

  var state = null;

  // 当前站点是否在内置的直播屏蔽支持列表里
  function liveSiteFor(host) {
    var LR = self.AdShieldLiveRules;
    if (!LR || !host) return null;
    var parts = host.split('.');
    for (var i = 0; i < parts.length - 1; i++) {
      var suffix = parts.slice(i).join('.');
      for (var j = 0; j < LR.SITES.length; j++) {
        if (LR.SITES[j].hosts.indexOf(suffix) !== -1) return LR.SITES[j];
      }
    }
    return null;
  }

  function render() {
    if (!state) return;
    var s = state.settings;
    var tab = state.tab;
    var info = state.info;

    $('masterSwitch').checked = !!s.enabled;
    $('siteHost').textContent = tab.host || '当前不是普通网页';

    $('statBlocked').textContent = fmt(tab.blocked);
    $('statHidden').textContent = fmt(tab.hidden);
    $('statTotal').textContent = fmt((state.totals && state.totals.blocked || 0));

    var whitelisted = !!tab.whitelisted;
    var btnWhite = $('btnWhite');
    btnWhite.textContent = whitelisted ? '已加入白名单' : '本站白名单';
    btnWhite.classList.toggle('on', whitelisted);
    btnWhite.disabled = !tab.host;

    $('btnPick').disabled = !tab.host || !s.enabled;

    var btnLive = $('btnLive');
    var liveOn = s.hideLive === true;
    var liveSite = liveSiteFor(tab.host);
    btnLive.textContent = liveOn ? '已屏蔽直播推荐' : '屏蔽直播推荐';
    btnLive.classList.toggle('on', liveOn);
    btnLive.disabled = !s.enabled;
    btnLive.title = liveSite
      ? ('当前站点已支持：' + liveSite.name)
      : '当前站点不在内置支持列表内；开启后对已支持的视频站生效';

    $('metaRules').textContent = info
      ? (fmt(info.dynamicRules) + (info.network && info.network.truncated ? ' (已取舍)' : ''))
      : '-';
    var enabledLists = (state.lists || []).filter(function (l) { return l.enabled; });
    $('metaLists').textContent = enabledLists.length + ' 个';
    $('metaCosmetic').textContent = info && info.cosmetic
      ? fmt(info.cosmetic.generic) + ' 通用 / ' + fmt(info.cosmetic.specific) + ' 专属'
      : '-';
    $('metaUpdated').textContent = info ? fmtTime(info.at) : '尚未编译';

    ['btnPick', 'btnWhite', 'btnLive'].forEach(function (id) {
      $(id).style.opacity = $(id).disabled ? .5 : 1;
      $(id).style.cursor = $(id).disabled ? 'not-allowed' : 'pointer';
    });
  }

  function refresh() {
    return send('getState').then(function (data) {
      state = data;
      render();
    }).catch(function (err) {
      hint('读取状态失败：' + err.message, 'err');
    });
  }

  /* ---------- 事件 ---------- */

  $('masterSwitch').addEventListener('change', function (e) {
    var on = e.target.checked;
    send('updateSettings', { patch: { enabled: on } }).then(function () {
      hint(on ? '防护已开启' : '防护已暂停', on ? '' : 'warn');
      refresh();
    }).catch(function (err) { hint(err.message, 'err'); });
  });

  $('btnPick').addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      void chrome.runtime.lastError;
      var tab = tabs && tabs[0];
      if (!tab) { hint('找不到当前标签页', 'err'); return; }
      chrome.tabs.sendMessage(tab.id, { type: 'startPicker' }, function (resp) {
        if (chrome.runtime.lastError) {
          // 内容脚本可能尚未注入（页面在扩展安装前打开），后台会兜底注入
          send('startPicker').then(function () {
            window.close();
          }).catch(function (err) { hint('启动失败：' + err.message, 'err'); });
          return;
        }
        if (resp && resp.ok) window.close();
        else hint((resp && resp.error) || '启动失败', 'err');
      });
    });
  });

  $('btnWhite').addEventListener('click', function () {
    send('toggleWhitelistCurrent').then(function (res) {
      hint(res.disabled ? ('已关闭 ' + res.domain + ' 的拦截') : ('已恢复 ' + res.domain + ' 的拦截'), res.disabled ? 'warn' : '');
      refresh();
    }).catch(function (err) { hint(err.message, 'err'); });
  });

  $('btnLive').addEventListener('click', function () {
    if (!state) return;
    var on = !(state.settings.hideLive === true);
    var btn = $('btnLive');
    btn.disabled = true;
    send('updateSettings', { patch: { hideLive: on } }).then(function () {
      return refresh();
    }).then(function () {
      hint(on ? '已开启：视频站推荐位里的直播内容会被隐藏（已打开的页面刷新后生效）'
              : '已关闭直播推荐屏蔽', on ? '' : 'warn');
    }).catch(function (err) {
      hint('切换失败：' + err.message, 'err');
      btn.disabled = false;
    });
  });

  $('btnRecompile').addEventListener('click', function () {
    hint('正在重新编译规则…');
    send('recompile').then(function () {
      hint('规则已重新编译');
      refresh();
    }).catch(function (err) { hint(err.message, 'err'); });
  });

  $('btnDashboard').addEventListener('click', function () {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/dashboard/dashboard.html') });
    window.close();
  });

  $('btnTheme').addEventListener('click', function () {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/dashboard/dashboard.html#theme') });
    window.close();
  });

  $('btnOptions').addEventListener('click', function () {
    chrome.runtime.openOptionsPage();
    window.close();
  });

  /* 主题：先套上再拉状态，避免窗口打开瞬间闪一下默认配色 */
  if (self.AdShieldTheme) self.AdShieldTheme.init();

  refresh();
})();
