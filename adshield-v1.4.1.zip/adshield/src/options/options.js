/* AdShield - 设置页逻辑 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };

  function send(type, extra) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(Object.assign({ type: type }, extra || {}), function (resp) {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (!resp) { reject(new Error('后台无响应，请尝试重新加载扩展')); return; }
        if (resp.ok === false) { reject(new Error(resp.error || '执行失败')); return; }
        resolve(resp.data);
      });
    });
  }

  var toastTimer = null;
  function toast(text, kind) {
    var el = $('toast');
    el.textContent = text;
    el.className = 'toast' + (kind ? ' ' + kind : '');
    el.hidden = false;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.hidden = true; }, kind === 'err' ? 6000 : 2800);
  }

  function fmtNum(n) {
    if (n === undefined || n === null) return '0';
    return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

  function fmtBytes(b) {
    if (!b) return '0 KB';
    if (b < 1024) return b + ' B';
    if (b < 1024 * 1024) return (b / 1024).toFixed(0) + ' KB';
    return (b / 1024 / 1024).toFixed(1) + ' MB';
  }

  function fmtTime(ts) {
    if (!ts) return '从未';
    var d = new Date(ts);
    return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()) + ' ' +
      p2(d.getHours()) + ':' + p2(d.getMinutes());
  }
  function p2(n) { return String(n).padStart(2, '0'); }

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  var state = null;

  /* ---------------- Tabs ---------------- */
  document.querySelectorAll('.tab').forEach(function (tab) {
    tab.addEventListener('click', function () {
      document.querySelectorAll('.tab').forEach(function (t) { t.classList.remove('active'); });
      document.querySelectorAll('.panel').forEach(function (p) { p.classList.remove('active'); });
      tab.classList.add('active');
      $('panel-' + tab.dataset.tab).classList.add('active');
    });
  });

  /* ---------------- 渲染 ---------------- */

  function renderLists() {
    var box = $('listBox');
    box.textContent = '';
    var lists = state.lists || [];
    $('listCount').textContent = lists.filter(function (l) { return l.enabled; }).length;

    if (!lists.length) {
      var e = el('div', 'empty', '还没有导入任何订阅列表。可以从下方推荐源一键添加，或到「导入规则」页导入本地文件。');
      box.appendChild(e);
    }

    lists.forEach(function (l) {
      var item = el('div', 'list-item' + (l.enabled ? '' : ' off'));

      var sw = el('label', 'switch');
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = !!l.enabled;
      cb.addEventListener('change', function () {
        send('toggleList', { id: l.id, enabled: cb.checked })
          .then(function () { toast(cb.checked ? '已启用 ' + l.name : '已停用 ' + l.name, 'ok'); refresh(); })
          .catch(function (err) { toast(err.message, 'err'); cb.checked = !cb.checked; });
      });
      sw.appendChild(cb);
      sw.appendChild(el('span', 'slider'));
      item.appendChild(sw);

      var info = el('div', 'info');
      info.appendChild(el('b', '', l.name));
      var detail = l.ruleCount
        ? (fmtNum(l.ruleCount) + ' 条规则 · 网络 ' + fmtNum(l.networkCount) + ' / 元素 ' + fmtNum(l.cosmeticCount) +
           ' · ' + fmtBytes(l.bytes) + ' · 更新于 ' + fmtTime(l.updatedAt))
        : '尚未下载内容';
      info.appendChild(el('span', l.error ? 'err' : '', l.error ? ('出错：' + l.error) : detail));
      if (l.url) info.appendChild(el('span', '', l.url));
      item.appendChild(info);

      if (l.url) {
        var btnRefresh = el('button', 'mini-btn', '更新');
        btnRefresh.addEventListener('click', function () {
          btnRefresh.disabled = true;
          btnRefresh.textContent = '更新中…';
          send('refreshList', { id: l.id })
            .then(function () { toast('已更新 ' + l.name, 'ok'); refresh(); })
            .catch(function (err) { toast(err.message, 'err'); })
            .then(function () { btnRefresh.disabled = false; btnRefresh.textContent = '更新'; });
        });
        item.appendChild(btnRefresh);
      }

      var btnDel = el('button', 'mini-btn danger', '删除');
      btnDel.addEventListener('click', function () {
        if (!confirm('确定删除规则列表「' + l.name + '」？')) return;
        send('deleteList', { id: l.id })
          .then(function () { toast('已删除', 'ok'); refresh(); })
          .catch(function (err) { toast(err.message, 'err'); });
      });
      item.appendChild(btnDel);

      box.appendChild(item);
    });
  }

  function renderPresets() {
    var box = $('presetBox');
    box.textContent = '';
    var added = {};
    (state.lists || []).forEach(function (l) { if (l.url) added[l.url] = true; });

    (state.presets || []).forEach(function (p) {
      var card = el('div', 'preset' + (added[p.url] ? ' added' : ''));
      card.appendChild(el('b', '', p.name));
      card.appendChild(el('p', '', p.desc));
      var btn = el('button', 'mini-btn', added[p.url] ? '已订阅' : '一键订阅');
      btn.addEventListener('click', function () {
        btn.disabled = true;
        btn.textContent = '下载中…';
        send('importList', { list: { name: p.name, url: p.url, source: 'url' } })
          .then(function () { toast('已导入 ' + p.name, 'ok'); refresh(); })
          .catch(function (err) {
            toast('导入失败：' + err.message + '（请检查网络能否访问该地址）', 'err');
            btn.disabled = false;
            btn.textContent = '重试';
          });
      });
      card.appendChild(btn);
      box.appendChild(card);
    });
  }

  function renderSettings() {
    var s = state.settings;
    $('masterSwitch').checked = !!s.enabled;
    $('optNetwork').checked = !!s.networkEnabled;
    $('optCosmetic').checked = !!s.cosmeticEnabled;
    $('optGeneric').checked = !!s.genericCosmetic;
    $('optTextRules').checked = s.textRulesEnabled !== false;
    $('optAntiDetect').checked = s.antiDetect !== false;
    $('optHideLive').checked = s.hideLive === true;
    $('optLog').checked = s.logEnabled !== false;
    $('optBadge').checked = !!s.badgeEnabled;
    $('customRules').value = s.customRules || '';
    countCustomRules();

    var info = state.info;
    $('heroSub').textContent = info
      ? ('当前生效 ' + fmtNum(info.dynamicRules) + ' 条网络规则 · ' + fmtNum(info.listCount) + ' 个列表 · 编译于 ' + fmtTime(info.at))
      : '尚未编译规则';
    $('compileInfo').textContent = info
      ? ('编译统计：网络规则 ' + fmtNum(info.network.block) + ' 条拦截 / ' + fmtNum(info.network.allow) +
         ' 条例外 / ' + fmtNum(info.network.redirect) + ' 条参数清理' +
         (info.network.regex ? '（其中正则规则 ' + fmtNum(info.network.regex) + ' 条、自定义规则 ' + fmtNum(info.network.userRules || 0) + ' 条）' : '') +
         '；元素隐藏 ' + fmtNum(info.cosmetic.generic) + ' 条通用 + ' + fmtNum(info.cosmetic.specific) + ' 条站点专属' +
         (info.cosmetic.text ? ' + ' + fmtNum(info.cosmetic.text) + ' 条文本正则' : '') +
         '；跳过不支持的语法 ' + fmtNum(info.network.skipped) + ' 条' +
         (info.network.regexRejected ? ('（其中正则规则 ' + fmtNum(info.network.regexRejected) + ' 条因语法错误或内核不支持被拒绝）') : '') +
         ((info.network.truncated || info.cosmetic.genericTruncated)
           ? ('\n⚠️ 已按规则价值自动取舍：' + fmtNum(info.network.truncated) + ' 条网络规则、' +
              fmtNum(info.cosmetic.genericTruncated) + ' 条通用隐藏规则因超出浏览器上限未生效（浏览器限制单个扩展最多 30000 条动态网络规则）。例外放行与自定义规则优先保留，建议只保留 1-2 个订阅列表。')
           : ''))
      : '—';
    $('compileInfo').style.whiteSpace = 'pre-line';

    // 白名单
    var wbox = $('whiteBox');
    wbox.textContent = '';
    var wl = s.whitelist || [];
    if (!wl.length) wbox.appendChild(el('span', 'mini', '暂无白名单站点'));
    wl.forEach(function (d) {
      var chip = el('span', 'chip');
      chip.appendChild(el('code', '', d));
      var b = el('button', '', '×');
      b.title = '移除';
      b.addEventListener('click', function () {
        send('setWhitelist', { domain: d, add: false })
          .then(function () { toast('已移除 ' + d, 'ok'); refresh(); })
          .catch(function (err) { toast(err.message, 'err'); });
      });
      chip.appendChild(b);
      wbox.appendChild(chip);
    });

    // 自定义元素规则
    var cbox = $('customCosmeticBox');
    cbox.textContent = '';
    var cc = s.customCosmetic || {};
    var keys = Object.keys(cc);
    if (!keys.length) cbox.appendChild(el('span', 'mini', '暂无自定义屏蔽规则，可在弹窗中点击「点选屏蔽元素」添加'));
    keys.forEach(function (host) {
      (cc[host] || []).forEach(function (sel) {
        var chip = el('span', 'chip');
        chip.appendChild(el('code', '', host + ' → ' + sel));
        var b = el('button', '', '×');
        b.addEventListener('click', function () {
          send('undoPickedElement', { host: host, selector: sel })
            .then(function () { toast('已删除该屏蔽规则', 'ok'); refresh(); });
        });
        chip.appendChild(b);
        cbox.appendChild(chip);
      });
    });

    // 统计
    var t = state.totals || {};
    $('sumBlocked').textContent = fmtNum(t.blocked);
    $('sumHidden').textContent = fmtNum(t.hidden);
    $('sumSince').textContent = t.since ? fmtTime(t.since).slice(0, 10) : '-';

    $('aboutInfo').textContent = state.lists && state.lists.length
      ? ('已安装 ' + state.lists.length + ' 个规则列表，共 ' +
         fmtNum(state.lists.reduce(function (a, l) { return a + (l.ruleCount || 0); }, 0)) + ' 条规则。')
      : '尚未安装任何外部规则列表，当前仅使用内置规则库。';
  }

  function countCustomRules() {
    var text = $('customRules').value || '';
    var lines = text.split('\n').filter(function (l) {
      var s = l.trim();
      return s && s.charAt(0) !== '!' && s.charAt(0) !== '[' && s.charAt(0) !== '#';
    });
    $('customStat').textContent = lines.length ? (lines.length + ' 条有效规则') : '暂无自定义规则';
  }

  function refresh() {
    return send('getState').then(function (data) {
      state = data;
      renderLists();
      renderPresets();
      renderSettings();
    }).catch(function (err) {
      toast('加载失败：' + err.message, 'err');
    });
  }

  /* ---------------- 事件绑定 ---------------- */

  $('masterSwitch').addEventListener('change', function (e) {
    var on = e.target.checked;
    send('updateSettings', { patch: { enabled: on } })
      .then(function () { toast(on ? '防护已开启' : '防护已暂停', 'ok'); refresh(); })
      .catch(function (err) { toast(err.message, 'err'); });
  });

  function bindToggle(id, key, label) {
    $(id).addEventListener('change', function (e) {
      var on = e.target.checked;
      send('updateSettings', { patch: (function () { var o = {}; o[key] = on; return o; })() })
        .then(function () { toast(label + (on ? ' 已开启' : ' 已关闭'), 'ok'); refresh(); })
        .catch(function (err) { toast(err.message, 'err'); });
    });
  }
  bindToggle('optNetwork', 'networkEnabled', '网络拦截');
  bindToggle('optCosmetic', 'cosmeticEnabled', '元素隐藏');
  bindToggle('optGeneric', 'genericCosmetic', '通用元素隐藏规则');
  bindToggle('optTextRules', 'textRulesEnabled', '文本正则规则');
  bindToggle('optAntiDetect', 'antiDetect', '反广告拦截检测对抗');
  bindToggle('optHideLive', 'hideLive', '屏蔽直播内容推荐');
  bindToggle('optLog', 'logEnabled', '拦截日志');
  bindToggle('optBadge', 'badgeEnabled', '角标统计');

  $('btnOpenDash').addEventListener('click', function () {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/dashboard/dashboard.html') });
  });

  $('btnOpenTheme').addEventListener('click', function () {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/dashboard/dashboard.html#theme') });
  });

  $('customRules').addEventListener('input', countCustomRules);

  $('btnSaveRules').addEventListener('click', function () {
    var btn = this;
    btn.disabled = true;
    btn.textContent = '编译中…';
    send('updateSettings', { patch: { customRules: $('customRules').value } })
      .then(function (res) {
        var info = res && res.info;
        toast('已保存并编译：' + (info ? fmtNum(info.dynamicRules) + ' 条网络规则生效' : '完成'), 'ok');
        refresh();
      })
      .catch(function (err) { toast('编译失败：' + err.message, 'err'); })
      .then(function () { btn.disabled = false; btn.textContent = '保存并编译'; });
  });

  $('btnAddWhite').addEventListener('click', function () {
    var v = $('whiteInput').value.trim().toLowerCase()
      .replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '');
    if (!v || !/^[a-z0-9][a-z0-9.\-]*\.[a-z]{2,}$/.test(v)) { toast('请输入有效域名，例如 example.com', 'err'); return; }
    send('setWhitelist', { domain: v, add: true })
      .then(function () { toast('已加入白名单：' + v, 'ok'); $('whiteInput').value = ''; refresh(); })
      .catch(function (err) { toast(err.message, 'err'); });
  });

  $('whiteInput').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') $('btnAddWhite').click();
  });

  /* ---- 从 URL 导入 ---- */
  $('btnImportUrl').addEventListener('click', function () {
    var url = $('urlInput').value.trim();
    var name = $('urlName').value.trim();
    if (!/^https?:\/\/.+/i.test(url)) { toast('请输入以 http(s):// 开头的规则地址', 'err'); return; }
    var btn = this;
    btn.disabled = true;
    btn.textContent = '下载中…';
    $('urlProgress').hidden = false;
    send('importList', { list: { name: name, url: url, source: 'url' } })
      .then(function (res) {
        var e = res.entry || {};
        toast('导入成功：' + e.name + '（' + fmtNum(e.ruleCount) + ' 条规则）', 'ok');
        $('urlInput').value = '';
        $('urlName').value = '';
        refresh();
      })
      .catch(function (err) { toast('导入失败：' + err.message, 'err'); })
      .then(function () {
        btn.disabled = false;
        btn.textContent = '下载并导入';
        $('urlProgress').hidden = true;
      });
  });

  /* ---- 导入本地文件 ---- */
  $('btnImportFile').addEventListener('click', function () {
    var input = $('fileInput');
    var files = Array.prototype.slice.call(input.files || []);
    if (!files.length) { toast('请先选择规则文件', 'err'); return; }
    var btn = this;
    btn.disabled = true;
    btn.textContent = '导入中…';

    var okCount = 0;
    var errors = [];

    var chain = Promise.resolve();
    files.forEach(function (f) {
      chain = chain.then(function () {
        return f.text().then(function (text) {
          if (!text || !text.trim()) throw new Error('文件为空');
          return send('importList', { list: { name: f.name.replace(/\.[^.]+$/, ''), text: text, source: 'file' } });
        }).then(function (res) {
          okCount++;
          return res;
        }).catch(function (err) {
          errors.push(f.name + '：' + err.message);
        });
      });
    });

    chain.then(function () {
      if (okCount) toast('成功导入 ' + okCount + ' 个文件' + (errors.length ? '，' + errors.length + ' 个失败' : ''), errors.length ? '' : 'ok');
      if (errors.length) setTimeout(function () { toast('失败：' + errors.join('；'), 'err'); }, 1200);
      input.value = '';
      refresh();
    }).then(function () {
      btn.disabled = false;
      btn.textContent = '导入选中文件';
    });
  });

  /* ---- 粘贴导入 ---- */
  $('btnImportText').addEventListener('click', function () {
    var text = $('pasteArea').value;
    var name = $('pasteName').value.trim();
    if (!text.trim()) { toast('请先粘贴规则内容', 'err'); return; }
    var btn = this;
    btn.disabled = true;
    btn.textContent = '导入中…';
    send('importList', { list: { name: name || ('粘贴规则 ' + new Date().toLocaleString('zh-CN')), text: text, source: 'text' } })
      .then(function (res) {
        var e = res.entry || {};
        toast('导入成功：' + fmtNum(e.ruleCount) + ' 条规则（其中 ' + fmtNum(e.skipped) + ' 条语法暂不支持已跳过）', 'ok');
        $('pasteArea').value = '';
        $('pasteName').value = '';
        refresh();
      })
      .catch(function (err) { toast('导入失败：' + err.message, 'err'); })
      .then(function () { btn.disabled = false; btn.textContent = '导入这段规则'; });
  });

  /* ---- 备份 ---- */
  $('btnExport').addEventListener('click', function () {
    send('exportData').then(function (data) {
      var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'adshield-backup-' + new Date().toISOString().slice(0, 10) + '.json';
      a.click();
      setTimeout(function () { URL.revokeObjectURL(url); }, 3000);
      toast('备份已导出', 'ok');
    }).catch(function (err) { toast(err.message, 'err'); });
  });

  $('btnImportBackup').addEventListener('click', function () {
    var f = $('importFile').files && $('importFile').files[0];
    if (!f) { toast('请先选择备份 .json 文件', 'err'); return; }
    f.text().then(function (text) {
      var data = JSON.parse(text);
      return send('importData', { data: data });
    }).then(function () {
      toast('备份已恢复', 'ok');
      refresh();
    }).catch(function (err) { toast('恢复失败：' + err.message, 'err'); });
  });

  $('btnResetTotals').addEventListener('click', function () {
    if (!confirm('确定重置累计统计？此操作不影响已导入的规则。')) return;
    send('resetTotals').then(function () { toast('统计已重置', 'ok'); refresh(); });
  });

  /* ---------------- 启动 ---------------- */
  // 先套主题再拉配置，避免页面先闪一下默认配色
  if (self.AdShieldTheme) self.AdShieldTheme.init();

  refresh().then(function () {
    var params = new URLSearchParams(location.search);
    if (params.get('welcome')) {
      toast('安装完成！到「导入规则」页可一键订阅 EasyList China 等规则库', 'ok');
      var tab = document.querySelector('.tab[data-tab="import"]');
      if (tab) tab.click();
    }
  });
})();
