/* =============================================================
 * AdShield - 后台 Service Worker
 * 负责：规则编译下发、列表导入/更新、白名单、统计与角标、消息路由
 * ============================================================= */
importScripts(
  '/src/lib/regex-engine.js',
  '/src/lib/filter-parser.js',
  '/src/lib/storage.js',
  '/src/lib/compiler.js'
);

var RX = self.AdShieldRegex;
var P = self.AdShieldParser;
var S = self.AdShieldStorage;
var C = self.AdShieldCompiler;

/** 这些设置改的是界面、独立规则集或内容脚本行为，不参与过滤规则编译，改了不必触发重编译 */
var NO_COMPILE_KEYS = ['theme', 'antiDetect', 'hideLive'];

/* ---------------- 推荐订阅源 ---------------- */
var PRESET_LISTS = [
  {
    id: 'easylist',
    name: 'EasyList（国际通用）',
    url: 'https://easylist.to/easylist/easylist.txt',
    desc: '最主流的国际广告过滤列表，覆盖全球站点'
  },
  {
    id: 'easylist-china',
    name: 'EasyList China（中文站点）',
    url: 'https://easylist-downloads.adblockplus.org/easylistchina.txt',
    desc: '针对国内门户、视频站、论坛的广告规则'
  },
  {
    id: 'easyprivacy',
    name: 'EasyPrivacy（反追踪）',
    url: 'https://easylist.to/easylist/easyprivacy.txt',
    desc: '拦截统计脚本、埋点与用户行为追踪'
  },
  {
    id: 'ublock-filters',
    name: 'uBlock Origin Filters',
    url: 'https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/filters.txt',
    desc: 'uBO 官方基础列表，规则质量高、误伤低'
  },
  {
    id: 'adguard-chinese',
    name: 'AdGuard 中文过滤',
    url: 'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_224_Chinese/filter.txt',
    desc: 'AdGuard 维护的中文广告规则集'
  },
  {
    id: 'adguard-base',
    name: 'AdGuard Base Filter',
    url: 'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_2_Base/filter.txt',
    desc: 'AdGuard 基础通用规则'
  }
];

/* ---------------- 浮动 Promise 兜底 ----------------
 * MV3 下 chrome.action / chrome.storage / chrome.tabs 等 API 在没传回调时返回 Promise。
 * 这些调用大多是「最后一步、不关心结果」的，所以没有 await，外面套的 try/catch 拦不住
 * ——因为拒绝在微任务里发生，此刻 try/catch 早就退出了，于是拒绝会冒成全局未处理错误。
 * 最典型的就是标签页刚关闭时 setBadgeText({tabId}) 抛出
 * "No tab with id: xxx"（报错来源就是这里）。
 * 统一用 swallow() 显式声明「这次调用的失败是可以接受的」。
 */
function swallow(p) {
  if (p && typeof p.then === 'function') {
    p.then(null, function () { /* 标签页/窗口已关闭，或存储配额触及——忽略 */ });
  }
  return p;
}

/* ---------------- 内存态 ---------------- */
var tabStats = Object.create(null);   // tabId -> { blocked, hidden }
var writeTimer = null;

function persistTabStats() {
  if (writeTimer) return;
  writeTimer = setTimeout(function () {
    writeTimer = null;
    try {
      swallow(chrome.storage.session.set({ tabStats: tabStats }));
    } catch (e) { /* ignore */ }
  }, 800);
}

function restoreTabStats() {
  return new Promise(function (resolve) {
    try {
      chrome.storage.session.get(['tabStats'], function (res) {
        void chrome.runtime.lastError;
        if (res && res.tabStats) tabStats = res.tabStats;
        resolve();
      });
    } catch (e) { resolve(); }
  });
}

function stat(tabId) {
  if (tabId === undefined || tabId === null || tabId < 0) return null;
  if (!tabStats[tabId]) tabStats[tabId] = { blocked: 0, hidden: 0 };
  return tabStats[tabId];
}

/* ---------------- 拦截日志（供控制面板查看） ---------------- */
var MAX_LOGS = (S && S.LOG_LIMIT) || 400;
var logBuffer = [];
var logWriteTimer = null;
var logEnabled = true;

/** 实时日志依赖未打包扩展的调试接口，正式打包版不可用 */
var HAS_LIVE_LOG = (function () {
  try { return !!(chrome.declarativeNetRequest && chrome.declarativeNetRequest.onRuleMatchedDebug); }
  catch (e) { return false; }
})();

function persistLogs() {
  if (logWriteTimer) return;
  logWriteTimer = setTimeout(function () {
    logWriteTimer = null;
    try { swallow(chrome.storage.session.set({ blockLogs: logBuffer })); } catch (e) { /* ignore */ }
  }, 1200);
}

function restoreLogs() {
  return new Promise(function (resolve) {
    try {
      chrome.storage.session.get(['blockLogs'], function (res) {
        void chrome.runtime.lastError;
        if (res && Array.isArray(res.blockLogs)) logBuffer = res.blockLogs.slice(-MAX_LOGS);
        resolve();
      });
    } catch (e) { resolve(); }
  });
}

function pushLog(entry) {
  if (!logEnabled) return;
  logBuffer.push(entry);
  if (logBuffer.length > MAX_LOGS) logBuffer.splice(0, logBuffer.length - MAX_LOGS);
  persistLogs();
}

/** 用编译期记录的 id 区间把规则 id 反查成来源名称 */
function ruleSourceOf(ruleId, info) {
  if (ruleId == null || !info || !info.ruleIndex) return null;
  var idx = info.ruleIndex;
  for (var i = 0; i < idx.length; i++) {
    if (ruleId >= idx[i].from && ruleId <= idx[i].to) {
      var src = { name: idx[i].name, user: !!idx[i].user };
      if (src.user && info.userPatterns && info.userPatterns[ruleId]) {
        src.pattern = info.userPatterns[ruleId];
      }
      return src;
    }
  }
  return null;
}

/* ---------------- 角标 ---------------- */
async function updateBadge(tabId) {
  if (tabId === undefined || tabId === null || tabId < 0) return;
  try {
    var settings = await S.getSettings();
    if (!settings.enabled || !settings.badgeEnabled) {
      swallow(chrome.action.setBadgeText({ tabId: tabId, text: '' }));
      return;
    }
    var st = tabStats[tabId];
    var n = st ? (st.blocked + st.hidden) : 0;
    // 标签页可能在 getSettings() 的这一个 await 里就被关掉了，
    // 所以每个 setBadge* 都必须单独兜住拒绝，不能共用外层 try/catch。
    swallow(chrome.action.setBadgeText({ tabId: tabId, text: n > 0 ? String(n > 999 ? '999+' : n) : '' }));
    swallow(chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: '#2f6bff' }));
    if (chrome.action.setBadgeTextColor) {
      swallow(chrome.action.setBadgeTextColor({ tabId: tabId, color: '#ffffff' }));
    }
  } catch (e) { /* tab 已关闭 */ }
}

/* ---------------- 列表导入 ---------------- */
function fetchText(url) {
  return fetch(url, { cache: 'no-cache', credentials: 'omit' }).then(function (resp) {
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    return resp.text();
  });
}

function newListId() {
  return 'L' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

async function importList(opts) {
  var name = (opts.name || '').trim() || '未命名列表';
  var url = (opts.url || '').trim();
  var text = opts.text;
  if (!text && url) {
    text = await fetchText(url);
  }
  if (!text) throw new Error('没有可导入的内容');

  var lists = await S.getLists();
  var existing = url ? lists.filter(function (l) { return l.url === url; })[0] : null;
  var id = existing ? existing.id : newListId();

  var parsed = P.parseList(text);

  var entry = {
    id: id,
    name: name,
    url: url,
    enabled: true,
    autoUpdate: !!url && opts.autoUpdate !== false,
    source: opts.source || (url ? 'url' : 'text'),
    ruleCount: parsed.stats.network + parsed.stats.cosmetic,
    networkCount: parsed.stats.network,
    cosmeticCount: parsed.stats.cosmetic,
    skipped: parsed.stats.skipped,
    updatedAt: Date.now(),
    bytes: text.length
  };

  var payload = { lists: null };
  payload[S.KEYS.LIST_TEXT + id] = text;
  if (existing) {
    lists = lists.map(function (l) { return l.id === id ? entry : l; });
  } else {
    lists.push(entry);
  }
  payload.lists = lists;
  await S.set(payload);
  return entry;
}

/* ---------------- 自定义元素规则（点选屏蔽） ---------------- */
async function applyCustomCosmetic(hostname, selector, add) {
  var settings = await S.getSettings();
  var custom = settings.customCosmetic || {};
  var sels = custom[hostname] || [];
  if (add) {
    if (sels.indexOf(selector) === -1) sels.push(selector);
  } else {
    sels = sels.filter(function (s) { return s !== selector; });
  }
  if (sels.length) custom[hostname] = sels;
  else delete custom[hostname];

  await S.setSettings({ customCosmetic: custom });

  // 同步更新已落盘的外观规则，无需整体重编译
  var key = S.KEYS.COSMETIC_DOMAIN + hostname;
  var res = await S.get([key, S.KEYS.COSMETIC_INDEX]);
  var bucket = res[key] || { s: [], e: [], ng: false, t: [] };
  if (!bucket.t) bucket.t = [];
  if (add) {
    if (bucket.s.indexOf(selector) === -1) bucket.s.push(selector);
  } else {
    bucket.s = bucket.s.filter(function (s) { return s !== selector; });
  }
  var patch = {};
  patch[key] = bucket;
  var index = res[S.KEYS.COSMETIC_INDEX] || [];
  if (index.indexOf(hostname) === -1) {
    index = index.concat([hostname]);
    patch[S.KEYS.COSMETIC_INDEX] = index;
  }
  await S.set(patch);
  return { ok: true, selectors: sels };
}
/* ---------------- 编译封装（串行化，避免并发写规则） ---------------- */
var compileQueue = Promise.resolve();

function scheduleCompile() {
  compileQueue = compileQueue.then(function () {
    return C.compileAll().catch(function (e) {
      console.error('[AdShield] 编译失败', e);
      return { error: String(e && e.message || e) };
    });
  });
  return compileQueue;
}

/* ---------------- 静态规则集开关 ---------------- */
function setBuiltinRuleset(enabled) {
  return new Promise(function (resolve) {
    try {
      chrome.declarativeNetRequest.updateEnabledRulesets(
        enabled ? { enableRulesetIds: ['builtin_ads'] } : { disableRulesetIds: ['builtin_ads'] },
        function () { void chrome.runtime.lastError; resolve(); }
      );
    } catch (e) { resolve(); }
  });
}

/** 反广告拦截对抗规则集（诱饵脚本与诱饵图片的重定向），独立于总开关单独控制 */
function setAntiDetectRuleset(enabled) {
  return new Promise(function (resolve) {
    try {
      chrome.declarativeNetRequest.updateEnabledRulesets(
        enabled ? { enableRulesetIds: ['anti_detect'] } : { disableRulesetIds: ['anti_detect'] },
        function () { void chrome.runtime.lastError; resolve(); }
      );
    } catch (e) { resolve(); }
  });
}

/* ---------------- 初始化 ---------------- */
async function ensureInit() {
  var settings = await S.getSettings();
  await S.setSettings(settings);       // 补齐默认字段
  var lists = await S.getLists();
  if (!Array.isArray(lists)) await S.setLists([]);
  logEnabled = !!settings.logEnabled;

  try {
    chrome.alarms.create('adshield-refresh', { periodInMinutes: 720 });
  } catch (e) { /* ignore */ }

  await setBuiltinRuleset(!!settings.enabled);
  await setAntiDetectRuleset(settings.antiDetect !== false);

  var info = (await S.get([S.KEYS.COMPILE_INFO]))[S.KEYS.COMPILE_INFO];
  if (!info && settings.enabled) await scheduleCompile();
}

chrome.runtime.onInstalled.addListener(function (details) {
  restoreTabStats().then(restoreLogs).then(ensureInit).then(function () {
    if (details.reason === 'install') {
      swallow(chrome.tabs.create({ url: chrome.runtime.getURL('src/options/options.html?welcome=1') }));
    }
  });
});

chrome.runtime.onStartup.addListener(function () {
  restoreTabStats().then(restoreLogs).then(ensureInit);
});

restoreTabStats();
restoreLogs();

/* ---------------- 计数：调试接口（未打包扩展可用） ---------------- */
try {
  if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
    chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(function (info) {
      var req = info.request || {};
      var rule = info.rule || {};
      var tabId = req.tabId;
      var st = stat(tabId);
      if (st) {
        st.blocked++;
        updateBadge(tabId);
        persistTabStats();
      }
      if (logEnabled) {
        pushLog({
          t: Date.now(),
          url: req.url || '',
          type: req.type || '',
          tab: typeof tabId === 'number' ? tabId : -1,
          dynamic: rule.rulesetId === '_dynamic',
          rulesetId: rule.rulesetId || null,
          ruleId: typeof rule.ruleId === 'number' ? rule.ruleId : null
        });
      }
    });
  }
} catch (e) { /* ignore */ }

/* ---------------- 内容脚本汇报 ---------------- */
chrome.runtime.onMessage.addListener(function (msg, sender) {
  if (!msg || msg.type !== 'reportHidden') return;
  var tabId = sender.tab && sender.tab.id;
  var st = stat(tabId);
  if (!st) return;
  st.hidden += (msg.count || 0);
  S.bumpTotals({ hidden: msg.count || 0 });
  updateBadge(tabId);
  persistTabStats();
});

/* ---------------- 标签页生命周期 ---------------- */
chrome.tabs.onRemoved.addListener(function (tabId) {
  delete tabStats[tabId];
  persistTabStats();
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo) {
  if (changeInfo.status === 'loading' && changeInfo.url) {
    tabStats[tabId] = { blocked: 0, hidden: 0 };
    persistTabStats();
    try { swallow(chrome.action.setBadgeText({ tabId: tabId, text: '' })); } catch (e) { /* ignore */ }
  }
});

/* ---------------- 定时任务 ---------------- */
chrome.alarms.onAlarm.addListener(async function (alarm) {
  if (alarm.name === 'adshield-refresh') {
    var lists = await S.getLists();
    var changed = false;
    for (var i = 0; i < lists.length; i++) {
      var l = lists[i];
      if (!l.enabled || !l.autoUpdate || !l.url) continue;
      try {
        var text = await fetchText(l.url);
        var parsed = P.parseList(text);
        var payload = {};
        payload[S.KEYS.LIST_TEXT + l.id] = text;
        await S.set(payload);
        lists[i] = Object.assign({}, l, {
          ruleCount: parsed.stats.network + parsed.stats.cosmetic,
          networkCount: parsed.stats.network,
          cosmeticCount: parsed.stats.cosmetic,
          skipped: parsed.stats.skipped,
          updatedAt: Date.now(),
          bytes: text.length,
          error: null
        });
        changed = true;
      } catch (e) {
        lists[i] = Object.assign({}, l, { error: String(e && e.message || e) });
      }
    }
    if (changed) {
      await S.setLists(lists);
      await scheduleCompile();
    }
  }
});

/* ---------------- 消息路由 ---------------- */
function getActiveTab() {
  return new Promise(function (resolve) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      void chrome.runtime.lastError;
      resolve(tabs && tabs[0]);
    });
  });
}

function hostOf(url) {
  try { return new URL(url).hostname; } catch (e) { return ''; }
}

/** 找出白名单中匹配该 host 的条目 */
function matchWhitelist(host, whitelist) {
  if (!host) return null;
  for (var i = 0; i < whitelist.length; i++) {
    var d = whitelist[i];
    if (host === d || host.endsWith('.' + d)) return d;
  }
  return null;
}

async function buildState() {
  var settings = await S.getSettings();
  var lists = await S.getLists();
  var totals = await S.getTotals();
  var kv = await S.get([S.KEYS.COMPILE_INFO]);
  var tab = await getActiveTab();
  var host = tab ? hostOf(tab.url || '') : '';
  var st = tab && tab.id >= 0 ? (tabStats[tab.id] || { blocked: 0, hidden: 0 }) : { blocked: 0, hidden: 0 };

  var matchedRules = 0;
  if (tab && tab.id >= 0 && chrome.declarativeNetRequest.getMatchedRules) {
    matchedRules = await countMatchedRules(tab.id);
    if (matchedRules > st.blocked) {
      var diff = matchedRules - st.blocked;
      st.blocked = matchedRules;
      S.bumpTotals({ blocked: diff });
      persistTabStats();
      updateBadge(tab.id);
    }
  }

  return {
    settings: settings,
    lists: lists,
    totals: totals,
    info: kv[S.KEYS.COMPILE_INFO] || null,
    presets: PRESET_LISTS,
    capabilities: {
      liveLog: HAS_LIVE_LOG,
      regex: !!RX,
      logCount: logBuffer.length
    },
    tab: {
      id: tab ? tab.id : -1,
      url: tab ? tab.url : '',
      host: host,
      whitelisted: matchWhitelist(host, settings.whitelist),
      blocked: st.blocked,
      hidden: st.hidden
    }
  };
}

function countMatchedRules(tabId) {
  return new Promise(function (resolve) {
    try {
      chrome.declarativeNetRequest.getMatchedRules({ tabId: tabId }, function (res) {
        if (chrome.runtime.lastError) { resolve(0); return; }
        resolve((res && res.rulesMatchedInfo ? res.rulesMatchedInfo.length : 0));
      });
    } catch (e) { resolve(0); }
  });
}

function runPicker(tabId) {
  return new Promise(function (resolve) {
    chrome.tabs.sendMessage(tabId, { type: 'startPicker' }, function (resp) {
      if (chrome.runtime.lastError) {
        // 内容脚本未注入（例如扩展刚安装），主动注入后再试
        chrome.scripting.executeScript(
          { target: { tabId: tabId, allFrames: false }, files: ['src/lib/default-cosmetic.js', 'src/content/cosmetic.js'] },
          function () {
            void chrome.runtime.lastError;
            chrome.tabs.sendMessage(tabId, { type: 'startPicker' }, function (r2) {
              void chrome.runtime.lastError;
              resolve(r2 || { ok: false });
            });
          }
        );
        return;
      }
      resolve(resp || { ok: true });
    });
  });
}

var HANDLERS = {
  getState: function () { return buildState(); },

  updateSettings: async function (msg) {
    var patch = msg.patch || {};
    var next = await S.setSettings(patch);
    if ('logEnabled' in patch) logEnabled = !!next.logEnabled;

    // 反检测对抗挂在独立规则集上，单独启停，同样不必重编译
    if ('antiDetect' in patch) await setAntiDetectRuleset(next.antiDetect !== false);

    // 外观类改动只影响界面，不能触发规则重编译（上万条规则要 1 秒+）
    var keys = Object.keys(patch);
    if (keys.length && keys.every(function (k) { return NO_COMPILE_KEYS.indexOf(k) !== -1; })) {
      return { settings: next, light: true };
    }

    // 只切换总开关时走轻量路径，避免重新下发上万条规则
    if (keys.length === 1 && keys[0] === 'enabled') {
      await setBuiltinRuleset(!!next.enabled);
      if (!next.enabled) {
        await C.clearDynamicRules();
        return { settings: next, light: true };
      }
      // 重新开启需要把动态规则补回去
      return { settings: next, info: await scheduleCompile() };
    }

    var info = await scheduleCompile();
    return { settings: next, info: info };
  },

  importList: async function (msg) {
    var entry = await importList(msg.list || {});
    var info = await scheduleCompile();
    return { entry: entry, info: info };
  },

  refreshList: async function (msg) {
    var lists = await S.getLists();
    var target = lists.filter(function (l) { return l.id === msg.id; })[0];
    if (!target) throw new Error('列表不存在');
    if (!target.url) throw new Error('该列表没有来源 URL');
    var entry = await importList({ name: target.name, url: target.url, text: null, source: target.source });
    var info = await scheduleCompile();
    return { entry: entry, info: info };
  },

  deleteList: async function (msg) {
    var lists = await S.getLists();
    lists = lists.filter(function (l) { return l.id !== msg.id; });
    await S.setLists(lists);
    await S.remove([S.KEYS.LIST_TEXT + msg.id]);
    var info = await scheduleCompile();
    return { info: info };
  },

  toggleList: async function (msg) {
    var lists = await S.getLists();
    lists = lists.map(function (l) {
      return l.id === msg.id ? Object.assign({}, l, { enabled: !!msg.enabled }) : l;
    });
    await S.setLists(lists);
    var info = await scheduleCompile();
    return { info: info };
  },

  setWhitelist: async function (msg) {
    var settings = await S.getSettings();
    var wl = settings.whitelist.slice();
    if (msg.add && wl.indexOf(msg.domain) === -1) wl.push(msg.domain);
    if (!msg.add) wl = wl.filter(function (d) { return d !== msg.domain; });
    await S.setSettings({ whitelist: wl });
    var info = await scheduleCompile();
    return { whitelist: wl, info: info };
  },

  toggleWhitelistCurrent: async function () {
    var tab = await getActiveTab();
    var host = tab ? hostOf(tab.url || '') : '';
    if (!host) throw new Error('无法识别当前站点');
    var settings = await S.getSettings();
    var hit = matchWhitelist(host, settings.whitelist);
    var wl = settings.whitelist.slice();
    var domain = hit || host;
    if (hit) wl = wl.filter(function (d) { return d !== hit; });
    else wl.push(domain);
    await S.setSettings({ whitelist: wl });
    await scheduleCompile();
    return { whitelist: wl, disabled: !hit, domain: domain };
  },

  recompile: async function () {
    return { info: await scheduleCompile() };
  },

  resetTotals: async function () {
    await S.resetTotals();
    tabStats = Object.create(null);
    persistTabStats();
    return { totals: await S.getTotals() };
  },

  clearTabStats: async function (msg) {
    if (tabStats[msg.tabId]) {
      tabStats[msg.tabId] = { blocked: 0, hidden: 0 };
      persistTabStats();
      updateBadge(msg.tabId);
    }
    return { ok: true };
  },

  startPicker: async function () {
    var tab = await getActiveTab();
    if (!tab || tab.id < 0) throw new Error('没有活动标签页');
    return runPicker(tab.id);
  },

  savePickedElement: async function (msg) {
    var host = msg.host || '';
    if (!host) throw new Error('缺少站点信息');
    var res = await applyCustomCosmetic(host, msg.selector, true);
    return res;
  },

  undoPickedElement: async function (msg) {
    var res = await applyCustomCosmetic(msg.host, msg.selector, false);
    return res;
  },

  exportData: async function () {
    var all = await S.get(null);
    var lists = await S.getLists();
    var texts = {};
    lists.forEach(function (l) { texts[l.id] = all[S.KEYS.LIST_TEXT + l.id] || ''; });
    delete all[S.KEYS.COSMETIC_INDEX];
    Object.keys(all).forEach(function (k) {
      if (k.indexOf(S.KEYS.COSMETIC_DOMAIN) === 0) delete all[k];
    });
    return {
      version: 1,
      exportedAt: Date.now(),
      settings: all[S.KEYS.SETTINGS],
      lists: all[S.KEYS.LISTS],
      listTexts: texts,
      totals: all[S.KEYS.TOTALS]
    };
  },

  importData: async function (msg) {
    var data = msg.data || {};
    if (!data.lists) throw new Error('备份文件格式不正确');
    var payload = { lists: data.lists };
    if (data.settings) payload[S.KEYS.SETTINGS] = Object.assign(await S.getSettings(), data.settings);
    var texts = data.listTexts || {};
    Object.keys(texts).forEach(function (id) { payload[S.KEYS.LIST_TEXT + id] = texts[id]; });
    await S.set(payload);
    var info = await scheduleCompile();
    return { info: info };
  },

  getMatchedRules: async function (msg) {
    return { count: await countMatchedRules(msg.tabId) };
  },

  /* ---------------- 控制面板：拦截日志 ---------------- */

  getLogs: async function (msg) {
    var info = (await S.get([S.KEYS.COMPILE_INFO]))[S.KEYS.COMPILE_INFO];
    var limit = Math.min((msg && msg.limit) || 200, MAX_LOGS);
    var filter = ((msg && msg.filter) || '').trim().toLowerCase();
    var hostFilter = ((msg && msg.host) || '').trim().toLowerCase();

    var out = [];
    for (var i = logBuffer.length - 1; i >= 0 && out.length < limit; i--) {
      var e = logBuffer[i];
      if (filter && (e.url || '').toLowerCase().indexOf(filter) === -1) continue;
      var host = hostOf(e.url || '');
      if (hostFilter && host.indexOf(hostFilter) === -1) continue;

      var src = e.dynamic ? ruleSourceOf(e.ruleId, info) : null;
      out.push({
        t: e.t,
        url: e.url,
        host: host,
        type: e.type,
        tab: e.tab,
        source: src ? src.name : (e.dynamic ? ('动态规则 #' + e.ruleId) : (e.rulesetId || '内置规则库')),
        pattern: (src && src.pattern) || null,
        ruleId: e.ruleId
      });
    }

    return {
      logs: out,
      total: logBuffer.length,
      enabled: logEnabled,
      live: HAS_LIVE_LOG
    };
  },

  clearLogs: async function () {
    logBuffer = [];
    try { swallow(chrome.storage.session.set({ blockLogs: [] })); } catch (e) { /* ignore */ }
    return { ok: true };
  },

  /* ---------------- 控制面板：规则校验与追加 ---------------- */

  validateRule: async function (msg) {
    var line = ((msg && msg.line) || '').trim();
    if (!line) throw new Error('规则内容为空');

    var res = P.parseLine(line);
    if (res.kind === 'skip') {
      return { accepted: false, kind: 'skip', reason: res.reason || '语法不受支持，该行会被跳过' };
    }
    if (res.kind === 'cosmetic') {
      var c = res.data;
      if (c.generic) {
        return { accepted: true, kind: 'cosmetic', summary: '控制规则：停用指定站点的通用隐藏规则' };
      }
      var isText = !!(c.text && c.text.length);
      return {
        accepted: true,
        kind: 'cosmetic',
        summary: (c.domains.length ? c.domains.join(',') : '所有站点') +
          ' 隐藏元素 ' + c.selector +
          (isText ? '（文本条件：' + c.text.map(function (t) { return '/' + t.src + '/' + t.flags; }).join(', ') + '）' : ''),
        text: isText
      };
    }

    var dnr = P.toDnrRule(res.data, 1);
    if (!dnr) return { accepted: false, kind: 'network', reason: '无法转换成内核规则' };
    var d = res.data;
    return {
      accepted: true,
      kind: 'network',
      summary: (d.regex ? '正则规则 ' : '') + d.pattern +
        ' → ' + (dnr.action.type === 'block' ? '拦截' : dnr.action.type === 'allow' ? '放行例外' : '清理参数') +
        '（' + d.options.types.length + ' 种资源类型）',
      dnr: dnr,
      regex: !!d.regex,
      repaired: d.repaired || null
    };
  },

  appendCustomRule: async function (msg) {
    var line = ((msg && msg.line) || '').trim();
    if (!line) throw new Error('规则内容为空');
    if (line.indexOf('\n') !== -1) throw new Error('一次只能添加一条规则');

    var settings = await S.getSettings();
    var cur = settings.customRules || '';
    var lines = cur.split('\n');
    for (var i = 0; i < lines.length; i++) {
      if (lines[i].trim() === line) {
        return { duplicated: true, line: line };
      }
    }

    var next = cur.trim() ? (cur.replace(/\s*$/, '') + '\n' + line) : line;
    await S.setSettings({ customRules: next });
    var info = await scheduleCompile();
    return { line: line, info: info };
  },

  openOptions: async function () {
    try { swallow(chrome.runtime.openOptionsPage()); } catch (e) { /* ignore */ }
    return { ok: true };
  }
};

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type || msg.type === 'reportHidden') return false;
  var fn = HANDLERS[msg.type];
  if (!fn) { sendResponse({ error: '未知指令: ' + msg.type }); return false; }
  Promise.resolve()
    .then(function () { return fn(msg, sender); })
    .then(function (res) { sendResponse({ ok: true, data: res }); })
    .catch(function (err) {
      console.error('[AdShield]', msg.type, err);
      sendResponse({ ok: false, error: String(err && err.message || err) });
    });
  return true;   // 异步响应
});
