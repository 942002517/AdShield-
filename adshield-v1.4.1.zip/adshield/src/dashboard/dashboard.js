/* AdShield - 控制面板逻辑 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var RX = self.AdShieldRegex;

  /* ---------------- 通用工具 ---------------- */

  function send(type, extra) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(Object.assign({ type: type }, extra || {}), function (resp) {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (!resp) { reject(new Error('后台无响应，请重新加载扩展')); return; }
        if (resp.ok === false) { reject(new Error(resp.error || '执行失败')); return; }
        resolve(resp.data);
      });
    });
  }

  var toastTimer = null;
  function toast(text, kind) {
    var el = $('toast');
    el.textContent = text;
    el.className = 'toast' + (kind ? ' ' + kind : '');
    el.hidden = false;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.hidden = true; }, 2800);
  }

  function fmtNum(n) {
    if (n === undefined || n === null) return '0';
    return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

  function p2(n) { return String(n).padStart(2, '0'); }

  function fmtTime(ts, withSec) {
    if (!ts) return '—';
    var d = new Date(ts);
    var s = d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()) + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes());
    return withSec ? (s + ':' + p2(d.getSeconds())) : s;
  }

  function fmtAgo(ts) {
    if (!ts) return '—';
    var diff = Date.now() - ts;
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return Math.floor(diff / 60000) + ' 分钟前';
    if (diff < 86400000) return Math.floor(diff / 3600000) + ' 小时前';
    return fmtTime(ts);
  }

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function debounce(fn, wait) {
    var t = null;
    return function () {
      var args = arguments, self_ = this;
      if (t) clearTimeout(t);
      t = setTimeout(function () { t = null; fn.apply(self_, args); }, wait);
    };
  }

  var state = null;

  /* ---------------- 标签切换 ---------------- */

  var activeTab = 'overview';

  function activateTab(name) {
    var target = null;
    document.querySelectorAll('.tab').forEach(function (t) {
      var on = t.dataset.tab === name;
      t.classList.toggle('active', on);
      if (on) target = t;
    });
    if (!target) return;
    document.querySelectorAll('.panel').forEach(function (p) { p.classList.remove('active'); });
    activeTab = name;
    $('panel-' + name).classList.add('active');
    if (name === 'logs') loadLogs();
    if (name === 'regex') runRegexLab();
    if (name === 'theme') themeEnter();
  }

  document.querySelectorAll('.tab').forEach(function (tab) {
    tab.addEventListener('click', function () {
      activateTab(tab.dataset.tab);
      if (history.replaceState) history.replaceState(null, '', '#' + tab.dataset.tab);
    });
  });

  /* ============================================================
   * 一、运行概览
   * ============================================================ */

  var REASON_LABEL = {
    '正则语法错误': '正则语法错误',
    '浏览器内核不支持': '内核不支持的正则写法'
  };

  function renderOverview() {
    if (!state) return;
    var s = state.settings;
    var info = state.info;
    var totals = state.totals || {};

    $('masterSwitch').checked = !!s.enabled;
    $('optNetwork').checked = !!s.networkEnabled;
    $('optCosmetic').checked = !!s.cosmeticEnabled;
    $('optGeneric').checked = !!s.genericCosmetic;
    $('optText').checked = s.textRulesEnabled !== false;
    $('optLog').checked = s.logEnabled !== false;
    $('optBadge').checked = !!s.badgeEnabled;

    var net = (info && info.network) || {};
    var cos = (info && info.cosmetic) || {};

    $('dRules').textContent = info ? fmtNum(info.dynamicRules) : '–';
    $('dRulesSub').textContent = info
      ? (fmtNum(net.block) + ' 拦截 / ' + fmtNum(net.allow) + ' 例外' + (net.regex ? ' · 含 ' + fmtNum(net.regex) + ' 条正则' : ''))
      : '尚未编译';

    $('dCosmetic').textContent = info ? fmtNum((cos.generic || 0) + (cos.specific || 0)) : '–';
    $('dCosmeticSub').textContent = info
      ? (fmtNum(cos.generic) + ' 通用 / ' + fmtNum(cos.specific) + ' 站点专属' + (cos.text ? ' · ' + fmtNum(cos.text) + ' 条文本正则' : ''))
      : '尚未编译';

    $('dBlocked').textContent = fmtNum(totals.blocked || 0);
    $('dBlockedSub').textContent = '已记录 ' + fmtNum((state.capabilities && state.capabilities.logCount) || 0) + ' 条拦截日志';

    $('dHidden').textContent = fmtNum(totals.hidden || 0);
    $('dSince').textContent = totals.since ? ('统计起始 ' + fmtTime(totals.since).slice(0, 10)) : '—';

    $('heroSub').textContent = info
      ? ('生效 ' + fmtNum(info.dynamicRules) + ' 条网络规则 · ' + fmtNum(info.listCount) + ' 个订阅列表 · 编译于 ' + fmtAgo(info.at))
      : '尚未编译规则，可在「详细设置」中导入订阅列表';

    $('compileTime').textContent = info
      ? ('上次编译：' + fmtTime(info.at, true) + '（' + fmtAgo(info.at) + '）')
      : '尚未编译';

    $('cBlock').textContent = fmtNum(net.block);
    $('cAllow').textContent = fmtNum(net.allow);
    $('cRedirect').textContent = fmtNum(net.redirect);
    $('cRegex').textContent = fmtNum(net.regex);
    $('cUser').textContent = fmtNum(net.userRules);
    $('cSkipped').textContent = fmtNum(net.skipped);

    // 未生效的正则规则（按原因归类）
    var reasons = net.reasons || {};
    var rxReasons = Object.keys(reasons).filter(function (k) {
      return k.indexOf('正则') !== -1 || k.indexOf('内核') !== -1;
    });
    var warnBox = $('regexWarn');
    var warnList = $('regexWarnList');
    warnList.textContent = '';
    if (rxReasons.length) {
      warnBox.hidden = false;
      rxReasons.forEach(function (k) {
        var li = el('li', 'warn', fmtNum(reasons[k]) + ' 条：' + k);
        warnList.appendChild(li);
      });
      if (net.regexRepaired) {
        warnList.appendChild(el('li', 'ok', fmtNum(net.regexRepaired) + ' 条使用了占有量词，已自动降级为贪婪量词后生效'));
      }
    } else {
      warnBox.hidden = true;
    }

    // 截断提示
    var trunc = $('truncWarn');
    if (net.truncated || cos.genericTruncated) {
      trunc.hidden = false;
      trunc.textContent = '注意：浏览器限制单个扩展最多 30000 条动态网络规则。本轮已按规则价值取舍，' +
        fmtNum(net.truncated) + ' 条网络规则、' + fmtNum(cos.genericTruncated) +
        ' 条通用隐藏规则未生效。例外放行与自定义规则优先保留，建议只保留 1-2 个订阅列表。';
    } else {
      trunc.hidden = true;
    }

    var cap = state.capabilities || {};
    $('capHint').textContent = cap.liveLog
      ? '当前为开发模式安装，拦截日志为实时完整记录。'
      : '当前为打包安装，内核不提供逐条实时回调，日志面板依赖浏览器提供的匹配记录接口，可能不完整。';
  }

  function refresh() {
    return send('getState').then(function (data) {
      state = data;
      renderOverview();
      if (activeTab === 'logs') loadLogs();
      // 外观页正在编辑时不要用后台的快照覆盖本地状态
      if (activeTab === 'theme' && !themeSaveTimer && state.settings && state.settings.theme) {
        themeState = TH.normalize(state.settings.theme);
        renderTheme(TH.resolve(themeState));
      }
    }).catch(function (err) {
      toast('读取状态失败：' + err.message, 'err');
    });
  }

  function bindToggle(id, key, label) {
    $(id).addEventListener('change', function (e) {
      var on = e.target.checked;
      var patch = {};
      patch[key] = on;
      send('updateSettings', { patch: patch })
        .then(function () { toast(label + (on ? ' 已开启' : ' 已关闭'), 'ok'); refresh(); })
        .catch(function (err) { toast(err.message, 'err'); e.target.checked = !on; });
    });
  }

  bindToggle('optNetwork', 'networkEnabled', '网络拦截');
  bindToggle('optCosmetic', 'cosmeticEnabled', '元素隐藏');
  bindToggle('optGeneric', 'genericCosmetic', '通用元素隐藏');
  bindToggle('optText', 'textRulesEnabled', '文本正则规则');
  bindToggle('optLog', 'logEnabled', '拦截日志');
  bindToggle('optBadge', 'badgeEnabled', '工具栏角标');

  $('masterSwitch').addEventListener('change', function (e) {
    var on = e.target.checked;
    $('masterSwitch').disabled = true;
    send('updateSettings', { patch: { enabled: on } })
      .then(function () { toast(on ? '防护已开启' : '防护已暂停', 'ok'); })
      .catch(function (err) { toast(err.message, 'err'); e.target.checked = !on; })
      .then(function () { $('masterSwitch').disabled = false; refresh(); });
  });

  $('btnOptions').addEventListener('click', function () {
    chrome.runtime.openOptionsPage();
  });

  $('btnRecompile').addEventListener('click', function () {
    var btn = this;
    btn.disabled = true;
    btn.textContent = '编译中…';
    send('recompile')
      .then(function (res) {
        var info = res && res.info;
        toast(info ? ('编译完成：' + fmtNum(info.dynamicRules) + ' 条规则生效') : '编译完成', 'ok');
        refresh();
      })
      .catch(function (err) { toast('编译失败：' + err.message, 'err'); })
      .then(function () { btn.disabled = false; btn.textContent = '重新编译规则'; });
  });

  $('btnReloadTab').addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      void chrome.runtime.lastError;
      var t = tabs && tabs[0];
      if (!t) { toast('找不到当前标签页', 'err'); return; }
      chrome.tabs.reload(t.id, { bypassCache: false }, function () {
        void chrome.runtime.lastError;
        toast('已刷新当前页面', 'ok');
      });
    });
  });

  $('btnExport').addEventListener('click', function () {
    send('exportData').then(function (data) {
      download(
        'adshield-backup-' + new Date().toISOString().slice(0, 10) + '.json',
        JSON.stringify(data, null, 2),
        'application/json'
      );
      toast('备份已导出', 'ok');
    }).catch(function (err) { toast(err.message, 'err'); });
  });

  $('btnResetTotals').addEventListener('click', function () {
    if (!confirm('确定重置累计统计？此操作不影响已导入的规则。')) return;
    send('resetTotals').then(function () { toast('统计已重置', 'ok'); refresh(); });
  });

  function download(filename, content, mime) {
    var blob = new Blob([content], { type: mime || 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    setTimeout(function () { URL.revokeObjectURL(url); }, 3000);
  }

  /* ============================================================
   * 二、正则实验室
   * ============================================================ */

  var RESOURCE_TYPES = [
    { id: 'script', label: '脚本' },
    { id: 'image', label: '图片' },
    { id: 'stylesheet', label: '样式' },
    { id: 'xmlhttprequest', label: 'XHR/fetch' },
    { id: 'subdocument', label: '内嵌框架' },
    { id: 'media', label: '音视频' },
    { id: 'font', label: '字体' },
    { id: 'object', label: '插件对象' },
    { id: 'ping', label: '埋点 ping' },
    { id: 'websocket', label: 'WebSocket' },
    { id: 'other', label: '其他' }
  ];
  var DEFAULT_TYPES = { script: true, image: true, stylesheet: true, xmlhttprequest: true, subdocument: true };

  var rxTypesBuilt = false;
  var rxLastRule = '';

  function buildTypeChecks() {
    if (rxTypesBuilt) return;
    var box = $('rxTypes');
    RESOURCE_TYPES.forEach(function (t) {
      var lab = el('label', 'chk');
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = t.id;
      cb.checked = !!DEFAULT_TYPES[t.id];
      cb.addEventListener('change', function () { runRegexLab(); });
      lab.appendChild(cb);
      lab.appendChild(el('span', '', t.label));
      box.appendChild(lab);
    });
    rxTypesBuilt = true;
  }

  function selectedTypes() {
    var out = [];
    document.querySelectorAll('#rxTypes input:checked').forEach(function (cb) { out.push(cb.value); });
    return out;
  }

  function buildTemplates() {
    var sel = $('rxTemplate');
    RX.TEMPLATES.forEach(function (t, i) {
      var opt = document.createElement('option');
      opt.value = String(i);
      opt.textContent = t.name + ' — ' + t.hint;
      sel.appendChild(opt);
    });
    sel.addEventListener('change', function () {
      var idx = sel.value;
      if (idx === '') return;
      var t = RX.TEMPLATES[Number(idx)];
      $('rxInput').value = t.pattern;
      runRegexLab();
      sel.value = '';
    });
  }

  function readSamples() {
    return $('rxSamples').value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
  }

  function runRegexLab() {
    buildTypeChecks();

    var pattern = $('rxInput').value.trim();
    var caseSensitive = $('rxCase').checked;
    var opts = { caseSensitive: caseSensitive };

    if (!pattern) {
      setVerdict('', '等待输入正则表达式…');
      $('rxQuantBlock').hidden = true;
      $('rxCompatBlock').hidden = true;
      $('rxResults').textContent = '';
      $('rxGreedyPat').textContent = $('rxLazyPat').textContent = '—';
      $('rxGreedyOut').textContent = $('rxLazyOut').textContent = '—';
      $('rxCompareNote').textContent = '输入正则后自动对比。';
      $('rxRuleOut').textContent = '—';
      rxLastRule = '';
      return;
    }

    var v = RX.validate(pattern, caseSensitive ? '' : 'i');

    if (!v.ok) {
      setVerdict('err', '✕ ' + v.error);
      $('rxQuantBlock').hidden = true;
      $('rxCompatBlock').hidden = true;
      renderMatches(pattern, opts, v.ok);
      renderCompare(pattern, opts, v.ok);
      renderRule(pattern, v);
      return;
    }

    var st = v.stats;
    var msg = '✓ 语法正确 · ' + pattern.length + ' 字符 · ' +
      st.captures + ' 个捕获组 · ' +
      st.greedy + ' 贪婪 / ' + st.lazy + ' 懒惰量词';
    setVerdict(v.dnr.ok ? 'ok' : 'warn', (v.dnr.ok ? '' : '! ') + msg +
      (v.dnr.ok ? ' · 可下发浏览器内核' : ' · 但包含内核不支持的写法'));

    renderQuant(st);
    renderCompat(v);
    renderMatches(pattern, opts, true);
    renderCompare(pattern, opts, true);
    renderRule(pattern, v);
  }

  function setVerdict(kind, text) {
    var box = $('rxVerdict');
    box.className = 'rx-verdict' + (kind ? ' ' + kind : '');
    box.textContent = text;
  }

  function renderQuant(st) {
    var block = $('rxQuantBlock');
    var chips = $('rxQuantChips');
    chips.textContent = '';

    if (!st.quantifiers.length) {
      block.hidden = false;
      chips.appendChild(el('span', 'rx-chip', '该表达式不含量词，贪婪与懒惰无从体现'));
      return;
    }

    block.hidden = false;
    var label = { greedy: '贪婪', lazy: '懒惰', possessive: '占有' };
    st.quantifiers.slice(0, 40).forEach(function (q) {
      var chip = el('span', 'rx-chip ' + q.kind, '位置 ' + q.index + '：' + q.text + ' · ' + label[q.kind]);
      chips.appendChild(chip);
    });
    if (st.quantifiers.length > 40) {
      chips.appendChild(el('span', 'rx-chip', '…共 ' + st.quantifiers.length + ' 个量词'));
    }
  }

  function renderCompat(v) {
    var block = $('rxCompatBlock');
    var list = $('rxCompatList');
    list.textContent = '';
    var items = [];

    v.dnr.blockers.forEach(function (b) { items.push(['err', b + '，无法下发给内核（仍可用于文本规则）']); });
    v.dnr.repairs.forEach(function (r) { items.push(['ok', r]); });
    v.errors.forEach(function (e) { items.push(['err', e]); });
    v.warnings.forEach(function (w) { items.push(['warn', w]); });

    if (!items.length) {
      block.hidden = true;
      return;
    }
    block.hidden = false;
    items.forEach(function (it) {
      list.appendChild(el('li', it[0], it[1]));
    });
  }

  function renderMatches(pattern, opts, usable) {
    var box = $('rxResults');
    box.textContent = '';
    var samples = readSamples();

    if (!samples.length) {
      box.appendChild(el('div', 'rx-row miss', '在上方输入样本后，这里会显示逐行匹配结果。'));
      return;
    }
    if (!usable) {
      box.appendChild(el('div', 'rx-row miss', '正则有语法错误，无法执行匹配测试。'));
      return;
    }

    samples.slice(0, 60).forEach(function (s) {
      var res = RX.matchOne(pattern, s, opts);
      var row = el('div', 'rx-row ' + (res.matched ? 'hit' : 'miss'));
      row.appendChild(el('span', 'tag', res.matched ? '命中' : '未命中'));

      if (res.matched) {
        RX.segments(s, res.hits[0]).forEach(function (seg) {
          if (seg.hit) {
            var m = el('mark', 'hit' + (seg.empty ? ' empty' : ''));
            m.textContent = seg.empty ? '⟨空匹配⟩' : seg.text;
            row.appendChild(m);
          } else {
            row.appendChild(document.createTextNode(seg.text));
          }
        });
        if (res.hits.length > 1) {
          row.appendChild(el('span', '', '  （共 ' + res.hits.length + ' 处）'));
        }
      } else {
        row.appendChild(document.createTextNode(s));
      }
      box.appendChild(row);
    });

    if (samples.length > 60) {
      box.appendChild(el('div', 'rx-row miss', '样本过多，仅显示前 60 条。'));
    }
  }

  function renderCompare(pattern, opts, usable) {
    var gPat = $('rxGreedyPat'), lPat = $('rxLazyPat');
    var gOut = $('rxGreedyOut'), lOut = $('rxLazyOut');
    var note = $('rxCompareNote');

    if (!usable) {
      gPat.textContent = lPat.textContent = '—';
      gOut.textContent = lOut.textContent = '—';
      note.textContent = '正则有语法错误，无法对比。';
      return;
    }

    var sample = readSamples()[0] || '';
    var c = RX.compare(pattern, sample, opts);

    gPat.textContent = c.greedyPattern;
    lPat.textContent = c.lazyPattern;

    gOut.textContent = c.greedy.matched ? ('匹配：' + c.greedy.hits[0].text) : '未命中';
    lOut.textContent = c.lazy.matched ? ('匹配：' + c.lazy.hits[0].text) : '未命中';

    if (!sample) {
      note.textContent = '填写样本后即可看到两种量词策略的差异。';
      return;
    }
    note.textContent = c.note +
      (c.changed ? '' : '（原表达式不含可切换的量词）');
  }

  function renderRule(pattern, v) {
    if (!v.ok) {
      rxLastRule = '';
      $('rxRuleOut').textContent = '正则有语法错误，无法生成规则';
      return;
    }

    var out;
    if ($('rxRemoveParam').checked) {
      // 清理参数名：真正会因贪婪/懒惰而改变删除范围的地方
      out = '*$removeparam=' + RX.toRemoveParam(pattern);
    } else if (!v.dnr.ok) {
      // 内核不兼容时只能退化为文本匹配规则
      out = '##div:has-text(/' + pattern + '/' + ($('rxCase').checked ? '' : 'i') + ')';
    } else {
      out = RX.toAbp(pattern, {
        types: selectedTypes(),
        thirdParty: $('rxThird').checked,
        caseSensitive: $('rxCase').checked,
        important: $('rxImportant').checked
      });
    }

    rxLastRule = out;
    $('rxRuleOut').textContent = out;
  }

  var runRegexLabDebounced = debounce(runRegexLab, 180);

  ['rxInput', 'rxSamples', 'rxCase', 'rxThird', 'rxImportant', 'rxRemoveParam'].forEach(function (id) {
    $(id).addEventListener('input', runRegexLabDebounced);
    $(id).addEventListener('change', runRegexLab);
  });

  $('btnCopyRule').addEventListener('click', function () {
    if (!rxLastRule) { toast('请先生成规则', 'err'); return; }
    var done = function () { toast('规则已复制到剪贴板', 'ok'); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(rxLastRule).then(done, function () { toast('复制失败，请手动选中复制', 'err'); });
    } else {
      toast('当前环境不支持自动复制，请手动选中复制', 'err');
    }
  });

  $('btnAddRule').addEventListener('click', function () {
    if (!rxLastRule) { toast('请先生成规则', 'err'); return; }
    var btn = this;
    btn.disabled = true;
    btn.textContent = '写入中…';

    send('validateRule', { line: rxLastRule })
      .then(function (check) {
        if (!check.accepted) throw new Error(check.reason || '该规则不被接受');
        return send('appendCustomRule', { line: rxLastRule });
      })
      .then(function (res) {
        if (res && res.duplicated) { toast('这条规则已经存在，未重复添加', ''); return; }
        toast('已添加到自定义规则并重新编译', 'ok');
        refresh();
      })
      .catch(function (err) { toast('添加失败：' + err.message, 'err'); })
      .then(function () { btn.disabled = false; btn.textContent = '添加到自定义规则'; });
  });

  /* ============================================================
   * 三、拦截日志
   * ============================================================ */

  var logTimer = null;

  function loadLogs() {
    if (!state) return Promise.resolve();
    return send('getLogs', { limit: 200, filter: $('logFilter').value.trim() })
      .then(renderLogs)
      .catch(function (err) {
        $('logNote').textContent = '读取日志失败：' + err.message;
      });
  }

  function renderLogs(data) {
    var box = $('logBox');
    box.textContent = '';
    var logs = (data && data.logs) || [];

    $('logCount').textContent = fmtNum((data && data.total) || 0);
    $('logNote').textContent = !data
      ? '—'
      : (data.enabled
        ? (data.live
          ? '实时记录中（开发模式安装，内核提供逐条回调）。最多保留 ' + fmtNum(data.total) + ' 条。'
          : '记录中，但内核未提供逐条实时回调，数据可能不完整。')
        : '日志记录已关闭，可在「运行概览」中开启。');

    if (!logs.length) {
      box.appendChild(el('div', 'log-empty', data && data.enabled
        ? '还没有拦截记录。打开几个网站后再回来看看。'
        : '日志记录已关闭。'));
      return;
    }

    var table = el('table', 'log-table');
    var thead = el('thead');
    var htr = el('tr');
    ['时间', '类型', '域名', '请求地址', '命中来源'].forEach(function (h) {
      htr.appendChild(el('th', '', h));
    });
    thead.appendChild(htr);
    table.appendChild(thead);

    var tbody = el('tbody');
    logs.forEach(function (item) {
      var tr = el('tr');
      tr.appendChild(el('td', 't', fmtTime(item.t, true)));
      tr.appendChild(el('td', 'src', item.type || '—'));
      tr.appendChild(el('td', 'src', item.host || '—'));

      var tdUrl = el('td', 'u');
      tdUrl.textContent = item.url || '';
      tdUrl.title = item.url || '';
      tr.appendChild(tdUrl);

      var tdSrc = el('td', 'src');
      var isUser = item.pattern != null;
      tdSrc.appendChild(el('span', 'pill' + (isUser ? ' user' : (item.ruleId == null ? ' gray' : '')), item.source || '未知'));
      if (item.pattern) {
        tdSrc.appendChild(el('div', '', item.pattern));
      }
      tr.appendChild(tdSrc);

      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    box.appendChild(table);
  }

  function scheduleLogRefresh() {
    if (logTimer) clearInterval(logTimer);
    logTimer = setInterval(function () {
      if (activeTab !== 'logs' || !$('logAuto').checked) return;
      loadLogs();
    }, 2500);
  }

  $('logFilter').addEventListener('input', debounce(loadLogs, 250));

  $('btnLogClear').addEventListener('click', function () {
    if (!confirm('确定清空拦截日志？')) return;
    send('clearLogs').then(function () {
      toast('日志已清空', 'ok');
      loadLogs();
    }).catch(function (err) { toast(err.message, 'err'); });
  });

  $('btnLogExport').addEventListener('click', function () {
    send('getLogs', { limit: 400, filter: $('logFilter').value.trim() })
      .then(function (data) {
        var rows = [['时间', '类型', '域名', '请求地址', '命中来源']];
        (data.logs || []).forEach(function (l) {
          rows.push([
            new Date(l.t).toLocaleString('zh-CN'),
            l.type, l.host, l.url,
            l.source + (l.pattern ? (' ' + l.pattern) : '')
          ]);
        });
        var csv = rows.map(function (r) {
          return r.map(function (c) { return '"' + String(c == null ? '' : c).replace(/"/g, '""') + '"'; }).join(',');
        }).join('\r\n');
        download('adshield-logs-' + new Date().toISOString().slice(0, 10) + '.csv',
          '\uFEFF' + csv, 'text/csv;charset=utf-8');
        toast('日志已导出', 'ok');
      })
      .catch(function (err) { toast(err.message, 'err'); });
  });

  /* ============================================================
   * 四、界面外观
   * ============================================================ */

  var TH = self.AdShieldTheme;

  var themeState = null;        // 归一化后的主题设置
  var themeBuilt = false;
  var themeSaveTimer = null;

  function themeRef() {
    return themeState || TH.normalize(null);
  }

  function presetTokenOf(presetId, key) {
    var p = TH.getPreset(presetId);
    return p && p.tokens ? TH.toHex(p.tokens[key]) : null;
  }

  /** 只改本地与画面，不落盘（取色器拖动时每一帧都会调用） */
  function liveApply(next) {
    themeState = TH.normalize(next);
    var resolved = TH.resolve(themeState);
    TH.apply(resolved);
    renderTheme(resolved);
    return resolved;
  }

  function queueSave() {
    if (themeSaveTimer) clearTimeout(themeSaveTimer);
    themeSaveTimer = setTimeout(function () {
      themeSaveTimer = null;
      persistTheme();
    }, 260);
  }

  function persistTheme() {
    return TH.save(themeRef()).then(function (resolved) {
      themeState = resolved.theme;
      renderTheme(resolved);
      return resolved;
    }).catch(function (err) {
      toast('主题保存失败：' + err.message, 'err');
    });
  }

  function saveTheme(next) {
    if (themeSaveTimer) { clearTimeout(themeSaveTimer); themeSaveTimer = null; }
    liveApply(next);
    return persistTheme();
  }

  /* ---------------- 预设画廊 ---------------- */

  var SWATCH_KEYS = ['brand', 'brand2', 'bg', 'surface', 'ink'];

  function buildPresetGallery() {
    var box = $('presetGallery');
    if (!box || box.childElementCount) return;

    TH.PRESETS.forEach(function (p) {
      var card = document.createElement('button');
      card.type = 'button';
      card.className = 'preset-card';
      card.dataset.preset = p.id;

      var name = el('div', 'name');
      name.appendChild(el('span', '', p.name));
      name.appendChild(el('span', 'mode', p.mode === 'dark' ? '深' : '浅'));

      var sw = el('div', 'swatches');
      SWATCH_KEYS.forEach(function (k) {
        var i = document.createElement('i');
        i.style.background = p.tokens[k];
        sw.appendChild(i);
      });

      card.appendChild(name);
      card.appendChild(sw);
      card.appendChild(el('div', 'desc', p.desc));

      card.addEventListener('click', function () {
        if (p.id === themeRef().preset && !Object.keys(themeRef().overrides).length) return;
        // 换整套主题时清掉微调，否则新主题会带着上一个主题的改色，预览与实际不符
        saveTheme(Object.assign({}, themeRef(), { preset: p.id, overrides: {} }))
          .then(function () { toast('已切换到「' + p.name + '」', 'ok'); });
      });

      box.appendChild(card);
    });
  }

  /* ---------------- 取色器 ---------------- */

  function buildColorGroups() {
    var box = $('colorGroups');
    if (!box || box.childElementCount) return;

    TH.GROUPS.forEach(function (group) {
      var wrap = el('div', 'color-group');
      wrap.appendChild(el('h3', '', group));

      var rows = el('div', 'color-rows');
      TH.EDITABLE.filter(function (item) { return item.group === group; })
        .forEach(function (item) { rows.appendChild(buildColorRow(item)); });

      wrap.appendChild(rows);
      box.appendChild(wrap);
    });
  }

  function buildColorRow(item) {
    var row = el('div', 'color-row');
    row.dataset.key = item.key;

    var label = document.createElement('label');
    label.textContent = item.label;
    label.setAttribute('for', 'color-' + item.key);

    var picker = document.createElement('input');
    picker.type = 'color';
    picker.id = 'color-' + item.key;

    var hex = document.createElement('input');
    hex.type = 'text';
    hex.spellcheck = false;
    hex.setAttribute('aria-label', item.label + ' 的十六进制值');

    var reset = document.createElement('button');
    reset.type = 'button';
    reset.className = 'reset';
    reset.textContent = '还原';
    reset.title = '撤销这一项的改动';

    picker.addEventListener('input', function () { setColor(item.key, picker.value); });

    hex.addEventListener('change', function () {
      var v = TH.toHex(hex.value);
      if (!v) {
        toast('“' + hex.value + '” 不是有效的颜色值', 'err');
        hex.value = picker.value;
        return;
      }
      setColor(item.key, v);
    });

    reset.addEventListener('click', function () {
      var t = themeRef();
      var ov = Object.assign({}, t.overrides);
      delete ov[item.key];
      saveTheme(Object.assign({}, t, { overrides: ov }));
    });

    row.appendChild(label);
    row.appendChild(picker);
    row.appendChild(hex);
    row.appendChild(reset);
    return row;
  }

  function setColor(key, value) {
    var t = themeRef();
    var hex = TH.toHex(value);
    if (!hex) return;
    var ov = Object.assign({}, t.overrides);
    // 改回预设原值就撤销这条覆盖，保持「未改动」的干净状态
    if (hex === presetTokenOf(t.preset, key)) delete ov[key];
    else ov[key] = hex;
    liveApply(Object.assign({}, t, { overrides: ov }));
    queueSave();
  }

  /* ---------------- 渲染 ---------------- */

  function renderTheme(resolved) {
    if (!resolved) return;
    var t = resolved.theme;

    // 预设选中态
    document.querySelectorAll('#presetGallery .preset-card').forEach(function (card) {
      card.classList.toggle('active', card.dataset.preset === resolved.presetId);
    });

    $('themeCurrent').textContent = resolved.presetName +
      (resolved.isDark ? ' · 深色' : ' · 浅色') +
      (resolved.followedSystem ? '（跟随系统）' : '');

    $('themeAuto').checked = !!t.auto;
    $('themeGradient').checked = resolved.vars['--brand-grad'].indexOf('linear-gradient') === 0;

    var slider = $('themeRadius');
    slider.value = String(t.radius);
    $('themeRadiusOut').textContent = t.radius + 'px';

    // 取色器
    document.querySelectorAll('#colorGroups .color-row').forEach(function (row) {
      var key = row.dataset.key;
      var picker = row.querySelector('input[type="color"]');
      var hex = row.querySelector('input[type="text"]');
      var reset = row.querySelector('button.reset');
      var cur = resolved.base[key];
      var changed = Object.prototype.hasOwnProperty.call(t.overrides, key);

      if (picker.value !== cur) picker.value = cur;
      if (document.activeElement !== hex) hex.value = cur;
      reset.hidden = !changed;
      hex.title = changed
        ? ('预设原值 ' + presetTokenOf(t.preset, key))
        : '与预设一致';
    });

    var ovCount = Object.keys(t.overrides).length;
    $('themeDirty').textContent = ovCount
      ? ('已微调 ' + ovCount + ' 项')
      : '当前与预设完全一致';

    renderThemeChecks(resolved.warnings);
  }

  function renderThemeChecks(warnings) {
    var box = $('themeChecks');
    box.textContent = '';
    $('themeCheckCount').textContent = warnings.length;

    if (!warnings.length) {
      var ok = el('li', 'ok', '当前配色的关键对比度全部达标（WCAG AA）。');
      box.appendChild(ok);
      return;
    }

    warnings.forEach(function (w) {
      var li = el('li', w.level);
      var ratio = document.createElement('b');
      ratio.textContent = w.ratio + ':1';
      li.appendChild(ratio);
      li.appendChild(document.createTextNode(w.text + '（建议 ≥ ' + w.min + ':1）'));
      box.appendChild(li);
    });
  }

  function themeEnter() {
    if (!TH) return;
    buildPresetGallery();
    buildColorGroups();
    if (!themeState) themeState = TH.normalize(state && state.settings ? state.settings.theme : null);
    renderTheme(TH.resolve(themeState));
  }

  /* ---------------- 交互 ---------------- */

  $('themeAuto').addEventListener('change', function (e) {
    var on = e.target.checked;
    saveTheme(Object.assign({}, themeRef(), { auto: on })).then(function (resolved) {
      if (!on) { toast('已关闭跟随系统', 'ok'); return; }
      toast(resolved.followedSystem
        ? ('系统当前为' + (TH.systemPrefersDark() ? '深色' : '浅色') + '，已换成「' + resolved.presetName + '」')
        : '当前预设没有配对的明暗版本，将保持原样', resolved.followedSystem ? 'ok' : 'warn');
    });
  });

  $('themeGradient').addEventListener('change', function (e) {
    var on = e.target.checked;
    saveTheme(Object.assign({}, themeRef(), { gradient: on }))
      .then(function () { toast(on ? '主题色已启用渐变' : '主题色已改为纯色', 'ok'); });
  });

  $('themeRadius').addEventListener('input', function (e) {
    var v = Number(e.target.value);
    $('themeRadiusOut').textContent = v + 'px';
    liveApply(Object.assign({}, themeRef(), { radius: v }));
    queueSave();
  });

  $('btnThemeReset').addEventListener('click', function () {
    var t = themeRef();
    if (!Object.keys(t.overrides).length) { toast('当前没有需要还原的改动', 'warn'); return; }
    saveTheme(Object.assign({}, t, { overrides: {} }))
      .then(function () { toast('已全部恢复为预设原色', 'ok'); });
  });

  $('btnThemeExportJson').addEventListener('click', function () {
    $('themeJson').value = JSON.stringify(themeRef(), null, 2);
    toast('已生成当前主题 JSON，可直接复制', 'ok');
  });

  $('btnThemeImportJson').addEventListener('click', function () {
    var raw = $('themeJson').value.trim();
    if (!raw) { toast('先在文本框里粘贴一份主题 JSON', 'err'); return; }
    var obj;
    try {
      obj = JSON.parse(raw);
    } catch (err) {
      toast('JSON 解析失败：' + err.message, 'err');
      return;
    }
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) {
      toast('这段 JSON 不是主题对象', 'err');
      return;
    }
    saveTheme(obj).then(function (resolved) {
      toast('主题已导入：' + resolved.presetName, 'ok');
    });
  });

  /* ---------------- 启动 ---------------- */

  buildTemplates();
  buildTypeChecks();

  // 先把主题套上再拉状态，避免面板打开时闪一下默认配色
  if (TH) {
    TH.init().then(function (resolved) {
      themeState = resolved.theme;
      if (activeTab === 'theme') renderTheme(resolved);
    });
  }

  $('rxSamples').value = [
    'https://www.example.com/js/ads/banner_300x250.js',
    'https://cdn.site.com/a?utm_source=newsletter&utm_medium=email&id=42',
    'https://analytics.example.com/collect?v=1&gclid=abc123',
    '推荐阅读：赞助商内容 — Sponsored by Acme'
  ].join('\n');

  refresh().then(function () {
    runRegexLab();
    scheduleLogRefresh();
    // 支持从弹窗或设置页用 #theme 直接跳到外观页
    var want = (location.hash || '').replace(/^#/, '');
    if (want && document.querySelector('.tab[data-tab="' + want + '"]')) activateTab(want);
  });
})();
