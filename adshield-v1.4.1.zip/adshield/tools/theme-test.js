/* =============================================================
 * AdShield - 主题引擎专项测试
 *
 * 覆盖：预设合法性、派生色完整性、对比度阈值、覆盖合并、
 *       非法输入容错、跟随系统配对、内容脚本取色。
 * 不依赖 chrome API 与网络。
 * ============================================================= */
'use strict';

global.self = global;
require(process.cwd().replace(/\\/g, '/') + '/src/lib/theme.js');
const T = self.AdShieldTheme;

let pass = 0, fail = 0;
function check(label, cond, extra) {
  if (cond) { pass++; return; }
  fail++;
  console.log('  ✗ ' + label + (extra ? '   [' + extra + ']' : ''));
}
function section(name) { console.log('\n' + name); }

/* ---------------- 1. 颜色工具 ---------------- */
section('1. 颜色工具');

check('toHex 展开三位简写', T.toHex('#f00') === '#ff0000', T.toHex('#f00'));
check('toHex 接受 rgb()', T.toHex('rgb(255, 0, 0)') === '#ff0000', T.toHex('rgb(255,0,0)'));
check('toHex 接受大写', T.toHex('#ABCDEF') === '#abcdef', T.toHex('#ABCDEF'));
check('parseColor 拒绝乱码', T.parseColor('不是颜色') === null);
check('parseColor 拒绝空值', T.parseColor('') === null && T.parseColor(null) === null);
check('parseColor 拒绝超范围 hex', T.parseColor('#1234567') === null);
check('alpha 输出 rgba', T.alpha('#ffffff', 0.5) === 'rgba(255,255,255,0.5)', T.alpha('#ffffff', 0.5));

check('mix 0 取左端', T.mix('#000000', '#ffffff', 0) === '#000000', T.mix('#000000', '#ffffff', 0));
check('mix 1 取右端', T.mix('#000000', '#ffffff', 1) === '#ffffff', T.mix('#000000', '#ffffff', 1));
check('mix 0.5 取中值', T.mix('#000000', '#ffffff', 0.5) === '#808080', T.mix('#000000', '#ffffff', 0.5));

const C_BLACK = T.contrast('#000000', '#ffffff');
check('黑白对比度约 21', Math.abs(C_BLACK - 21) < 0.1, String(C_BLACK.toFixed(3)));
check('同色对比度约 1', Math.abs(T.contrast('#3366ff', '#3366ff') - 1) < 1e-9);
check('对比度与顺序无关', Math.abs(T.contrast('#fff', '#000') - C_BLACK) < 1e-9);
check('readableOn 浅底给深字', T.readableOn('#ffffff') === '#101828', T.readableOn('#ffffff'));
check('readableOn 深底给白字', T.readableOn('#101828') === '#ffffff', T.readableOn('#101828'));

/* ---------------- 2. 预设合法性 ---------------- */
section('2. 预设合法性');

check('预设数量 ≥ 10', T.PRESETS.length >= 10, String(T.PRESETS.length));

const ids = T.PRESETS.map((p) => p.id);
check('预设 id 不重复', new Set(ids).size === ids.length);

const REQUIRED_VARS = [
  '--brand', '--brand-2', '--on-brand', '--brand-text', '--brand-soft', '--brand-line', '--brand-grad',
  '--ink', '--ink-2', '--ink-3', '--line', '--line-2', '--bg', '--surface', '--soft',
  '--track', '--knob', '--code-bg', '--code-ink', '--code-key', '--code-dim',
  '--ok', '--ok-soft', '--ok-line', '--warn', '--warn-soft', '--warn-line',
  '--err', '--err-soft', '--err-line', '--on-ok', '--on-err',
  '--mark-bg', '--mark-ink', '--toast-bg', '--toast-ink', '--toast-ok', '--toast-err',
  '--shadow', '--shadow-pop', '--radius', '--radius-sm', '--radius-lg'
];

T.PRESETS.forEach((p) => {
  check('预设 ' + p.id + ' 有名称与描述', !!p.name && !!p.desc);
  check('预设 ' + p.id + ' 模式合法', p.mode === 'light' || p.mode === 'dark', p.mode);
  T.COLOR_KEYS.forEach((k) => {
    check('预设 ' + p.id + ' 缺色 ' + k, !!T.parseColor(p.tokens[k]), String(p.tokens[k]));
  });
  if (p.darkPair) check('预设 ' + p.id + ' 的 darkPair 存在', !!T.getPreset(p.darkPair), p.darkPair);
  if (p.lightPair) check('预设 ' + p.id + ' 的 lightPair 存在', !!T.getPreset(p.lightPair), p.lightPair);
  if (p.darkPair) {
    check('配对 ' + p.id + '→' + p.darkPair + ' 应为深色主题',
      T.getPreset(p.darkPair).mode === 'dark', T.getPreset(p.darkPair).mode);
  }
  if (p.lightPair) {
    check('配对 ' + p.id + '→' + p.lightPair + ' 应为浅色主题',
      T.getPreset(p.lightPair).mode === 'light', T.getPreset(p.lightPair).mode);
  }
});

check('浅色预设都能配对到深色版本',
  T.PRESETS.filter((p) => p.mode === 'light' && p.id !== 'contrast').every((p) => !!p.darkPair));
check('深色预设都能配对到浅色版本',
  T.PRESETS.filter((p) => p.mode === 'dark').every((p) => !!p.lightPair));

/* ---------------- 3. 派生色完整性 ---------------- */
section('3. 派生色完整性');

T.PRESETS.forEach((p) => {
  const r = T.resolve({ preset: p.id });
  const missing = REQUIRED_VARS.filter((k) => r.vars[k] === undefined || r.vars[k] === '');
  check('预设 ' + p.id + ' 派生色齐全', missing.length === 0, missing.join(','));
  const empty = Object.keys(r.vars).filter((k) => r.vars[k] === undefined || r.vars[k] === '');
  check('预设 ' + p.id + ' 无空变量', empty.length === 0, empty.join(','));

  const colorVars = Object.keys(r.vars).filter((k) => !['--brand-grad', '--shadow', '--shadow-pop', '--radius', '--radius-sm', '--radius-lg'].includes(k));
  const badColor = colorVars.filter((k) => !T.parseColor(r.vars[k]));
  check('预设 ' + p.id + ' 颜色变量都可解析', badColor.length === 0, badColor.map((k) => k + '=' + r.vars[k]).join(' '));

  check('预设 ' + p.id + ' 半径为 px 值', /^\d+px$/.test(r.vars['--radius']), r.vars['--radius']);
  check('预设 ' + p.id + ' 明暗标记正确', r.isDark === (p.mode === 'dark'), String(r.isDark));
});

/* ---------------- 4. 对比度体检 ---------------- */
section('4. 对比度（WCAG）');

T.PRESETS.forEach((p) => {
  const b = T.resolve({ preset: p.id }).base;
  const pairs = [
    ['ink', 'bg', 4.5, '主文字/页面背景'],
    ['ink', 'surface', 4.5, '主文字/卡片背景'],
    ['ink2', 'surface', 3.5, '次级文字/卡片背景'],
    ['ink3', 'surface', 2.2, '弱化文字/卡片背景'],
    ['brand', 'surface', 2, '主题色/卡片背景'],
    ['line', 'surface', 1.15, '边框/卡片背景']
  ];
  pairs.forEach(([a, b2, min, label]) => {
    const c = T.contrast(b[a], b[b2]);
    check('预设 ' + p.id + ' 对比度 ' + label + ' ≥ ' + min,
      c >= min, c.toFixed(2) + ' (' + b[a] + ' on ' + b[b2] + ')');
  });

  // 按钮上的文字必须可读
  const onBrand = T.resolve({ preset: p.id }).vars['--on-brand'];
  const cb = T.contrast(onBrand, b.brand);
  check('预设 ' + p.id + ' 主题色上文字对比度 ≥ 4.5', cb >= 4.5,
    cb.toFixed(2) + ' (' + onBrand + ' on ' + b.brand + ')');

  // 主题色当文字用时也必须可读（浅色主题色最容易被忽略）
  const bt = T.resolve({ preset: p.id }).vars['--brand-text'];
  const cbt = T.contrast(bt, b.surface);
  check('预设 ' + p.id + ' 主题色文字对比度 ≥ 3', cbt >= 3,
    cbt.toFixed(2) + ' (' + bt + ' on ' + b.surface + ')');

  // 预设本身不应产生任何告警
  const w = T.resolve({ preset: p.id }).warnings;
  check('预设 ' + p.id + ' 无对比度告警', w.length === 0,
    w.map((x) => x.text + '=' + x.ratio).join(' | '));
});

section('4c. 主题色文字兜底');
const lightBrand = T.resolve({ preset: 'default', overrides: { brand: '#ffe9a8' } });
check('把主题色改成极浅色后，文字色自动压深到可读',
  T.contrast(lightBrand.vars['--brand-text'], lightBrand.vars['--surface']) >= 3,
  lightBrand.vars['--brand-text'] + ' 对比 ' +
  T.contrast(lightBrand.vars['--brand-text'], lightBrand.vars['--surface']).toFixed(2));
check('兜底只影响文字色，不影响按钮底色',
  lightBrand.vars['--brand'] === '#ffe9a8', lightBrand.vars['--brand']);
const darkBrand = T.resolve({ preset: 'midnight', overrides: { brand: '#101020' } });
check('深色主题下会反向提亮',
  T.contrast(darkBrand.vars['--brand-text'], darkBrand.vars['--surface']) >= 3,
  darkBrand.vars['--brand-text']);
check('原本够用的主题色不被改动',
  T.resolve({ preset: 'default' }).vars['--brand-text'] === T.getPreset('default').tokens.brand,
  T.resolve({ preset: 'default' }).vars['--brand-text']);

section('4b. 对比度告警只在确实有问题时出现');
const badTheme = T.resolve({ preset: 'default', overrides: { ink: '#f8f8f8' } });
check('把主文字改成近白后产生告警', badTheme.warnings.length > 0,
  badTheme.warnings.map((w) => w.text).join(' | '));
check('告警里包含主文字项',
  badTheme.warnings.some((w) => w.keys.includes('ink')), JSON.stringify(badTheme.warnings));

/* ---------------- 5. 归一化与容错 ---------------- */
section('5. 归一化与容错');

const n1 = T.normalize(null);
check('null 得到默认主题', n1.preset === 'default' && n1.radius === 10, JSON.stringify(n1));
check('默认开启渐变', n1.gradient === true);

const n2 = T.normalize({ preset: '并不存在', overrides: { brand: '#123456' } });
check('未知预设回落到默认', n2.preset === 'default', n2.preset);
check('合法覆盖被保留', n2.overrides.brand === '#123456', n2.overrides.brand);

const n3 = T.normalize({ overrides: { brand: '乱码', 未知键: '#ff0000', ink: '#00ff00' } });
check('非法颜色被丢弃', n3.overrides.brand === undefined, JSON.stringify(n3.overrides));
check('未知键被丢弃', n3.overrides['未知键'] === undefined, JSON.stringify(n3.overrides));
check('同批次的合法项保留', n3.overrides.ink === '#00ff00', n3.overrides.ink);

const n4 = T.normalize({ radius: 999 });
check('半径上限被夹到 %d'.replace('%d', T.MAX_RADIUS), n4.radius === T.MAX_RADIUS, String(n4.radius));
check('半径下限被夹到 0', T.normalize({ radius: -5 }).radius === 0, String(T.normalize({ radius: -5 }).radius));
check('半径非法值回落默认', T.normalize({ radius: 'abc' }).radius === 10, String(T.normalize({ radius: 'abc' }).radius));

check('overrides 传字符串不炸', T.normalize({ overrides: 'x' }).overrides && Object.keys(T.normalize({ overrides: 'x' }).overrides).length === 0);
check('gradient:false 被尊重', T.normalize({ gradient: false }).gradient === false);

/* ---------------- 6. 覆盖与派生联动 ---------------- */
section('6. 覆盖与派生联动');

const base = T.resolve({ preset: 'default' });
const mod = T.resolve({ preset: 'default', overrides: { brand: '#ff0066' } });
check('覆盖主题色生效', mod.vars['--brand'] === '#ff0066', mod.vars['--brand']);
check('派生浅底跟着变', mod.vars['--brand-soft'] !== base.vars['--brand-soft'],
  base.vars['--brand-soft'] + ' -> ' + mod.vars['--brand-soft']);
check('派生描边跟着变', mod.vars['--brand-line'] !== base.vars['--brand-line'],
  base.vars['--brand-line'] + ' -> ' + mod.vars['--brand-line']);
check('反色文字自动重算',
  mod.vars['--on-brand'] === T.readableOn('#ff0066'),
  mod.vars['--on-brand'] + ' vs ' + T.readableOn('#ff0066'));
check('未覆盖的颜色保持预设值', mod.vars['--ink'] === base.vars['--ink']);

const noGrad = T.resolve({ preset: 'default', gradient: false });
check('关闭渐变后退化为纯色',
  noGrad.vars['--brand-grad'] === T.getPreset('default').tokens.brand,
  noGrad.vars['--brand-grad']);
check('开启渐变时是 linear-gradient', T.resolve({ preset: 'default' }).vars['--brand-grad'].indexOf('linear-gradient') === 0);

const r0 = T.resolve({ preset: 'default', radius: 0 });
const r20 = T.resolve({ preset: 'default', radius: 20 });
check('半径为 0 时不给负值', r0.vars['--radius-sm'] === '0px', r0.vars['--radius-sm']);
check('半径变大后各级同步', r20.vars['--radius'] === '20px' && r20.vars['--radius-lg'] === '30px',
  r20.vars['--radius'] + ' / ' + r20.vars['--radius-lg']);

check('深色主题不用阴影', T.resolve({ preset: 'midnight' }).vars['--shadow'] === 'none');
check('浅色主题有阴影', T.resolve({ preset: 'default' }).vars['--shadow'].indexOf('0 1px 2px') === 0);

/* ---------------- 7. 跟随系统 ---------------- */
section('7. 跟随系统明暗');

let fakeDark = false;
global.matchMedia = () => ({ matches: fakeDark, addEventListener() {}, addListener() {} });
check('systemPrefersDark 跟随打桩', T.systemPrefersDark() === false);

const autoLight = T.resolve({ preset: 'default', auto: true });
check('浅色系统下 auto 保持浅色', !autoLight.isDark, autoLight.mode);

fakeDark = true;
const autoDark = T.resolve({ preset: 'default', auto: true });
check('深色系统下 auto 切到配对深色主题', autoDark.isDark === true, autoDark.presetId);
check('切换到了预期的配对主题', autoDark.presetId === 'midnight', autoDark.presetId);
check('标记为已跟随系统', autoDark.followedSystem === true);
check('覆盖色在切换后仍然生效',
  T.resolve({ preset: 'default', auto: true, overrides: { brand: '#ff0000' } }).vars['--brand'] === '#ff0000');

const autoOff = T.resolve({ preset: 'default', auto: false });
check('关闭跟随则不切换', autoOff.isDark === false, autoOff.presetId);

const contrastAuto = T.resolve({ preset: 'contrast', auto: true });
check('无配对时跟随系统不崩', !!contrastAuto.vars['--brand'], contrastAuto.presetId);

fakeDark = false;
check('深色系统下反向配对到浅色', T.resolve({ preset: 'midnight', auto: true }).isDark === false);
check('反向配对目标是 default', T.resolve({ preset: 'midnight', auto: true }).presetId === 'default');

/* ---------------- 8. 内容脚本取色 ---------------- */
section('8. 内容脚本点选器取色');

T.PRESETS.forEach((p) => {
  const o = T.overlayTokens(T.resolve({ preset: p.id }));
  const keys = ['hiBorder', 'hiFill', 'barBg', 'barInk', 'btnPrimary', 'btnInk'];
  const bad = keys.filter((k) => !T.parseColor(o[k]));
  check('预设 ' + p.id + ' 点选器取色可用', bad.length === 0, bad.join(','));
  check('预设 ' + p.id + ' 按钮文字与主题色对比 ≥ 4.5',
    T.contrast(o.btnInk, o.btnPrimary) >= 4.5,
    T.contrast(o.btnInk, o.btnPrimary).toFixed(2));
  check('预设 ' + p.id + ' 提示条文字可读',
    T.contrast(o.barInk, o.barBg) >= 4.5, T.contrast(o.barInk, o.barBg).toFixed(2));
  check('预设 ' + p.id + ' 半径透传', typeof o.radius === 'number');
});

const vs = T.varString(T.resolve({ preset: 'default' }));
check('varString 含 --brand', vs.indexOf('--brand:') !== -1);
check('varString 以分号分隔且无空项',
  vs.split(';').every((s) => s.indexOf(':') > 0), vs.slice(0, 80));

/* ---------------- 9. 存取与重置 ---------------- */
section('9. 覆盖清除');

const cleared = T.resetOverrides({ preset: 'indigo', overrides: { brand: '#000000', ink: '#111111' } });
check('resetOverrides 清空全部覆盖', Object.keys(cleared.overrides).length === 0);
check('resetOverrides 保留预设', cleared.preset === 'indigo', cleared.preset);
check('清除后回到预设原色',
  T.resolve(cleared).vars['--brand'] === T.getPreset('indigo').tokens.brand);

check('getPreset 未知 id 返回 null', T.getPreset('nope') === null);
check('DEFAULT_THEME 可被外部读取', T.DEFAULT_THEME.preset === 'default');

console.log('\n' + '='.repeat(52));
console.log('通过 ' + pass + ' 项，失败 ' + fail + ' 项');
console.log('='.repeat(52));
process.exit(fail === 0 ? 0 : 1);
