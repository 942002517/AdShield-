# -*- coding: utf-8 -*-
"""直播推荐屏蔽：真实站点端到端验证。

test/live-block.html 用的是"按真实探测结果搭的夹具"，它能证明判定逻辑对，
证明不了两件事：
  1) 规则库里的 liveHosts 片段，今天还能命中真实站点的链接
  2) 真装进浏览器后，内容脚本确实在真实页面上跑起来并藏住了卡片

所以这里用 --load-extension 真装扩展，把 hideLive 打开，再去真实视频站
取数。判定只看 DOM 产物（style 元素 / data-adshield-live 属性），因为内容
脚本在隔离世界，它的变量从页面里读不到。

用法：
  python tools/live-e2e.py                 # 打开 hideLive，验证真实站点上的屏蔽
  python tools/live-e2e.py --off           # 对照组：不打开，拍"屏蔽前"的图
  python tools/live-e2e.py --scroll 1234   # 沿用对照组测出的滚动位置，图才对得齐
"""
import base64
import json
import os
import subprocess
import sys
import time
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shot import (CDP, http_json, find_browser,  # noqa: E402
                  cleanup_profile, stop_browser, wait_cdp)

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CDP_PORT = 9338


def _flag(name):
    if name in sys.argv:
        sys.argv.remove(name)
        return True
    return False


def _opt(name, cast=int, default=None):
    """取形如 `--scroll 1234` 的带值选项，取走后从 argv 移除。"""
    if name in sys.argv:
        i = sys.argv.index(name)
        try:
            v = cast(sys.argv[i + 1])
        except (IndexError, ValueError):
            v = default
        del sys.argv[i:i + 2]
        return v
    return default


HIDE_LIVE = not _flag("--off")
# 手动指定滚动位置：屏蔽后直播卡片已经 display:none，量不出它在哪，
# 所以拿对照组（--off）测出的 y 值传进来，两张图才对齐到同一处。
SCROLL_Y = _opt("--scroll", int, None)

DEFAULT_TARGETS = [
    ("哔哩哔哩首页", "https://www.bilibili.com/"),
    ("哔哩哔哩搜索页", "https://search.bilibili.com/all?keyword=%E8%8B%B1%E9%9B%84%E8%81%94%E7%9B%9F"),
]

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0")

checks = []


def rec(name, ok, detail=""):
    checks.append((name, bool(ok), detail))
    print("  %s %s%s" % ("PASS" if ok else "FAIL", name,
                         ("   " + detail) if detail else ""))


def info(msg):
    print("       %s" % msg)


def start_browser(port, profile):
    cleanup_profile(profile)
    args = [
        find_browser(), "--headless=new", "--no-sandbox", "--disable-gpu",
        "--disable-dev-shm-usage", "--no-first-run", "--no-default-browser-check",
        "--disable-sync", "--lang=zh-CN",
        "--user-data-dir=" + profile,
        "--remote-debugging-port=%d" % port,
        "--remote-allow-origins=*",
        "--load-extension=" + BASE,
        "--window-size=1400,1000",
        "about:blank",
    ]
    proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    wait_cdp(port, proc, profile)
    time.sleep(3)                       # 给 MV3 service worker 注册留时间
    return proc


# ---------------- 找扩展 ID ----------------
# 不自己算路径哈希（那套算法跨平台不一致），直接从 profile 的 Preferences 里
# 读 Chrome 自己登记的结果，再用 options 页面探一次确认。

EXT_ID_CHARS = set('abcdefghijklmnop')


def is_ext_id(s):
    return isinstance(s, str) and len(s) == 32 and set(s) <= EXT_ID_CHARS


def ids_from_prefs(profile):
    """从 profile 里读 Chrome 自己登记的扩展条目。

    注意要连 Secure Preferences 一起读：以 --load-extension 加载的未打包扩展
    是登记在 Secure Preferences 里的（location=8），Preferences 里查不到。
    """
    out = []
    for name in ("Preferences", "Secure Preferences"):
        p = os.path.join(profile, "Default", name)
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            continue
        settings = (data.get("extensions") or {}).get("settings") or {}
        for eid, ent in settings.items():
            if not is_ext_id(eid):
                continue
            path = (ent.get("path") or "").replace("\\", "/").rstrip("/")
            out.append((eid, path))
    return out


def pick_ext_id(profile):
    want = BASE.replace("\\", "/").rstrip("/").lower()
    cands = ids_from_prefs(profile)
    for eid, path in cands:
        if path.lower() == want:
            return eid, "profile 登记项（路径精确匹配）"
    if len(cands) == 1:
        return cands[0][0], "profile 登记项（仅一个候选）"
    return None, "未找到（id 候选 %d 个）" % len(cands)


def ev(cdp, sid, expr, timeout_note=""):
    r = cdp.send("Runtime.evaluate",
                 {"expression": expr, "returnByValue": True, "awaitPromise": True}, sid)
    if "exceptionDetails" in r:
        return None
    return r.get("result", {}).get("value")


# ---------------- 页面取数 ----------------

# 注意：内容脚本在隔离世界，window.__adShieldLive 在这里读不到。
# 但 <style> 元素和元素上的 data-* 属性都在共享 DOM 上，可以正常读到。
STATS = r"""
(function () {
  var MARK = 'data-adshield-live';
  var liveRe = /live\.bilibili\.com/;
  function vis(el) {
    if (!el) return false;
    return el.offsetHeight > 0 && getComputedStyle(el).display !== 'none';
  }
  var chromeRe = /(^|[-_\s])(header|navbar|navigation|nav|topbar|menu|sidebar|aside|breadcrumb|footer|toolbar)([-_\s]|$)/i;
  function inChrome(el) {
    var d = 0;
    while (el && el.nodeType === 1 && d < 16) {
      var tag = el.tagName;
      if (tag === 'HEADER' || tag === 'NAV' || tag === 'FOOTER' || tag === 'ASIDE') return true;
      if (el.getAttribute && el.getAttribute('role') === 'navigation') return true;
      var c = (typeof el.className === 'string' ? el.className : '') || '';
      if (c && chromeRe.test(c)) return true;
      if (el === document.body) return false;
      el = el.parentElement; d++;
    }
    return false;
  }

  var all = [].slice.call(document.querySelectorAll('a[href]'));
  var live = all.filter(function (a) { return liveRe.test(a.href); });
  var liveOut = live.filter(function (a) { return !inChrome(a); });
  var marked = [].slice.call(document.querySelectorAll('[' + MARK + ']'));
  var style = document.getElementById('__adshield_live_style__');

  return JSON.stringify({
    title: document.title,
    url: location.href,
    links: all.length,
    liveLinks: live.length,
    liveOutsideChrome: liveOut.length,
    liveVisible: live.filter(vis).length,
    marked: marked.length,
    markedVisible: marked.filter(vis).length,
    hasStyle: !!style,
    css: style ? style.textContent.slice(0, 200) : ''
  });
})()
"""

# 找出第一张直播卡片在文档里的纵向位置，用来把"屏蔽前/后"的截图对齐到同一处。
# 不能靠 [data-adshield-live] 定位——屏蔽后那张卡片已经 display:none，
# 量出来是 0，反而找不到位置；这里从链接往上找承载它的卡片外壳。
LOCATE = r"""
(function () {
  var liveRe = /live\.bilibili\.com/;
  var chromeRe = /(^|[-_\s])(header|navbar|navigation|nav|topbar|menu|sidebar|aside|breadcrumb|footer|toolbar)([-_\s]|$)/i;
  function inChrome(el) {
    var d = 0;
    while (el && el.nodeType === 1 && d < 16) {
      var tag = el.tagName;
      if (tag === 'HEADER' || tag === 'NAV' || tag === 'FOOTER' || tag === 'ASIDE') return true;
      var c = (typeof el.className === 'string' ? el.className : '') || '';
      if (c && chromeRe.test(c)) return true;
      if (el === document.body) return false;
      el = el.parentElement; d++;
    }
    return false;
  }
  var cardRe = /(card|cells?|items?|entry|module|tile|feed)/i;
  var ceiling = Math.max(360, Math.min(Math.round(innerHeight * 0.85), 1000));
  var links = [].slice.call(document.querySelectorAll('a[href]'));
  for (var i = 0; i < links.length; i++) {
    var a = links[i];
    if (!liveRe.test(a.href) || inChrome(a)) continue;
    // 跳过已经被隐藏的（getClientRects 为空说明根本没参与渲染），
    // 这样才定位得到"对照组里那张看得见的直播卡片"
    if (!a.getClientRects().length) continue;
    var el = a.parentElement, best = null, d = 0;
    while (el && el.nodeType === 1 && el !== document.body && d < 12) {
      var h = el.offsetHeight || 0;
      if (h > ceiling) break;
      if (cardRe.test((typeof el.className === 'string' ? el.className : '') || '')) best = el;
      else if (best) break;
      el = el.parentElement; d++;
    }
    if (!best) continue;
    var r = best.getBoundingClientRect();
    return JSON.stringify({
      y: Math.round(r.top + scrollY),
      h: Math.round(r.height),
      cls: (best.className || '').toString().slice(0, 70)
    });
  }
  return 'null';
})()
"""


def run_page(cdp, url, label, out_dir, idx):
    t = cdp.send("Target.createTarget", {"url": "about:blank"})
    tid = t["targetId"]
    sid = cdp.send("Target.attachToTarget",
                   {"targetId": tid, "flatten": True})["sessionId"]
    cdp.send("Page.enable", {}, sid)
    cdp.send("Runtime.enable", {}, sid)
    cdp.send("Emulation.setUserAgentOverride",
             {"userAgent": UA, "acceptLanguage": "zh-CN,zh;q=0.9"}, sid)
    cdp.send("Emulation.setDeviceMetricsOverride",
             {"width": 1400, "height": 1000, "deviceScaleFactor": 1, "mobile": False}, sid)
    cdp.send("Page.navigate", {"url": url}, sid)

    # 等首屏渲染 + 内容脚本的补扫落地（DOMContentLoaded/load 各会补一次）
    time.sleep(9)

    raw = ev(cdp, sid, STATS)
    try:
        st = json.loads(raw) if raw else {}
    except Exception:
        st = {}

    print("\n【%s】%s" % (label, "" if HIDE_LIVE else "（对照组：功能关闭）"))
    if not st:
        info("取数失败")
    else:
        info("标题: %s" % (st.get("title") or "")[:70])
        info("链接 %d 个，其中指向直播域 %d 个（导航/侧栏之外 %d 个）"
             % (st.get("links", 0), st.get("liveLinks", 0), st.get("liveOutsideChrome", 0)))
        info("已打标记 %d 个，其中仍然可见 %d 个；样式表 %s"
             % (st.get("marked", 0), st.get("markedVisible", 0),
                "已注入" if st.get("hasStyle") else "缺失"))
        if st.get("css"):
            info("CSS: %s" % st["css"].replace("\n", " ")[:110])

        if not HIDE_LIVE:
            # 对照组只观察、不判定：功能关着，本来就该看不到任何痕迹
            info("对照组预期：样式表缺失、marked=0，且直播卡片照常可见")
            rec("对照组：功能关闭时页面无任何屏蔽痕迹",
                not st.get("hasStyle") and st.get("marked", 0) == 0,
                "style=%s marked=%d" % (st.get("hasStyle"), st.get("marked", 0)))
            rec("对照组：直播卡片仍然可见（可作为前后对比的基线）",
                st.get("liveOutsideChrome", 0) == 0 or st.get("liveVisible", 0) > 0,
                "直播链接可见 %d 个" % st.get("liveVisible", 0))
        else:
            rec("内容脚本在真实站点上已运行", st.get("hasStyle"))
            rec("打了标记的卡片确实都藏住了",
                st.get("hasStyle") and st.get("markedVisible") == 0,
                "marked=%d visible=%d" % (st.get("marked", 0), st.get("markedVisible", 0)))
            # 只有在页面上真的存在"导航之外的直播链接"时，才要求必须藏住东西；
            # 否则页面本来就没有直播推荐，藏 0 个也是对的，不该判失败。
            if st.get("liveOutsideChrome", 0) > 0:
                rec("存在直播推荐，且至少隐藏了 1 张卡片",
                    st.get("marked", 0) >= 1,
                    "可屏蔽直播链接 %d 个 → 已藏 %d 张卡片"
                    % (st.get("liveOutsideChrome", 0), st.get("marked", 0)))
            else:
                info("（页面上没有导航之外的直播链接，跳过「是否有卡片被藏」的断言）")

    # 截图存档：滚到第一张直播卡片处取视口，"屏蔽前/后"两张图才是同一处可比。
    # 取不到位置（页面上没有直播推荐）就退回页首。
    try:
        if SCROLL_Y is not None:
            scroll_y = max(0, SCROLL_Y)
            info("沿用指定滚动位置 y=%d（与对照组对齐）" % scroll_y)
        else:
            loc_raw = ev(cdp, sid, LOCATE)
            loc = json.loads(loc_raw) if loc_raw and loc_raw != "null" else None
            if loc:
                info("首张直播卡片: 文档 y=%d 高=%d class=%s"
                     % (loc["y"], loc["h"], loc["cls"]))
                scroll_y = max(0, loc["y"] - 120)
            else:
                scroll_y = 0
        ev(cdp, sid, "window.scrollTo(0, %d); 1" % scroll_y)
        time.sleep(1.2)

        shot = cdp.send("Page.captureScreenshot", {"format": "png"}, sid)
        tag = "on" if HIDE_LIVE else "off"
        png = os.path.join(out_dir, "live-e2e-%d-%s.png" % (idx, tag))
        with open(png, "wb") as f:
            f.write(base64.b64decode(shot["data"]))
        info("截图: %s" % png)
    except Exception as exc:                                  # noqa: BLE001
        info("截图失败: %s" % exc)

    cdp.send("Target.closeTarget", {"targetId": tid})


def main():
    targets = DEFAULT_TARGETS + [(u, u) for u in sys.argv[1:]]
    out_dir = os.path.join(BASE, "tools", ".tmp", "livee2e")
    os.makedirs(out_dir, exist_ok=True)
    profile = os.path.join(out_dir, "profile")

    print("启动带扩展的浏览器 :%d（真装扩展，hideLive=%s）"
          % (CDP_PORT, "开" if HIDE_LIVE else "关"))
    br = start_browser(CDP_PORT, profile)
    code = 3
    try:
        ver = http_json(CDP_PORT, "/json/version")
        cdp = CDP(ver["webSocketDebuggerUrl"])

        eid, how = pick_ext_id(profile)
        print("扩展 ID: %s  (%s)" % (eid or "—", how))
        if not eid:
            print("\n结论: 拿不到扩展 ID，无法打开设置页打开 hideLive")
            stop_browser(br, profile)
            sys.exit(2)

        # 打开设置页：扩展页面才有 chrome.storage 权限
        t = cdp.send("Target.createTarget",
                     {"url": "chrome-extension://%s/src/options/options.html" % eid})
        tid = t["targetId"]
        sid = cdp.send("Target.attachToTarget",
                       {"targetId": tid, "flatten": True})["sessionId"]
        cdp.send("Runtime.enable", {}, sid)
        time.sleep(2)

        ok_page = ev(cdp, sid, "!!document.getElementById('optHideLive')")
        rec("扩展设置页可访问（ID 有效）", ok_page, "chrome-extension://%s/…" % eid)
        if not ok_page:
            print("\n结论: 扩展 ID 不可用")
            stop_browser(br, profile)
            sys.exit(2)

        # 直接写 chrome.storage.local，等价于用户在设置里拨这个开关
        wrote = ev(cdp, sid, """new Promise(function (res) {
          chrome.storage.local.get('settings', function (r) {
            var s = Object.assign({}, r.settings || {},
                                  {enabled: true, hideLive: %s});
            chrome.storage.local.set({settings: s}, function () {
              res(JSON.stringify({enabled: s.enabled, hideLive: s.hideLive}));
            });
          });
        })""" % ("true" if HIDE_LIVE else "false"))
        rec("已把「屏蔽直播内容推荐」拨到 %s" % ("开" if HIDE_LIVE else "关（对照组）"),
            bool(wrote) and ("true" if HIDE_LIVE else "false") in str(wrote), str(wrote))
        cdp.send("Target.closeTarget", {"targetId": tid})

        for i, (label, url) in enumerate(targets):
            run_page(cdp, url, label, out_dir, i)

        cdp.close()
        passed = sum(1 for _, ok, _ in checks if ok)
        print("\n结果：%d 通过 / %d 失败" % (passed, len(checks) - passed))
        code = 0 if passed == len(checks) else 1
    finally:
        stop_browser(br, profile)
    sys.exit(code)


if __name__ == "__main__":
    main()
