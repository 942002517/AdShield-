/* =============================================================
 * AdShield - 端到端测试（Node 环境，mock chrome.* API）
 * 用真实规则列表跑完整编译流程，验证：
 *   1) 动态规则能正常下发且全部合法
 *   2) 元素隐藏索引正确落盘
 *   3) 超限时按价值取舍而不是整批失败
 *   4) 混入非法规则时二分回退只丢弃坏规则
 *
 * 运行： node tools/e2e-test.js
 * ============================================================= */
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.dirname(__dirname);
const VALID_TYPES = ['main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'font',
  'object', 'xmlhttprequest', 'ping', 'csp_report', 'media', 'websocket', 'other'];

const DYNAMIC_LIMIT = 30000;

let pass = 0;
let fail = 0;
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  \u2713 ' + name); }
  else { fail++; console.log('  \u2717 ' + name + (extra ? '  -> ' + extra : '')); }
}

/* ---------------- mock chrome.storage.local ---------------- */
const store = new Map();
const storageLocal = {
  get(keys, cb) {
    const res = {};
    if (keys === null || keys === undefined) {
      for (const [k, v] of store) res[k] = v;
    } else if (typeof keys === 'string') {
      if (store.has(keys)) res[keys] = store.get(keys);
    } else if (Array.isArray(keys)) {
      keys.forEach((k) => { if (store.has(k)) res[k] = store.get(k); });
    } else {
      Object.keys(keys).forEach((k) => { res[k] = store.has(k) ? store.get(k) : keys[k]; });
    }
    // 模拟 storage 的序列化行为
    cb(JSON.parse(JSON.stringify(res)));
  },
  set(obj, cb) {
    const v = JSON.parse(JSON.stringify(obj));
    Object.keys(v).forEach((k) => store.set(k, v[k]));
    if (cb) cb();
  },
  remove(keys, cb) {
    (Array.isArray(keys) ? keys : [keys]).forEach((k) => store.delete(k));
    if (cb) cb();
  },
  getKeys(cb) { cb(Array.from(store.keys())); },
};

/* ---------------- mock declarativeNetRequest ---------------- */
let dynamicRules = [];
const rejectLog = [];

function validateRule(r) {
  if (typeof r.id !== 'number' || !Number.isInteger(r.id) || r.id < 1) return 'id 非法';
  if (typeof r.priority !== 'number' || !Number.isInteger(r.priority)) return 'priority 非法';
  if (!r.action || ['block', 'redirect', 'allow', 'upgradeScheme', 'modifyHeaders', 'allowAllRequests'].indexOf(r.action.type) === -1) {
    return 'action.type 非法';
  }
  const c = r.condition || {};
  const hasTarget = c.urlFilter !== undefined || c.regexFilter !== undefined ||
    c.requestDomains !== undefined || c.initiatorDomains !== undefined;
  if (!hasTarget) return 'condition 缺少匹配目标';
  if (c.urlFilter !== undefined) {
    if (typeof c.urlFilter !== 'string') return 'urlFilter 不是字符串';
    if (c.urlFilter.length === 0) return 'urlFilter 为空';
    if (c.urlFilter.length > 2048) return 'urlFilter 过长';
  }
  if (c.regexFilter !== undefined) {
    if (c.urlFilter !== undefined) return 'urlFilter 与 regexFilter 不能同时存在';
    if (c.regexFilter.length > 2048) return 'regexFilter 过长';
    try { new RegExp(c.regexFilter); } catch (e) { return 'regexFilter 非法: ' + e.message; }
  }
  if (c.resourceTypes !== undefined) {
    if (!Array.isArray(c.resourceTypes) || !c.resourceTypes.length) return 'resourceTypes 为空';
    for (const t of c.resourceTypes) if (VALID_TYPES.indexOf(t) === -1) return '未知资源类型 ' + t;
  }
  if (r.action.type === 'allow' && !c.resourceTypes) return 'allow 规则必须指定 resourceTypes';
  if (c.initiatorDomains && c.excludedInitiatorDomains) {
    const overlap = c.initiatorDomains.filter((d) => c.excludedInitiatorDomains.indexOf(d) !== -1);
    if (overlap.length) return 'initiatorDomains 与 excluded 重叠: ' + overlap[0];
  }
  if (r.action.type === 'redirect' && !r.action.redirect) return 'redirect 缺少 redirect 字段';
  // 模拟内核对个别合法外观的规则也拒绝（用于验证二分回退）
  if (c.urlFilter && c.urlFilter.indexOf('__rejectme__') !== -1) return '模拟内核拒绝该规则';
  return null;
}

const dnr = {
  MAX_NUMBER_OF_DYNAMIC_AND_SESSION_RULES: DYNAMIC_LIMIT,
  getDynamicRules(cb) { cb(JSON.parse(JSON.stringify(dynamicRules))); },
  updateDynamicRules(opts, cb) {
    let failure = null;
    try {
      if (opts.removeRuleIds && opts.removeRuleIds.length) {
        const rm = new Set(opts.removeRuleIds);
        dynamicRules = dynamicRules.filter((r) => !rm.has(r.id));
      }
      if (opts.addRules && opts.addRules.length) {
        if (dynamicRules.length + opts.addRules.length > DYNAMIC_LIMIT) {
          throw new Error('超出规则上限 (' + DYNAMIC_LIMIT + ')');
        }
        const ids = new Set(dynamicRules.map((r) => r.id));
        const accepted = [];
        for (const r of opts.addRules) {
          const err = validateRule(r);
          if (err) throw new Error('规则校验失败: ' + err + ' | ' + JSON.stringify(r).slice(0, 160));
          if (ids.has(r.id)) throw new Error('规则 ID 重复: ' + r.id);
          ids.add(r.id);
          accepted.push(r);
        }
        // 模拟 Chrome 的原子行为：校验全部通过才真正写入
        dynamicRules = dynamicRules.concat(accepted.map((r) => JSON.parse(JSON.stringify(r))));
      }
    } catch (e) {
      failure = e.message;
      rejectLog.push(e.message);
    }
    // 与真实实现一致：lastError 只在本次回调内有效
    chrome.runtime.lastError = failure ? { message: failure } : null;
    cb();
    chrome.runtime.lastError = null;
  },
};

/* ---------------- 组装 sandbox ---------------- */
const chrome = {
  runtime: { lastError: null },
  storage: { local: storageLocal },
  declarativeNetRequest: dnr,
};

function loadModule(rel) {
  const code = fs.readFileSync(path.join(ROOT, rel), 'utf8');
  const sandbox = { chrome, self: {}, console, Promise, Object, Array, JSON, Date, Math, String, Number, RegExp, Set, Error, setTimeout, clearTimeout };
  sandbox.self = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { filename: rel });
  return sandbox;
}

const sandbox = loadModule('src/lib/regex-engine.js');
loadModuleInto(sandbox, 'src/lib/filter-parser.js');
loadModuleInto(sandbox, 'src/lib/storage.js');
loadModuleInto(sandbox, 'src/lib/compiler.js');

function loadModuleInto(ctx, rel) {
  const code = fs.readFileSync(path.join(ROOT, rel), 'utf8');
  vm.runInContext(code, ctx, { filename: rel });
}

const S = sandbox.AdShieldStorage;
const C = sandbox.AdShieldCompiler;

/* ---------------- 开始测试 ---------------- */
(async function main() {
  console.log('\n=== AdShield 端到端测试 ===\n');

  const txt = path.join(ROOT, 'tools/.tmp/easylistchina.txt');
  if (!fs.existsSync(txt)) {
    console.log('缺少测试用规则文件 ' + txt + '（tests 可选，跳过）');
    process.exit(0);
  }
  const chinaText = fs.readFileSync(txt, 'utf8');
  const bigPath = path.join(ROOT, 'tools/.tmp/easylist.txt');
  const bigText = fs.existsSync(bigPath) ? fs.readFileSync(bigPath, 'utf8') : '';

  console.log('--- 场景 1：单列表编译 ---');
  store.clear();
  dynamicRules = [];
  rejectLog.length = 0;
  await S.setSettings(S.DEFAULT_SETTINGS);
  await S.setLists([{ id: 'cn', name: 'EasyList China', url: 'x', enabled: true }]);
  await S.set({ ['listText:cn']: chinaText });

  let info = await C.compileAll();
  check('动态规则成功下发', dynamicRules.length > 0, 'count=' + dynamicRules.length);
  check('无规则被拒绝', rejectLog.length === 0, rejectLog[0]);
  check('规则数 == 编译统计', dynamicRules.length === info.dynamicRules,
    dynamicRules.length + ' vs ' + info.dynamicRules);
  check('元素隐藏索引已落盘', Array.isArray(store.get('cosmeticIndex')) && store.get('cosmeticIndex').length > 100,
    'domains=' + (store.get('cosmeticIndex') || []).length);
  check('通用隐藏选择器已落盘', Array.isArray(store.get('cosmeticGeneric')) && store.get('cosmeticGeneric').length > 100,
    'generic=' + (store.get('cosmeticGeneric') || []).length);
  check('站点专属规则已落盘', (() => {
    const idx = store.get('cosmeticIndex') || [];
    return idx.some((d) => store.has('cosmeticDomain:' + d) && (store.get('cosmeticDomain:' + d).s || []).length > 0);
  })());
  check('通用选择器未超上限 8000', (store.get('cosmeticGeneric') || []).length <= 8000);

  const sampleDomain = (store.get('cosmeticIndex') || [])[0];
  check('站点规则结构完整', (() => {
    const b = store.get('cosmeticDomain:' + sampleDomain);
    return b && Array.isArray(b.s) && Array.isArray(b.e) && typeof b.ng === 'boolean';
  })(), sampleDomain);

  console.log('\n--- 场景 2：白名单优先级 ---');
  await S.setSettings(Object.assign({}, S.DEFAULT_SETTINGS, { whitelist: ['example.com'] }));
  info = await C.compileAll();
  const wlRules = dynamicRules.filter((r) => r.priority === 1000);
  check('白名单生成 2 条高优先级放行规则', wlRules.length === 2, 'count=' + wlRules.length);
  check('白名单规则独立于列表规则', wlRules.every((r) => r.action.type === 'allow'));
  check('全部规则仍合法', rejectLog.length === 0, rejectLog[0]);

  console.log('\n--- 场景 3：超出 30000 条上限时的取舍 ---');
  if (bigText) {
    store.clear();
    dynamicRules = [];
    rejectLog.length = 0;
    await S.setSettings(S.DEFAULT_SETTINGS);
    await S.setLists([
      { id: 'cn', name: 'EasyList China', enabled: true },
      { id: 'el', name: 'EasyList', enabled: true },
    ]);
    await S.set({ ['listText:cn']: chinaText, ['listText:el']: bigText });

    const t0 = Date.now();
    info = await C.compileAll();
    const elapsed = Date.now() - t0;
    const total = info.network.block + info.network.allow + info.network.redirect + info.network.truncated;
    check('规则总量确实超过上限', total > 30000, 'total=' + total);
    check('实际下发未超上限', dynamicRules.length <= 30000, 'count=' + dynamicRules.length);
    check('没有整批失败', rejectLog.length === 0, rejectLog[0]);
    check('记录了被取舍的规则数', info.network.truncated > 0, 'truncated=' + info.network.truncated);
    check('取舍数量守恒', info.network.block + info.network.allow + info.network.redirect === dynamicRules.length,
      (info.network.block + info.network.allow + info.network.redirect) + ' vs ' + dynamicRules.length);
    const allowKept = dynamicRules.filter((r) => r.action.type === 'allow').length;
    check('所有例外规则都被保留', allowKept === info.network.allow,
      allowKept + ' / ' + info.network.allow);
    check('编译耗时在可接受范围', elapsed < 30000, elapsed + 'ms');
    console.log('    (编译耗时 ' + elapsed + 'ms，下发 ' + dynamicRules.length + ' 条，取舍 ' + info.network.truncated + ' 条)');
  } else {
    console.log('  (跳过：未下载 easylist.txt)');
  }

  console.log('\n--- 场景 4：非法规则容错（二分回退） ---');
  store.clear();
  dynamicRules = [];
  rejectLog.length = 0;
  await S.setSettings(S.DEFAULT_SETTINGS);
  await S.setLists([{ id: 'bad', name: '含坏规则的列表', enabled: true }]);
  // 用一条 length 超限的 urlFilter 制造非法规则（Chrome 会整批拒绝）
  const lines = [];
  for (let i = 0; i < 500; i++) lines.push('||good' + i + '.example.com^');
  lines.push('||__rejectme__.example.com^');
  lines.push('||good-after-bad.example.com^');
  await S.set({ ['listText:bad']: lines.join('\n') });

  info = await C.compileAll();
  check('坏规则被单独丢弃而不是整批失败', rejectLog.length > 0, 'rejects=' + rejectLog.length);
  check('坏规则之前的好规则成功下发', dynamicRules.some((r) => r.condition.urlFilter === '||good0.example.com^'));
  check('坏规则之后的好规则也成功下发', dynamicRules.some((r) => r.condition.urlFilter === '||good-after-bad.example.com^'));
  check('好规则数量正确', dynamicRules.filter((r) => r.action.type === 'block').length === 501,
    'block=' + dynamicRules.filter((r) => r.action.type === 'block').length);
  check('被拒绝的规则确实没有下发',
    !dynamicRules.some((r) => (r.condition.urlFilter || '').indexOf('__rejectme__') !== -1));
  console.log('    (被拒绝批次数 ' + rejectLog.length + '，最终下发 ' + dynamicRules.length + ' 条)');

  console.log('\n--- 场景 5：关闭总开关 ---');
  await S.setSettings(Object.assign({}, S.DEFAULT_SETTINGS, { enabled: false }));
  info = await C.compileAll();
  check('关闭网络拦截后动态规则清空', dynamicRules.length === 0, 'count=' + dynamicRules.length);

  console.log('\n=== 结果：' + pass + ' 项通过，' + fail + ' 项失败 ===\n');
  process.exit(fail ? 1 : 0);
})().catch((e) => {
  console.error('测试异常：', e);
  process.exit(1);
});
