# -*- coding: utf-8 -*-
"""开发期自检：JS 语法校验 + manifest/规则 JSON 校验 + 规则解析器冒烟测试"""
import io
import json
import os
import re
import subprocess
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NODE = r"C:/Users/huhu/.workbuddy/binaries/node/versions/22.22.2-6/node.exe"

JS_FILES = [
    "src/lib/theme.js",
    "src/lib/regex-engine.js",
    "src/lib/filter-parser.js",
    "src/lib/storage.js",
    "src/lib/compiler.js",
    "src/lib/default-cosmetic.js",
    "src/lib/anti-detect-main.js",
    "src/lib/noop-adscript.js",
    "src/lib/live-rules.js",
    "src/background/service-worker.js",
    "src/content/cosmetic.js",
    "src/content/anti-detect.js",
    "src/content/live-block.js",
    "src/popup/popup.js",
    "src/options/options.js",
    "src/dashboard/dashboard.js",
]

JSON_FILES = ["manifest.json", "rules/builtin-rules.json", "rules/anti-detect-rules.json"]

fail = 0

for rel in JS_FILES:
    path = os.path.join(BASE, rel)
    r = subprocess.run([NODE, "--check", path], capture_output=True, text=True)
    if r.returncode == 0:
        print("OK   %s" % rel)
    else:
        fail += 1
        print("FAIL %s\n%s" % (rel, r.stderr.strip()))

for rel in JSON_FILES:
    path = os.path.join(BASE, rel)
    try:
        json.load(io.open(path, encoding="utf-8"))
        print("OK   %s" % rel)
    except Exception as exc:
        fail += 1
        print("FAIL %s -> %s" % (rel, exc))

# manifest 引用完整性
man = json.load(io.open(os.path.join(BASE, "manifest.json"), encoding="utf-8"))
for res in man["declarative_net_request"]["rule_resources"]:
    p = os.path.join(BASE, res["path"])
    print(("OK   " if os.path.exists(p) else "FAIL ") + res["path"])
    fail += 0 if os.path.exists(p) else 1
for item in man["content_scripts"][0]["js"]:
    p = os.path.join(BASE, item)
    print(("OK   " if os.path.exists(p) else "FAIL ") + item)
    fail += 0 if os.path.exists(p) else 1
for key in ("16", "32", "48", "128"):
    p = os.path.join(BASE, man["icons"][key])
    if not os.path.exists(p):
        fail += 1
        print("FAIL %s" % p)
print("OK   icons")

# 页面引用的本地 css/js/图片是否存在
print("\n--- 页面资源引用 ---")
import re
html_files = []
for root, dirs, names in os.walk(os.path.join(BASE, "src")):
    for n in names:
        if n.endswith(".html"):
            html_files.append(os.path.join(root, n))
for html_path in sorted(html_files):
    body = io.open(html_path, encoding="utf-8").read()
    refs = re.findall(r'(?:href|src)="([^"]+)"', body)
    for ref in refs:
        if ref.startswith(("http://", "https://", "data:", "#", "//", "mailto:",
                           "javascript:", "tel:", "blob:")):
            continue
        target = os.path.normpath(os.path.join(os.path.dirname(html_path), ref))
        rel_from_base = os.path.relpath(target, BASE).replace("\\", "/")
        if os.path.exists(target):
            print("OK   %s -> %s" % (os.path.relpath(html_path, BASE).replace("\\", "/"), rel_from_base))
        else:
            fail += 1
            print("FAIL %s -> %s (不存在)" % (os.path.relpath(html_path, BASE).replace("\\", "/"), rel_from_base))

# ---------------- CSS 令牌审计 ----------------
# 主题系统的坑几乎全在这里：CSS 里写了一个 var(--x)，但 deriveVars / :root 都没产出它，
# 浏览器会直接当无效值丢掉 → 元素变成透明底/黑字，也就是「配色崩坏」。
print("\n--- CSS 令牌审计 ---")

css_files = []
for root, dirs, names in os.walk(os.path.join(BASE, "src")):
    for n in names:
        if n.endswith(".css"):
            css_files.append(os.path.join(root, n))

def read(p):
    return io.open(p, encoding="utf-8").read()

defined = set()
# 1) CSS 里直接声明的（:root 兜底 + 各页面自己的局部变量）
for p in css_files:
    for m in re.finditer(r"(--[a-zA-Z0-9-]+)\s*:", read(p)):
        defined.add(m.group(1))
# 2) theme.js 里由算法产出的
theme_js = read(os.path.join(BASE, "src/lib/theme.js"))
for m in re.finditer(r"v\['(--[a-zA-Z0-9-]+)'\]", theme_js):
    defined.add(m.group(1))
for m in re.finditer(r"['\"](--[a-zA-Z0-9-]+)['\"]\s*:", theme_js):
    defined.add(m.group(1))

referenced = {}          # token -> [(file, has_fallback)]
for p in css_files + [h for h in html_files]:
    text = read(p)
    for m in re.finditer(r"var\(\s*(--[a-zA-Z0-9-]+)\s*(,)?", text):
        tok, fallback = m.group(1), bool(m.group(2))
        referenced.setdefault(tok, []).append(
            (os.path.relpath(p, BASE).replace("\\", "/"), fallback))

missing = {t: v for t, v in referenced.items()
           if t not in defined and not all(fb for _, fb in v)}
if missing:
    fail += len(missing)
    for tok in sorted(missing):
        files = ", ".join(sorted({f for f, _ in missing[tok]}))
        print("FAIL 未定义令牌 %s  <- %s" % (tok, files))
else:
    print("OK   %d 个引用令牌全部有定义（CSS 声明 %d 个 + theme.js 产出 %d 个）"
          % (len(referenced), len(defined), len(defined)))

# 反向：定义了却没人用（只是提醒，不算失败）
unused = sorted(t for t in defined if t not in referenced)
if unused:
    print("提示 有 %d 个已定义但未被引用的令牌：%s"
          % (len(unused), ", ".join(unused)))

# ---------------- 解析器冒烟测试 ----------------
SAMPLE = "\n".join([
    "[Adblock Plus 2.0]",
    "! 标题: 测试列表",
    "||ads.example.com^",
    "||ads2.example.com^$third-party,script",
    "@@||good.example.com^$script",
    "/banner\\d+/$image",
    "||track.example.com^$domain=shop.com|~sub.shop.com",
    "||prm.example.com^$removeparam=utm_source|utm_medium",
    "||nope.example.com^$csp=script-src none",
    "example.com##.ad-box",
    "example.com,test.cn##div.sponsor",
    "example.com#@#.ad-box",
    "##.generic-ad",
    "@@||allow.example.com^$generichide",
    "0.0.0.0 tracker.example.com",
    "127.0.0.1 another-tracker.net",
    "utm-tracker.io",
    "https://s3.example.com/ad/banner.png",
    "||重定向.cn^",
    "*$badfilter",
    # 正则规则
    "/track(ing)?\\d*\\.js/$script",
    "*$removeparam=/^(utm_.*|gclid)$/",
    "/(?=foo)bar/",
    "/(a/",
    # 文本匹配规则
    "example.com##div:has-text(/赞助|Sponsored/i)",
    "##div:contains(Sponsored)",
])

CASES = [
    "||ads.example.com^",
    "||ads2.example.com^$third-party,script",
    "@@||good.example.com^$script",
    "/banner\\d+/$image",
    "||track.example.com^$domain=shop.com|~sub.shop.com",
    "||prm.example.com^$removeparam=utm_source|utm_medium",
    "example.com##.ad-box",
    "example.com,test.cn##div.sponsor",
    "example.com#@#.ad-box",
    "##.generic-ad",
    "@@||allow.example.com^$generichide",
    "0.0.0.0 tracker.example.com",
    "utm-tracker.io",
    "! comment",
    "[Adblock Plus 2.0]",
    "||bad.com^$csp=script-src",
    "example.com#?#div:has(> .ad)",
    "example.com##+js(set-constant, ads, false)",
    "/track(ing)?\\d*\\.js/$script",
    "*$removeparam=/^(utm_.*|gclid)$/",
    "/(?=foo)bar/",
    "example.com##div:has-text(/赞助|Sponsored/i)",
    "##div:contains(Sponsored)",
]

smoke_tpl = r"""
global.self = global;
require(__REGEX_ENGINE__);
require(__FILTER_PARSER__);
const P = self.AdShieldParser;
const CASES = __CASES__;
console.log('--- 单行解析 ---');
for (const c of CASES) {
  const r = P.parseLine(c);
  const tag = r.kind === 'skip' ? 'skip    ' : r.kind.padEnd(8);
  console.log('  ' + tag + c);
  if (r.kind !== 'skip') console.log('           -> ' + JSON.stringify(r.data));
}
console.log('\n--- 整份列表解析 ---');
const SAMPLE = __SAMPLE__;
const list = P.parseList(SAMPLE);
console.log('  network=' + list.stats.network + '  cosmetic=' + list.stats.cosmetic + '  skipped=' + list.stats.skipped);
console.log('  generic 选择器: ' + JSON.stringify(list.cosmetic.generic));
console.log('  正则规则 ' + (list.stats.regex || 0) + ' 条 / 被拒正则 ' + (list.stats.regexRejected || 0) + ' 条 / 文本规则 ' + (list.stats.textRules || 0) + ' 条');
if (list.stats.reasons && Object.keys(list.stats.reasons).length) {
  console.log('  跳过原因: ' + JSON.stringify(list.stats.reasons));
}
console.log('  example.com 专属: ' + JSON.stringify(list.cosmetic.specific['example.com']));
console.log('  example.com 例外: ' + JSON.stringify(list.cosmetic.exceptions['example.com']));
console.log('  noGeneric 域名: ' + JSON.stringify(Object.keys(list.cosmetic.noGeneric)));

const rules = [];
let id = 1;
for (const r of list.network) {
  const d = P.toDnrRule(r, id++);
  if (d) rules.push(d);
}
console.log('\n--- DNR 规则转换 ---');
console.log('  可转换: ' + rules.length + ' / ' + list.network.length);
let bad = 0;
const seen = new Set();
for (const r of rules) {
  const c = r.condition;
  if (!c.urlFilter && !c.regexFilter) { bad++; console.log('  ! 缺少匹配条件: ' + JSON.stringify(r)); }
  if (c.urlFilter === '') { bad++; console.log('  ! 空 urlFilter'); }
  if (!c.resourceTypes || !c.resourceTypes.length) { bad++; console.log('  ! 缺少 resourceTypes'); }
  if (c.regexFilter && c.urlFilter) { bad++; console.log('  ! urlFilter 与 regexFilter 冲突'); }
  if (seen.has(r.id)) { bad++; console.log('  ! 规则 ID 重复: ' + r.id); }
  seen.add(r.id);
}
console.log('  非法规则数: ' + bad);
console.log('\n--- 抽样输出 ---');
rules.slice(0, 8).forEach(r => console.log('  ' + JSON.stringify(r)));
console.log('\n--- 内置静态规则集 ---');
const builtin = JSON.parse(require('fs').readFileSync(__BUILTIN__, 'utf8'));
const ids = new Set();
let bBad = 0;
for (const r of builtin) {
  if (ids.has(r.id)) bBad++;
  ids.add(r.id);
  if (!r.condition.urlFilter || !r.condition.resourceTypes.length) bBad++;
  if (r.priority < 1) bBad++;
}
console.log('  共 ' + builtin.length + ' 条, ID 唯一, 非法 ' + bBad + ' 条');
if (bad || bBad) process.exitCode = 2;
"""

smoke = smoke_tpl \
    .replace("__REGEX_ENGINE__", json.dumps(os.path.join(BASE, "src/lib/regex-engine.js").replace("\\", "/"), ensure_ascii=False)) \
    .replace("__FILTER_PARSER__", json.dumps(os.path.join(BASE, "src/lib/filter-parser.js").replace("\\", "/"), ensure_ascii=False)) \
    .replace("__CASES__", json.dumps(CASES, ensure_ascii=False)) \
    .replace("__SAMPLE__", json.dumps(SAMPLE, ensure_ascii=False)) \
    .replace("__BUILTIN__", json.dumps(os.path.join(BASE, "rules/builtin-rules.json").replace("\\", "/"), ensure_ascii=False))

out = io.open(os.path.join(BASE, "tools", ".smoke.js"), "w", encoding="utf-8")
out.write(smoke)
out.close()

r = subprocess.run([NODE, os.path.join(BASE, "tools", ".smoke.js")],
                   capture_output=True, text=True, encoding="utf-8")
print("\n--- 解析器冒烟测试 ---")
print(r.stdout)
if r.stderr:
    print("STDERR:", r.stderr[:3000])
    fail += 1
if r.returncode == 2:
    fail += 1

try:
    os.remove(os.path.join(BASE, "tools", ".smoke.js"))
except OSError:
    pass

# ---------------- 正则与文本规则专项测试 ----------------
print("\n--- 正则与文本规则专项测试 ---")
r2 = subprocess.run([NODE, os.path.join(BASE, "tools", "regex-test.js")],
                    capture_output=True, text=True, encoding="utf-8")
for line in (r2.stdout or "").strip().splitlines()[-4:]:
    print(line)
if r2.stderr:
    print("STDERR:", r2.stderr[:2000])
if r2.returncode != 0 or r2.stderr:
    fail += 1

# ---------------- 主题引擎专项测试 ----------------
print("\n--- 主题引擎专项测试 ---")
r3 = subprocess.run([NODE, os.path.join(BASE, "tools", "theme-test.js")],
                    capture_output=True, text=True, encoding="utf-8")
for line in (r3.stdout or "").strip().splitlines()[-4:]:
    print(line)
if r3.stderr:
    print("STDERR:", r3.stderr[:2000])
if r3.returncode != 0 or r3.stderr:
    fail += 1

# ---------------- 反广告拦截对抗规则集 ----------------
# 这套规则靠"优先级压过拦截规则"生效。一旦它低于编译器给导入规则分配的优先级，
# block 会抢先命中，重定向就静默失效了 —— 功能看着开着，实际一点用没有。
# 所以这里不去猜，直接从 compiler.js 里读真实优先级来对账。
print("\n--- 反广告拦截对抗规则集 ---")

AD_TYPES = {
    "main_frame", "sub_frame", "stylesheet", "script", "image", "font",
    "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket",
    "webtransport", "webbundle", "other",
}

ad_rules = json.load(io.open(os.path.join(BASE, "rules/anti-detect-rules.json"),
                             encoding="utf-8"))
comp_src = io.open(os.path.join(BASE, "src/lib/compiler.js"), encoding="utf-8").read()
comp_prios = [int(m) for m in re.findall(r"priority:\s*(\d+)", comp_src)]
comp_max = max(comp_prios) if comp_prios else 0

ad_bad = []
seen_ids = set()
prios = set()
for rule in ad_rules:
    rid = rule.get("id")
    if rid in seen_ids:
        ad_bad.append("id 重复: %s" % rid)
    seen_ids.add(rid)

    cond = rule.get("condition", {})
    if not cond.get("urlFilter"):
        ad_bad.append("#%s 缺少 urlFilter" % rid)
    for t in cond.get("resourceTypes", []):
        if t not in AD_TYPES:
            ad_bad.append("#%s 非法 resourceType: %s" % (rid, t))

    act = rule.get("action", {})
    if act.get("type") != "redirect":
        ad_bad.append("#%s action 应为 redirect，实际 %s" % (rid, act.get("type")))
    target = (act.get("redirect") or {}).get("extensionPath")
    if not target:
        ad_bad.append("#%s 缺少 redirect.extensionPath" % rid)
    elif not os.path.isfile(os.path.join(BASE, target.lstrip("/"))):
        ad_bad.append("#%s 重定向目标不存在: %s" % (rid, target))

    p = int(rule.get("priority", 0))
    prios.add(p)
    if p <= comp_max:
        ad_bad.append("#%s 优先级 %d 压不过编译器优先级 %d" % (rid, p, comp_max))

if not any(x["id"] == "anti_detect"
           for x in man["declarative_net_request"]["rule_resources"]):
    ad_bad.append("manifest 未注册 anti_detect 规则集")

print("  共 %d 条，优先级 %s（编译器为 %d），重定向目标就位，非法 %d 条"
      % (len(ad_rules), sorted(prios), comp_max, len(ad_bad)))
for msg in ad_bad:
    print("  FAIL %s" % msg)
if ad_bad:
    fail += 1

print("\n--- 直播内容推荐屏蔽 ---")

live_bad = []

# ① 规则库结构：用 node 真跑一遍，避免用正则去猜 JS 里的对象字面量。
live_probe = r'''
const fs = require('fs'), vm = require('vm');
const box = {}; box.self = box;
vm.runInNewContext(fs.readFileSync(process.argv[2], 'utf8'), box);
const R = box.AdShieldLiveRules;
if (!R || !Array.isArray(R.SITES)) { console.log('[]'); process.exit(0); }
console.log(JSON.stringify(R.SITES.map(s => ({
  id: s.id, name: s.name,
  hosts: s.hosts || [],
  liveHosts: s.liveHosts || [],
  liveRe: s.liveRe ? String(s.liveRe) : null,
  fixed: s.fixed || []
}))));
'''
probe_path = os.path.join(BASE, "tools", ".liveprobe.js")
io.open(probe_path, "w", encoding="utf-8").write(live_probe)
rp = subprocess.run([NODE, probe_path,
                     os.path.join(BASE, "src/lib/live-rules.js")],
                    capture_output=True, text=True, encoding="utf-8")
try:
    os.remove(probe_path)
except OSError:
    pass

try:
    live_sites = json.loads((rp.stdout or "[]").strip().splitlines()[-1])
except Exception as exc:                                   # noqa: BLE001
    live_sites = []
    live_bad.append("规则库无法求值: %s / %s" % (exc, (rp.stderr or "")[:200]))

if not live_sites:
    live_bad.append("规则库没有解析出任何站点")

seen_sites = set()
for s in live_sites:
    sid = s.get("id")
    if not sid:
        live_bad.append("存在没有 id 的站点")
    elif sid in seen_sites:
        live_bad.append("站点 id 重复: %s" % sid)
    seen_sites.add(sid)

    if not s.get("name"):
        live_bad.append("%s 缺少 name" % sid)
    if not s.get("hosts"):
        live_bad.append("%s 缺少 hosts（host 匹配不上就永远不会启用）" % sid)
    if not s.get("liveHosts") and not s.get("liveRe"):
        live_bad.append("%s 既没有 liveHosts 也没有 liveRe（等于永不命中）" % sid)

    # liveHosts 约定写成协议无关的 URL 片段，用 indexOf 比对，不区分 http/https
    for h in s.get("liveHosts") or []:
        if not h.startswith("//"):
            live_bad.append("%s 的 liveHosts 片段 '%s' 应以 '//' 开头" % (sid, h))

    # liveRe 必须是合法正则（写错了在浏览器里会直接抛，整库失效）
    if s.get("liveRe"):
        try:
            re.compile(s["liveRe"].strip("/"))
        except re.error as exc:                            # noqa: BLE001
            live_bad.append("%s 的 liveRe 非法: %s" % (sid, exc))

    # fixed 选择器必须能在 querySelectorAll 里用，不能是空串
    for sel in s.get("fixed") or []:
        if not str(sel).strip():
            live_bad.append("%s 的 fixed 含空选择器" % sid)

# ② 加载顺序：live-block.js 依赖 live-rules.js，顺序反了脚本会静默不工作。
for cs in man["content_scripts"]:
    js = cs.get("js") or []
    if "src/content/live-block.js" in js:
        if "src/lib/live-rules.js" not in js:
            live_bad.append("manifest 未给 live-block.js 带上 live-rules.js")
        elif js.index("src/lib/live-rules.js") > js.index("src/content/live-block.js"):
            live_bad.append("manifest 里 live-rules.js 排在 live-block.js 之后")
        if cs.get("run_at") != "document_start":
            live_bad.append("live-block.js 的 run_at 应为 document_start，"
                            "否则首屏直播卡片会先闪现")
        break
else:
    live_bad.append("manifest 未注册 src/content/live-block.js")

# ③ 开关默认关：它隐藏的是"内容"，不是广告，不该在用户没同意时改变页面
st_src = io.open(os.path.join(BASE, "src/lib/storage.js"), encoding="utf-8").read()
if not re.search(r"hideLive\s*:\s*false", st_src):
    live_bad.append("storage.js 里 hideLive 的默认值应为 false")

# ④ 切换开关不该触发规则重编译（它不走 DNR），否则每次点一下都要重建规则集
sw_src = io.open(os.path.join(BASE, "src/background/service-worker.js"),
                 encoding="utf-8").read()
m = re.search(r"NO_COMPILE_KEYS\s*=\s*\[([^\]]*)\]", sw_src)
if not m or "hideLive" not in m.group(1):
    live_bad.append("service-worker.js 的 NO_COMPILE_KEYS 未包含 hideLive")

# ⑤ 两个界面的开关控件必须真实存在（id 写错就是点了没反应）
for page, jsf, ctl in [
    ("src/popup/popup.html", "src/popup/popup.js", "btnLive"),
    ("src/options/options.html", "src/options/options.js", "optHideLive"),
]:
    html = io.open(os.path.join(BASE, page), encoding="utf-8").read()
    jsx = io.open(os.path.join(BASE, jsf), encoding="utf-8").read()
    if ('id="%s"' % ctl) not in html:
        live_bad.append("%s 缺少控件 id=%s" % (page, ctl))
    if ctl not in jsx:
        live_bad.append("%s 未引用控件 %s" % (jsf, ctl))

# ⑥ 测试夹具与被测脚本都得在，否则这套断言是空转
for rel in ["test/live-block.html", "tools/live-run.py"]:
    if not os.path.isfile(os.path.join(BASE, rel)):
        live_bad.append("缺少 %s" % rel)

print("  规则库 %d 个站点：%s"
      % (len(live_sites), "、".join(s.get("name") or "?" for s in live_sites)))
print("  manifest 加载顺序 / 默认关 / 免重编译 / 界面控件 / 测试夹具，非法 %d 项"
      % len(live_bad))
for msg in live_bad:
    print("  FAIL %s" % msg)
if live_bad:
    fail += 1

print("\n--- 后台浮动 Promise 兜底 ---")

rej_bad = []

# MV3 下 chrome.action / chrome.storage.session / chrome.tabs.create 等不传回调时
# 返回 Promise，失败会以「未处理拒绝」的形式冒到全局（典型报错见下面这行文本）。
# 这些调用基本都写在同步的 try/catch 里，拦不住微任务里的拒绝，必须显式兜住。
SW_PATH = os.path.join(BASE, "src/background/service-worker.js")
sw_src = io.open(SW_PATH, encoding="utf-8").read()

if "function swallow(" not in sw_src:
    rej_bad.append("service-worker.js 里没有 swallow() 兜底助手")

# 这条语句被反向对照测试当成改写点，改了会让 sw-reject-test.js 丧失灵敏度
if "p.then(null, function () { /* 标签页/窗口已关闭，或存储配额触及——忽略 */ });" not in sw_src:
    rej_bad.append("swallow() 的拒绝处理语句被改动，sw-reject-test.js 的反向对照会失效")

# 逐条核对：凡是可能返回 Promise 的 chrome API 调用，必须被 swallow( 包住
GUARDED_CALLS = [
    "chrome.action.setBadgeText(",
    "chrome.action.setBadgeBackgroundColor(",
    "chrome.action.setBadgeTextColor(",
    "chrome.tabs.create(",
    "chrome.storage.session.set(",
    "chrome.runtime.openOptionsPage(",
]
for call in GUARDED_CALLS:
    total = sw_src.count(call)
    guarded = len(re.findall(r"swallow\(\s*" + re.escape(call), sw_src))
    if total != guarded:
        rej_bad.append("%s 共 %d 处，其中仅 %d 处被 swallow() 兜住"
                       % (call, total, guarded))
    elif total == 0:
        rej_bad.append("%s 一处都没有，自检规则可能已过期" % call)

# 把「调用处写了 try/catch 但没 await」这种假兜底也揪出来。
# 注意匹配是从 chrome. 开始的，所以判据要看匹配位置**前面**是不是 swallow(。
for m in re.finditer(r"chrome\.(action|tabs|runtime|storage)\.\w+\([^;]*\);", sw_src):
    if sw_src[max(0, m.start() - 8):m.start()] == "swallow(":
        continue
    stmt = m.group(0)
    if "await " in stmt or "void " in stmt:
        continue
    if "function (" in stmt or "callback" in stmt:
        continue          # 带回调的调用不会返回 Promise，安全
    rej_bad.append("可能存在未兜住的浮动 Promise: %s" % stmt[:90])

# 回归测试必须在位，并且真的能跑通
REJ_TEST = os.path.join(BASE, "tools/sw-reject-test.js")
if not os.path.isfile(REJ_TEST):
    rej_bad.append("缺少 tools/sw-reject-test.js")
else:
    rt = subprocess.run([NODE, REJ_TEST], capture_output=True, text=True,
                        encoding="utf-8", cwd=BASE)
    if rt.returncode != 0:
        rej_bad.append("sw-reject-test.js 未通过:\n%s" % (rt.stdout or "")[-800:])
    else:
        m = re.search(r"全部通过（(\d+) 通过", rt.stdout or "")
        print("  sw-reject-test：%s 项断言通过" % (m.group(1) if m else "?"))

print("  兜底调用 %d 类，非法 %d 项"
      % (len(GUARDED_CALLS), len(rej_bad)))
for msg in rej_bad:
    print("  FAIL %s" % msg)
if rej_bad:
    fail += 1

print("\n--- 隐私政策与用户协议页 ---")

pv_bad = []
PV = os.path.join(BASE, "src/privacy/privacy.html")

if not os.path.isfile(PV):
    pv_bad.append("缺少 src/privacy/privacy.html")
else:
    pv = io.open(PV, encoding="utf-8").read()

    # ① 版本号必须和 manifest 对得上，别出现「扩展 1.4.1、政策 1.4.0」
    if man["version"] not in pv:
        pv_bad.append("页面未标注当前版本 %s" % man["version"])

    # ② 页面声明生效的那一天不能是未来日期（防止复制粘贴忘改）
    #    先剥标签：文案里「生效日期：」和日期之间夹着 <b> 之类的标记
    pv_text = re.sub(r"<[^>]+>", "", pv)
    if not re.search(r"生效日期[：:]\s*\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日", pv_text):
        pv_bad.append("缺少格式正确的「生效日期」")

    # ③ 权限逐条说明必须覆盖 manifest 里的每一项，双向核对，防止漏写或写多
    for perm in man.get("permissions", []):
        if ("<code>%s</code>" % perm) not in pv:
            pv_bad.append("页面未说明权限 %s" % perm)
    for hp in man.get("host_permissions", []):
        label = hp.replace("<", "&lt;").replace(">", "&gt;")
        if label not in pv:
            pv_bad.append("页面未说明 host 权限 %s" % hp)

    # ④ 申请了却没用到的权限（说明文档或 manifest 有一边是错的）
    #    权限名本身不会作为字符串出现在代码里，要对到它解锁的那个 API 命名空间。
    #    这一条能挡住「manifest 里申请了一堆权限，代码里根本没用」——应用商店审核
    #    最反感的就是这个，而权限说明写不实同样是隐私合规问题。
    src_all = ""
    for root, _dirs, names in os.walk(os.path.join(BASE, "src")):
        if os.sep + "privacy" in root:
            continue                      # 隐私页里的说明文字不算使用点
        for n in names:
            if n.endswith((".js", ".html")):
                src_all += io.open(os.path.join(root, n), encoding="utf-8",
                                   errors="ignore").read()

    PERM_API = {
        "declarativeNetRequest": "chrome.declarativeNetRequest",
        "declarativeNetRequestFeedback": "getMatchedRules",
        "storage": "chrome.storage",
        "unlimitedStorage": "chrome.storage",
        "activeTab": "chrome.tabs.query",
        "scripting": "chrome.scripting",
        "alarms": "chrome.alarms",
    }
    for perm in man.get("permissions", []):
        api = PERM_API.get(perm)
        if api is None:
            pv_bad.append("权限 %s 没有登记对应的 API，无法核对" % perm)
        elif api not in src_all:
            pv_bad.append("权限 %s 对应的 %s 在代码里找不到，文档说明可能不实"
                          % (perm, api))

    # ⑤ 自包含：作为独立网站托管时不能引用任何外部资源
    ext = re.findall(r"""(?:src|href)\s*=\s*["'](?:https?:)?//""", pv)
    if ext:
        pv_bad.append("页面引用了外部资源，无法离线/独立托管：%d 处" % len(ext))

    # ⑤b 在扩展里打开时会条件加载主题引擎，这三个文件必须真的在
    for rel in ('../lib/theme.css', '../lib/storage.js', '../lib/theme.js'):
        if ("'" + rel + "'") in pv or ('"' + rel + '"') in pv:
            target = os.path.normpath(os.path.join(BASE, "src/privacy", rel))
            if not os.path.isfile(target):
                pv_bad.append("条件加载的 %s 不存在" % rel)
        else:
            pv_bad.append("页面未引用 %s，扩展内将无法跟随用户配色" % rel)

    # ⑥ 深浅色都要有兜底令牌，否则系统深色下会亮瞎眼
    if "prefers-color-scheme: dark" not in pv:
        pv_bad.append("缺少深色模式媒体查询")
    for tok in ("--bg", "--surface", "--ink", "--ink-2", "--line", "--brand"):
        if pv.count(tok + ":") < 2:
            pv_bad.append("令牌 %s 没有同时提供浅色与深色两套值" % tok)

    # ⑦ 结构完整性：标签必须闭合，且正文不能被人截断
    from html.parser import HTMLParser

    class _Chk(HTMLParser):
        VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input",
                "link", "meta", "param", "source", "track", "wbr"}

        def __init__(self):
            HTMLParser.__init__(self, convert_charrefs=True)
            self.stack = []
            self.errs = []

        def handle_starttag(self, tag, attrs):
            if tag not in self.VOID:
                self.stack.append(tag)

        def handle_endtag(self, tag):
            if tag in self.VOID:
                return
            if not self.stack:
                self.errs.append("多余的 </%s>" % tag)
            elif self.stack.pop() != tag:
                self.errs.append("</%s> 闭合错位" % tag)

    chk = _Chk()
    chk.feed(pv)
    if chk.stack:
        pv_bad.append("标签未闭合: %s" % ", ".join(chk.stack[:6]))
    if chk.errs:
        pv_bad.append("标签错误: %s" % "; ".join(chk.errs[:4]))

    # ⑧ 目录里的锚点必须都有对应章节，否则点了不跳
    anchors = re.findall(r'<a href="#([\w-]+)"', pv)
    ids = set(re.findall(r'<section class="doc" id="([\w-]+)"', pv)) | \
        set(re.findall(r'<div class="quick" id="([\w-]+)"', pv))
    missing = [a for a in anchors if a not in ids]
    if missing:
        pv_bad.append("目录锚点找不到对应章节: %s" % ", ".join(sorted(set(missing))))

    # ⑨ 设置页得给个入口，否则用户根本进不来
    opt = io.open(os.path.join(BASE, "src/options/options.html"), encoding="utf-8").read()
    if "../privacy/privacy.html" not in opt:
        pv_bad.append("设置页没有指向隐私政策页的链接")

print("  权限 %d 项 / host 权限 %d 项 双向核对，非法 %d 项"
      % (len(man.get("permissions", [])), len(man.get("host_permissions", [])),
         len(pv_bad)))
for msg in pv_bad:
    print("  FAIL %s" % msg)
if pv_bad:
    fail += 1

print("==> %s" % ("全部通过" if fail == 0 else "存在 %d 个问题" % fail))
sys.exit(1 if fail else 0)
