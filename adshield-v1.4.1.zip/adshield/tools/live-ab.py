# -*- coding: utf-8 -*-
"""把"屏蔽前 / 屏蔽后"两张截图拼成一张左右对比图。

图来自 tools/live-e2e.py：先跑 `--off` 拍到基线，再用 `--scroll <y>` 拍屏蔽后，
两张图是同一滚动位置，所以可以直接并排比。

用法：
  python tools/live-ab.py 前图.png 后图.png 输出.png [裁剪起y] [裁剪高度]
"""
import os
import sys

from PIL import Image, ImageDraw, ImageFont

FONTS = [
    r"C:\Windows\Fonts\msyhbd.ttc",
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
]

OK = (26, 157, 92)       # 绿：屏蔽后
NG = (214, 59, 59)       # 红：屏蔽前


def font(size):
    for p in FONTS:
        if os.path.isfile(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:                                  # noqa: BLE001
                pass
    return ImageFont.load_default()


def main():
    if len(sys.argv) < 4:
        print(__doc__)
        return 2

    before = Image.open(sys.argv[1]).convert("RGB")
    after = Image.open(sys.argv[2]).convert("RGB")
    out = sys.argv[3]
    top = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    height = int(sys.argv[5]) if len(sys.argv) > 5 else 560

    def crop(im):
        w, h = im.size
        y0 = max(0, min(top, h - 10))
        y1 = max(y0 + 10, min(y0 + height, h))
        return im.crop((0, y0, w, y1))

    b, a = crop(before), crop(after)
    gap, pad, head, cap = 26, 22, 62, 40
    cw = b.width + a.width + gap
    ch = max(b.height, a.height)

    canvas = Image.new("RGB", (cw + pad * 2, ch + head + cap + pad * 2), (246, 247, 250))
    d = ImageDraw.Draw(canvas)

    d.text((pad, pad - 4), "AdShield v1.4.0 · 直播内容推荐屏蔽（真实哔哩哔哩搜索结果页）",
           font=font(21), fill=(31, 36, 48))
    d.text((pad, pad + 26), "同一滚动位置；判定依据是「卡片里的链接是否指向直播域」，不是类名",
           font=font(14), fill=(120, 128, 148))

    y = pad + head
    canvas.paste(b, (pad, y))
    canvas.paste(a, (pad + b.width + gap, y))
    d.rectangle([pad - 1, y - 1, pad + b.width, y + b.height], outline=(224, 226, 234))
    d.rectangle([pad + b.width + gap - 1, y - 1,
                 pad + b.width + gap + a.width, y + a.height], outline=(224, 226, 234))

    ty = y + b.height + 10
    d.text((pad, ty), "○ 屏蔽前：直播卡片照常显示", font=font(15), fill=NG)
    d.text((pad + b.width + gap, ty), "● 屏蔽后：带直播链接的卡片整块移除",
           font=font(15), fill=OK)

    canvas.save(out)
    print("已生成: %s  (%dx%d)" % (out, canvas.width, canvas.height))
    return 0


if __name__ == "__main__":
    sys.exit(main())
