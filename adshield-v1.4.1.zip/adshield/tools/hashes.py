# -*- coding: utf-8 -*-
"""为分发包生成校验值文件（分发包摘要 + 包内逐文件 SHA-256）。

用法：
  python tools/hashes.py "新增：xxx"      # 附加一行版本说明
  python tools/hashes.py                  # 不写说明行

输出到扩展目录的上一级，形如 adshield-v1.4.0.SHA256SUMS.txt，
包内逐文件哈希直接读 zip 内容（而不是读磁盘），这样和用户拿到的东西一致。
"""
import hashlib
import io
import json
import os
import sys
import zipfile

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.dirname(BASE)


def digest(name, data):
    h = hashlib.new(name)
    h.update(data)
    return h.hexdigest()


def main():
    man = json.load(io.open(os.path.join(BASE, "manifest.json"), encoding="utf-8"))
    ver = man["version"]
    zip_path = os.path.join(OUT_DIR, "adshield-v%s.zip" % ver)
    if not os.path.isfile(zip_path):
        print("找不到分发包: %s\n请先跑 python tools/pack.py" % zip_path)
        return 1

    raw = open(zip_path, "rb").read()
    size = len(raw)

    entries = []
    with zipfile.ZipFile(zip_path) as z:
        for name in sorted(z.namelist()):
            if name.endswith("/"):
                continue
            entries.append((name, digest("sha256", z.read(name))))

    lines = []
    lines.append("AdShield 净网卫士 v%s  校验值" % ver)
    lines.append("=" * 72)
    lines.append("")
    lines.append("分发包: adshield-v%s.zip" % ver)
    lines.append("大小:   %.1f KB (%d 字节)" % (size / 1024.0, size))
    lines.append("文件数: %d" % len(entries))
    note = sys.argv[1].strip() if len(sys.argv) > 1 else ""
    if note:
        lines.append("说明:   %s" % note)
    lines.append("")
    lines.append("SHA-256  %s" % digest("sha256", raw))
    lines.append("SHA-512  %s" % digest("sha512", raw))
    lines.append("BLAKE2s  %s" % digest("blake2s", raw))
    lines.append("BLAKE2b  %s" % digest("blake2b", raw))
    lines.append("SHA-1    %s" % digest("sha1", raw))
    lines.append("MD5      %s" % digest("md5", raw))
    lines.append("")
    lines.append("校验方式：")
    lines.append("  Windows  certutil -hashfile adshield-v%s.zip SHA256" % ver)
    lines.append("  Linux    sha256sum -c adshield-v%s.SHA256SUMS.txt" % ver)
    lines.append("  macOS    shasum -a 256 adshield-v%s.zip" % ver)
    lines.append("")
    lines.append("")
    lines.append("# 包内每个文件的 SHA-256（%d 个）" % len(entries))
    for name, h in entries:
        lines.append("%s  %s" % (h, name))

    out_path = os.path.join(OUT_DIR, "adshield-v%s.SHA256SUMS.txt" % ver)
    io.open(out_path, "w", encoding="utf-8", newline="\n").write("\n".join(lines) + "\n")

    print("已生成: %s" % out_path)
    print("分发包 SHA-256: %s" % digest("sha256", raw))
    print("包内文件 %d 个，摘要 %d 行" % (len(entries), len(entries)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
