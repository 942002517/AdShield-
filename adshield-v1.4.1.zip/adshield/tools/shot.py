# -*- coding: utf-8 -*-
"""用 Edge 的 CDP 协议批量给主题预览页截图（开发用，不进打包）。

用法：
  1) 先起本地服务器：python -m http.server 8791 --bind 127.0.0.1
  2) 以调试端口起 Edge：
     msedge.exe --headless=new --remote-debugging-port=9333 --user-data-dir=<tmp>
  3) python tools/shot.py <port> <base_url> <out_dir> [case ...]

每个 case 形如  name:preset:extraQuery
  例： 01-default:default
       02-midnight:midnight
       13-radius0:default:radius=0
"""
import base64
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request

# 本机回环不要走系统代理（否则 /json/* 会被代理拦成 502）
for _k in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy",
           "all_proxy", "NO_PROXY", "no_proxy"):
    os.environ.pop(_k, None)
os.environ["NO_PROXY"] = "127.0.0.1,localhost"
os.environ["no_proxy"] = "127.0.0.1,localhost"

import websocket

_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

EDGE_CANDIDATES = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]


def find_browser():
    for p in EDGE_CANDIDATES:
        if os.path.isfile(p):
            return p
    raise RuntimeError("未找到 Edge / Chrome 可执行文件")


# ---------------------------------------------------------------------------
# 停机：必须按 --user-data-dir 反查真实进程，只 terminate(proc) 是不够的。
#
# Windows 上 Edge/Chrome 会"重新启动自己"（命令行里能看到
# --edge-skip-compat-layer-relaunch）：我们 Popen 拿到的那个启动器会先把
# 命令行交给真正的浏览器进程，然后自己退出。于是 proc 变成已退出的空壳，
# terminate() 打空，真正的浏览器连同渲染/GPU/网络等子进程全部变成孤儿。
#
# 后果很具体：
#   · 孤儿进程占着 --user-data-dir 的文件锁，下一轮的 rmtree(profile) 会失败
#   · 残留攒多了以后，新的浏览器启动时直接交棒给已有实例然后立刻退出，
#     表现为难以理解的"浏览器启动即退出 exit=0"
# 所以停机一律走"按 profile 路径匹配进程 → 连子树一起杀"。
# ---------------------------------------------------------------------------

_IMG = "msedge.exe", "chrome.exe"


def _pids_for_profile(profile_dir):
    """反查命令行里带该 --user-data-dir 的浏览器进程（含子进程）。"""
    if os.name != "nt" or not profile_dir:
        return set()
    # 注意：这里是 PowerShell **单引号**字符串，反斜杠是字面量，不要再转义一次。
    # 写 .replace("\\", "\\\\") 会让模式要求命令行里出现双反斜杠，永远匹配不上。
    pat = os.path.abspath(profile_dir)
    names = " or ".join("Name='%s'" % n for n in _IMG)
    script = (
        "Get-CimInstance Win32_Process -Filter \"%s\" | "
        "Where-Object { $_.CommandLine -like '*%s*' } | "
        "ForEach-Object { $_.ProcessId }" % (names, pat)
    )
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                           capture_output=True, text=True, timeout=25)
    except Exception:                                          # noqa: BLE001
        return set()
    out = set()
    for line in (r.stdout or "").splitlines():
        line = line.strip()
        if line.isdigit():
            out.add(int(line))
    return out


def _kill_tree(pid):
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(pid)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
        else:
            os.kill(pid, 15)
    except Exception:                                          # noqa: BLE001
        pass


def stop_browser(proc, profile_dir=None, timeout=20):
    """停掉浏览器整棵进程树；启动器已退出时按 profile 反查真实进程。"""
    pids = _pids_for_profile(profile_dir)
    if proc is not None and proc.poll() is None:
        pids.add(proc.pid)
    for pid in pids:
        _kill_tree(pid)
    if proc is not None:
        try:
            proc.wait(timeout=timeout)
        except Exception:                                      # noqa: BLE001
            try:
                proc.kill()
            except Exception:                                  # noqa: BLE001
                pass
    # 第二轮：交棒之后新起来的进程可能不在第一次的名单里
    for pid in _pids_for_profile(profile_dir):
        _kill_tree(pid)


def cleanup_profile(profile_dir):
    """清掉该 profile 上的孤儿浏览器进程，然后重建空目录。

    自定义启动参数（比如要 --load-extension）的脚本用这个，替代裸 rmtree：
    rmtree 在有孤儿进程占锁时会被静默 ignore_errors 吞掉，profile 没清成，
    于是新浏览器起来后读到的还是上一轮的扩展登记与设置。
    """
    for pid in _pids_for_profile(profile_dir):
        _kill_tree(pid)
    if os.path.isdir(profile_dir):
        shutil.rmtree(profile_dir, ignore_errors=True)
    os.makedirs(profile_dir, exist_ok=True)


def start_browser(port, profile_dir):
    # --user-data-dir 必须是绝对路径：Edge 会把命令行交棒给新进程，那个进程的
    # 工作目录不一定是我们的，相对路径会被解析到别处，浏览器起来即退。
    profile_dir = os.path.abspath(profile_dir)
    cleanup_profile(profile_dir)
    exe = find_browser()
    args = [
        exe,
        "--headless=new",
        "--no-sandbox",
        "--disable-gpu",
        "--disable-dev-shm-usage",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-sync",
        "--disable-extensions",
        "--disable-background-networking",
        "--user-data-dir=" + profile_dir,
        "--remote-debugging-port=%d" % port,
        "--remote-allow-origins=*",
        "--window-size=1240,900",
        "about:blank",
    ]
    proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return wait_cdp(port, proc, profile_dir)


def wait_cdp(port, proc, profile_dir=None, timeout=40):
    """等 CDP 端口就绪。

    不要拿"启动器进程是否还活着"当判据 —— 不带 --load-extension 时，Edge 会把
    命令行交给真正的浏览器进程然后自己退出（exit=0），这是正常的交棒，不是失败。
    只认端口：端口通了就算起来了，超时才算失败。
    """
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        try:
            http_json(port, "/json/version")
            return proc
        except Exception as e:  # noqa: BLE001
            last = e
        time.sleep(0.5)
    alive = _pids_for_profile(profile_dir) if profile_dir else set()
    raise RuntimeError("等待 CDP 端口超时：%s（profile 上仍存活进程 %d 个）" % (last, len(alive)))


class CDP:
    def __init__(self, ws_url):
        self.ws = websocket.create_connection(ws_url, timeout=60, max_size=200 * 1024 * 1024)
        self._id = 0
        self.pending = {}

    def send(self, method, params=None, session_id=None):
        self._id += 1
        mid = self._id
        msg = {"id": mid, "method": method, "params": params or {}}
        if session_id:
            msg["sessionId"] = session_id
        self.ws.send(json.dumps(msg))
        while True:
            raw = self.ws.recv()
            data = json.loads(raw)
            if data.get("id") == mid:
                if "error" in data:
                    raise RuntimeError(method + " -> " + json.dumps(data["error"]))
                return data.get("result", {})
            # 忽略事件
        # unreachable

    def close(self):
        try:
            self.ws.close()
        except Exception:
            pass


def http_json(port, path):
    with _opener.open("http://127.0.0.1:%d%s" % (port, path), timeout=20) as r:
        return json.loads(r.read().decode("utf-8"))


def parse_cases(argv):
    out = []
    for a in argv:
        parts = a.split(":")
        name = parts[0]
        preset = parts[1] if len(parts) > 1 and parts[1] else "default"
        extra = parts[2] if len(parts) > 2 else ""
        out.append((name, preset, extra))
    return out


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9333
    base = sys.argv[2] if len(sys.argv) > 2 else "http://127.0.0.1:8791"
    out_dir = sys.argv[3] if len(sys.argv) > 3 else "tools/.tmp/shots"
    cases = parse_cases(sys.argv[4:])
    if not cases:
        cases = [("preview", "default", "")]

    os.makedirs(out_dir, exist_ok=True)

    profile_dir = os.path.join(out_dir, "..", "cdpprofile")
    profile_dir = os.path.abspath(profile_dir)
    proc = start_browser(port, profile_dir)
    print("browser up, pid=%d" % proc.pid)

    try:
        run_shots(port, base, out_dir, cases)
    finally:
        stop_browser(proc, profile_dir)


def run_shots(port, base, out_dir, cases):
    width = 1240
    height = 900
    results = []

    ver = http_json(port, "/json/version")
    browser_ws = ver["webSocketDebuggerUrl"]
    cdp = CDP(browser_ws)

    for name, preset, extra in cases:
        # 允许用 w=/h= 覆盖视口（popup 要窄一点）
        vw, vh = width, height
        for part in (extra or "").split("&"):
            if part.startswith("w="):
                vw = int(part[2:])
            elif part.startswith("h="):
                vh = int(part[2:])

        t = cdp.send("Target.createTarget", {"url": "about:blank"})
        tid = t["targetId"]
        att = cdp.send("Target.attachToTarget", {"targetId": tid, "flatten": True})
        sid = att["sessionId"]

        cdp.send("Page.enable", {}, sid)
        cdp.send("Runtime.enable", {}, sid)
        cdp.send("Emulation.setDeviceMetricsOverride",
                 {"width": vw, "height": vh, "deviceScaleFactor": 1,
                  "mobile": False}, sid)

        q = ["preset=" + preset]
        page_path = "/tools/theme-preview.html"
        for part in (extra or "").split("&"):
            if part.startswith("path="):
                page_path = part[5:]
                continue
            if part:
                q.append(part)
        url = base + page_path + "?" + "&".join(q) + "#theme"

        # 开发服务器偶发抖动会让预览页挂掉，整体重试最多 4 次
        ready = False
        ready_expr = ("(function(){var h=document.getElementById('host');"
                      "if(!h){return document.readyState==='complete'"
                      " && !Array.prototype.some.call(document.images,"
                      "function(im){return !im.complete;});}"
                      "if(!h.firstElementChild)return false;"
                      "var s=h.firstElementChild.getAttribute('style')||'';"
                      "if(s.indexOf('padding:20px')!==-1)return false;"
                      "var pg=new URLSearchParams(location.search).get('page')||'dashboard';"
                      "if(pg==='dashboard')return !!document.querySelector('#host #panel-theme.active');"
                      "return true;})()")
        for attempt in range(4):
            cdp.send("Page.navigate", {"url": url}, sid)
            deadline = time.time() + 25
            while time.time() < deadline:
                time.sleep(0.4)
                r = cdp.send("Runtime.evaluate", {
                    "expression": ready_expr, "returnByValue": True}, sid)
                if r.get("result", {}).get("value"):
                    ready = True
                    break
            if ready:
                break
            time.sleep(0.6)
        time.sleep(1.0)

        # 量一下内容高度
        hr = cdp.send("Runtime.evaluate", {
            "expression": "Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)",
            "returnByValue": True}, sid)
        full_h = int(hr.get("result", {}).get("value") or 2600)
        full_h = max(300, min(full_h, 6000))

        # 支持 extra 里带 clip=x,y,w,h&scale=N 做局部放大核对
        clip = {"x": 0, "y": 0, "width": width, "height": full_h, "scale": 1}
        for part in (extra or "").split("&"):
            if part.startswith("clip="):
                nums = [float(v) for v in part[5:].split(",")]
                clip.update({"x": nums[0], "y": nums[1],
                             "width": nums[2], "height": nums[3]})
            elif part.startswith("scale="):
                clip["scale"] = float(part[6:])
        if "clip" not in (extra or ""):
            clip["width"] = vw

        shot = cdp.send("Page.captureScreenshot",
                        {"format": "png", "captureBeyondViewport": True,
                         "clip": clip}, sid)
        path = os.path.join(out_dir, name + ".png")
        with open(path, "wb") as f:
            f.write(base64.b64decode(shot["data"]))
        results.append({"name": name, "preset": preset, "ready": ready,
                        "h": full_h, "file": path})
        print("%-16s preset=%-11s ready=%s h=%d -> %s" % (name, preset, ready, full_h, path))

        cdp.send("Target.closeTarget", {"targetId": tid})

    cdp.close()
    with open(os.path.join(out_dir, "_index.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print("done: %d shots" % len(results))


if __name__ == "__main__":
    main()
