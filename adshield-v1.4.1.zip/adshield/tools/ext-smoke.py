# -*- coding: utf-8 -*-
"""扩展级冒烟测试：真的把扩展装进无头浏览器，验证注入与网络重定向确实生效。

页面内的有效性测试（test/anti-detect.html）是手动引入脚本的，
证明不了「manifest 里 world:"MAIN" 的声明式注入」「declarativeNetRequest
重定向诱饵脚本」这两条真实链路。这个脚本专门盯这两件事。

用法：python tools/ext-smoke.py
"""
import json
import os
import subprocess
import sys
import time
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shot import (CDP, http_json, find_browser,  # noqa: E402
                  cleanup_profile, stop_browser, wait_cdp)

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB_PORT = 8795          # 用来当"普通网站"的静态服务器
CDP_PORT = 9335
PY = sys.executable

checks = []


def rec(name, ok, detail=""):
    checks.append((name, ok, detail))
    print("  %s %s%s" % ("PASS" if ok else "FAIL", name,
                         ("   " + detail) if detail else ""))


def wait_http(port, path, timeout=20):
    deadline = time.time() + timeout
    req = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    while time.time() < deadline:
        try:
            with req.open("http://127.0.0.1:%d%s" % (port, path), timeout=2) as r:
                if r.status < 500:
                    return True
        except Exception:
            time.sleep(0.4)
    return False


def start_web(port):
    proc = subprocess.Popen(
        [PY, os.path.join(BASE, "tools", "devserver.py"), str(port), BASE],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not wait_http(port, "/manifest.json"):
        raise RuntimeError("静态服务器未就绪")
    return proc


def start_ext_browser(port, profile):
    cleanup_profile(profile)
    exe = find_browser()
    args = [
        exe, "--headless=new", "--no-sandbox", "--disable-gpu",
        "--disable-dev-shm-usage", "--no-first-run", "--no-default-browser-check",
        "--disable-sync", "--disable-background-networking",
        "--user-data-dir=" + profile,
        "--remote-debugging-port=%d" % port,
        "--remote-allow-origins=*",
        "--load-extension=" + BASE,          # 关键：真装扩展
        "--window-size=1240,900",
        "about:blank",
    ]
    proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    wait_cdp(port, proc, profile)
    time.sleep(3)              # 给 MV3 service worker 一点注册时间
    return proc


def ev(cdp, sid, expr):
    r = cdp.send("Runtime.evaluate",
                 {"expression": expr, "returnByValue": True, "awaitPromise": True}, sid)
    return r.get("result", {}).get("value")


def main():
    print("启动静态服务器 :%d" % WEB_PORT)
    web = start_web(WEB_PORT)

    out_dir = os.path.join(BASE, "tools", ".tmp", "extsmoke")
    os.makedirs(out_dir, exist_ok=True)
    print("启动带扩展的浏览器 :%d" % CDP_PORT)
    br = start_ext_browser(CDP_PORT, os.path.join(out_dir, "profile"))

    code = 3
    try:
        ver = http_json(CDP_PORT, "/json/version")
        cdp = CDP(ver["webSocketDebuggerUrl"])

        t = cdp.send("Target.createTarget", {"url": "about:blank"})
        tid = t["targetId"]
        sid = cdp.send("Target.attachToTarget",
                       {"targetId": tid, "flatten": True})["sessionId"]
        cdp.send("Page.enable", {}, sid)
        cdp.send("Runtime.enable", {}, sid)

        # 用一个普通页面（不是测试页）验证注入，避免页面自己引入脚本造成假阳性
        url = "http://127.0.0.1:%d/README.md" % WEB_PORT
        cdp.send("Page.navigate", {"url": url}, sid)
        time.sleep(3)

        rec("主世界欺骗层已注入（window.__adShieldAntiDetect）",
            bool(ev(cdp, sid, "!!window.__adShieldAntiDetect")),
            str(ev(cdp, sid, "window.__adShieldAntiDetect ? "
                             "'version=' + window.__adShieldAntiDetect.version : '缺失'")))

        # 隔离世界的变量不会出现在主世界（这本身就是隔离的意义），
        # 所以改看它留在 DOM 上的产物：cosmetic.js 注入的元素隐藏样式表
        has_style = ev(cdp, sid,
                       "!!document.getElementById('__adshield_style__')")
        rec("隔离世界内容脚本已运行（元素隐藏样式已注入）", bool(has_style),
            "找到 style#__adshield_style__" if has_style else "未找到")

        # 真正的判据：原地造一个被隐藏的诱饵，量它的尺寸
        probe = ev(cdp, sid, """(function(){
          var s=document.createElement('style');
          s.textContent='.ad-banner{display:none!important}';
          document.head.appendChild(s);
          var b=document.createElement('div');
          b.className='ad-banner';
          b.style.cssText='height:10px;width:300px;position:absolute;left:-9999px';
          document.body.appendChild(b);
          var out={h:b.offsetHeight,w:b.offsetWidth,ch:b.clientHeight,
                   op:b.offsetParent===null,rect:b.getBoundingClientRect().height,
                   display:getComputedStyle(b).display};
          b.remove(); s.remove();
          return JSON.stringify(out);
        })()""")
        detail = json.loads(probe) if probe else {}
        rec("诱饵尺寸被伪装（真实扩展环境下）",
            bool(detail) and detail.get("h") == 1 and detail.get("w") == 1
            and detail.get("ch") == 1 and detail.get("rect") == 1
            and detail.get("op") is False and detail.get("display") == "block",
            str(detail))

        # declarativeNetRequest：诱饵脚本应被重定向到扩展内的空桩。
        # 必须用真的 <script> 标签去加载，这样 resourceType 才是 script，
        # 跟站点实际用法一致；用 fetch 测会走 xmlhttprequest，是另一条规则。
        ev(cdp, sid, """(function(){
          window.__adsProbe = 'pending';
          var s = document.createElement('script');
          s.src = '/ads.js';
          s.onload = function(){ window.__adsProbe = 'loaded:' + String(window.canRunAds); };
          s.onerror = function(){ window.__adsProbe = 'error'; };
          document.head.appendChild(s);
          return 1;
        })()""")
        time.sleep(2)
        probe_js = ev(cdp, sid,
                      "String(window.__adsProbe) + ' | canRunAds=' + String(window.canRunAds)")
        rec("诱饵脚本被重定向到空桩", bool(probe_js) and "loaded:true" in probe_js,
            probe_js or "")

        img = ev(cdp, sid,
                 "fetch('/bait/300x250.png').then(function(r){"
                 "return r.arrayBuffer().then(function(b){"
                 "var u=new Uint8Array(b);"
                 "return JSON.stringify({len:b.byteLength,"
                 "png:u[0]===137&&u[1]===80&&u[2]===78&&u[3]===71});});})"
                 ".catch(function(e){return 'ERR:'+e.message;})")
        rec("诱饵图片被换成 1x1 透明图", bool(img) and '"png":true' in img, img or "")

        cdp.send("Target.closeTarget", {"targetId": tid})
        cdp.close()

        passed = sum(1 for _, ok, _ in checks if ok)
        print("\n结果：%d 通过 / %d 失败" % (passed, len(checks) - passed))
        code = 0 if passed == len(checks) else 1
    finally:
        stop_browser(br, os.path.join(out_dir, "profile"))
        try:
            web.terminate()
            web.wait(timeout=8)
        except Exception:
            try:
                web.kill()
            except Exception:
                pass
    sys.exit(code)


if __name__ == "__main__":
    main()
