# -*- coding: utf-8 -*-
"""探测站点里「直播内容」的 DOM 特征，用来校准内置的直播屏蔽规则。

不靠猜、不抄过期脚本：直接渲染真实页面，把两样东西 dump 出来——
  1) 所有指向直播域的链接，以及它们的祖先链（tag#id.class1.class2...）
  2) 页面里含 live / zhibo 的类名出现次数
据此反推稳定选择器。

用法：python tools/probe-live.py <url> [url2 ...]
输出：tools/.tmp/live-probe/<host>.json
"""
import json
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shot import CDP, http_json, start_browser, stop_browser  # noqa: E402

PORT = 9336
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0")

PROBE = r"""
(function () {
  function sig(el) {
    var c = '';
    try {
      var k = el.className;
      c = (typeof k === 'string') ? k : (k && k.baseVal ? k.baseVal : '');
    } catch (e) {}
    var s = el.tagName.toLowerCase();
    if (el.id) s += '#' + el.id;
    if (c) s += '.' + c.trim().split(/\s+/).join('.');
    return s;
  }

  var out = { url: location.href, title: document.title, liveLinks: [], cls: {}, cand: {} };

  // 0) 候选选择器命中数 —— 直接看哪些选择器在真实页面上有货
  var CAND = [
    'bili-live-card', '[class*="bili-live-card"]', '.floor-single-card',
    '.v-inline-live-player', '[class*="live-card"]', '[class*="live_card"]',
    '[class*="LiveCard"]', '[class*="liveCard"]', '.pop-live-small-mode',
    '[class*="live-item"]', '[class*="liveItem"]', '[class*="live-room"]',
    '[class*="liveRoom"]', '[class*="zhibo"]', '[class*="live-recommend"]',
    '[class*="liveRecommend"]', '[class*="live-list"]', '[class*="liveList"]',
    '[class*="live-area"]', '[class*="liveArea"]', '[class*="live-module"]',
    '[class*="liveModule"]', '[class*="live-wrapper"]', '[class*="liveWrap"]',
    '[class*="live-cover"]', '[class*="live-entry"]', '.tab-live',
    '[id*="live"]', '[class*="live"]'
  ];
  for (var ci = 0; ci < CAND.length; ci++) {
    try { out.cand[CAND[ci]] = document.querySelectorAll(CAND[ci]).length; }
    catch (e) { out.cand[CAND[ci]] = -1; }
  }

  // 1) 指向直播域的链接 + 祖先链
  var re = /(\/\/|\.)live\.|\/live(\/|$|\?)|\/zhibo|live\.bilibili|live\.douyin|live\.kuaishou/i;
  var links = document.querySelectorAll('a[href]');
  var n = 0;
  for (var i = 0; i < links.length && n < 30; i++) {
    var a = links[i];
    if (!re.test(a.href || '')) continue;
    var chain = [], el = a, d = 0;
    while (el && d < 7) { chain.push(sig(el)); el = el.parentElement; d++; }
    out.liveLinks.push({
      href: (a.href || '').slice(0, 120),
      text: (a.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 40),
      chain: chain
    });
    n++;
  }

  // 2) 含 live / zhibo 的类名统计
  var all = document.querySelectorAll('*');
  var lim = Math.min(all.length, 40000);
  for (var j = 0; j < lim; j++) {
    var e = all[j], c = '';
    try {
      var kk = e.className;
      c = (typeof kk === 'string') ? kk : (kk && kk.baseVal ? kk.baseVal : '');
    } catch (err) {}
    var toks = ((c || '') + ' ' + (e.id || '')).toLowerCase().split(/[^a-z0-9_-]+/);
    for (var t = 0; t < toks.length; t++) {
      var tok = toks[t];
      if (!tok || tok.length < 3) continue;
      if (tok.indexOf('live') === -1 && tok.indexOf('zhibo') === -1) continue;
      out.cls[tok] = (out.cls[tok] || 0) + 1;
    }
  }
  return JSON.stringify(out);
})()
"""


def probe(cdp, url, out_dir):
    t = cdp.send("Target.createTarget", {"url": "about:blank"})
    tid = t["targetId"]
    sid = cdp.send("Target.attachToTarget", {"targetId": tid, "flatten": True})["sessionId"]
    cdp.send("Page.enable", {}, sid)
    cdp.send("Runtime.enable", {}, sid)
    cdp.send("Network.enable", {}, sid)
    cdp.send("Network.setUserAgentOverride", {"userAgent": UA}, sid)
    cdp.send("Emulation.setDeviceMetricsOverride",
             {"width": 1440, "height": 900, "deviceScaleFactor": 1, "mobile": False}, sid)
    cdp.send("Page.navigate", {"url": url}, sid)

    time.sleep(9)
    # 滚一滚触发懒加载，再回到顶部
    for y in (1000, 2200, 3400, 0):
        cdp.send("Runtime.evaluate", {"expression": "window.scrollTo(0,%d)" % y}, sid)
        time.sleep(1.2)

    r = cdp.send("Runtime.evaluate",
                 {"expression": PROBE, "returnByValue": True, "awaitPromise": True}, sid)
    raw = r.get("result", {}).get("value")
    cdp.send("Target.closeTarget", {"targetId": tid})
    if not raw:
        return None
    return json.loads(raw)


def main():
    urls = sys.argv[1:]
    if not urls:
        print("用法: python tools/probe-live.py <url> [url2 ...]")
        sys.exit(2)

    out_dir = os.path.join("tools", ".tmp", "live-probe")
    os.makedirs(out_dir, exist_ok=True)
    profile = os.path.abspath(os.path.join("tools", ".tmp", "cdpprofile-probe"))

    proc = start_browser(PORT, profile)
    print("browser up, pid=%d\n" % proc.pid)
    try:
        ver = http_json(PORT, "/json/version")
        cdp = CDP(ver["webSocketDebuggerUrl"])
        for url in urls:
            host = re.sub(r"^www\.", "", re.sub(r"^https?://", "", url).split("/")[0])
            print("=" * 68)
            print("探测 %s" % url)
            try:
                data = probe(cdp, url, out_dir)
            except Exception as exc:  # noqa: BLE001
                print("  失败: %s" % exc)
                continue
            if not data:
                print("  未取到数据")
                continue

            path = os.path.join(out_dir, host + ".json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            print("  标题: %s" % data.get("title", "")[:60])
            print("  指向直播域的链接: %d 个" % len(data.get("liveLinks", [])))
            for item in data.get("liveLinks", [])[:6]:
                print("    · [%s] %s" % (item["text"], item["href"][:70]))
                print("      链: %s" % " < ".join(item["chain"][:5]))
            cls = sorted(data.get("cls", {}).items(), key=lambda x: -x[1])
            print("  含 live/zhibo 的类名 (前 22):")
            for name, cnt in cls[:22]:
                print("    %-38s %d" % (name, cnt))

            cand = [(k, v) for k, v in data.get("cand", {}).items() if v]
            cand.sort(key=lambda x: -x[1])
            print("  候选选择器命中（只列有货的）:")
            if cand:
                for name, cnt in cand:
                    print("    %-38s %d" % (name, cnt))
            else:
                print("    （全部为 0）")
            print("  已写入 %s\n" % path)
        cdp.close()
    finally:
        stop_browser(proc, profile)


if __name__ == "__main__":
    main()
