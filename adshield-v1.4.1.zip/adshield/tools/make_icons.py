# -*- coding: utf-8 -*-
"""生成 AdShield 扩展图标（纯 Python，无第三方依赖）。

图标：蓝紫渐变盾牌 + 白色禁止斜杠，代表"拦截"。
输出：icons/icon16.png icon32.png icon48.png icon128.png
"""
import math
import os
import struct
import zlib

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "icons")

TOP = 0.06
BOTTOM = 0.96
HALF = 0.400          # 盾牌最大半宽
CORNER = 0.115        # 顶部圆角半径
TAPER_START = 0.40    # 从该高度比例开始收窄
SS = 4                # 超采样倍数

# 斜杠（禁止符）：两端点 + 半宽
SLASH_A = (0.285, 0.745)
SLASH_B = (0.715, 0.255)
SLASH_HW = 0.048


def _shield_halfwidth(t):
    if t <= TAPER_START:
        return HALF
    u = (t - TAPER_START) / (1.0 - TAPER_START)
    return HALF * max(0.0, 1.0 - u ** 1.85)


def in_shield(x, y):
    if y < TOP or y > BOTTOM:
        return False
    t = (y - TOP) / (BOTTOM - TOP)
    hw = _shield_halfwidth(t)
    if hw <= 0:
        return False
    dx = abs(x - 0.5)
    # 顶部圆角
    if y < TOP + CORNER:
        r = CORNER
        base = HALF - r
        dy = (TOP + r) - y
        hw = min(hw, base + math.sqrt(max(0.0, r * r - dy * dy)))
    return dx <= hw


def in_slash(x, y):
    ax, ay = SLASH_A
    bx, by = SLASH_B
    vx, vy = bx - ax, by - ay
    wx, wy = x - ax, y - ay
    seg = vx * vx + vy * vy
    t = 0.0 if seg == 0 else max(0.0, min(1.0, (wx * vx + wy * vy) / seg))
    px, py = ax + t * vx, ay + t * vy
    return math.hypot(x - px, y - py) <= SLASH_HW


def gradient(t):
    """纵向渐变: #2f6bff -> #7c3aed"""
    r = int(0x2F + (0x7C - 0x2F) * t)
    g = int(0x6B + (0x3A - 0x6B) * t)
    b = int(0xFF + (0xED - 0xFF) * t)
    return r, g, b


def render(size):
    rows = []
    step = 1.0 / (size * SS)
    for py in range(size):
        row = []
        for px in range(size):
            cov_shield = 0
            cov_slash = 0
            rsum = gsum = bsum = 0
            for sy in range(SS):
                for sx in range(SS):
                    x = (px * SS + sx + 0.5) * step
                    y = (py * SS + sy + 0.5) * step
                    if in_shield(x, y):
                        cov_shield += 1
                        cr, cg, cb = gradient((y - TOP) / (BOTTOM - TOP))
                        rsum += cr
                        gsum += cg
                        bsum += cb
                        if in_slash(x, y):
                            cov_slash += 1
            total = SS * SS
            if cov_shield == 0:
                row.append((0, 0, 0, 0))
                continue
            r, g, b = rsum / cov_shield, gsum / cov_shield, bsum / cov_shield
            s = cov_slash / total
            r = r * (1 - s) + 255 * s
            g = g * (1 - s) + 255 * s
            b = b * (1 - s) + 255 * s
            alpha = int(round(255 * cov_shield / total))
            row.append((int(r), int(g), int(b), alpha))
        rows.append(row)
    return rows


def write_png(path, rows):
    size = len(rows)
    raw = bytearray()
    for row in rows:
        raw.append(0)
        for (r, g, b, a) in row:
            raw += struct.pack("BBBB", r, g, b, a)

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data +
                struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    ihdr = struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)
    blob = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) +
            chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))
    with open(path, "wb") as fh:
        fh.write(blob)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    for size in (16, 32, 48, 128):
        write_png(os.path.join(OUT_DIR, "icon%d.png" % size), render(size))
        print("icon%d.png" % size)


if __name__ == "__main__":
    main()
