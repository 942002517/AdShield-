# -*- coding: utf-8 -*-
"""反广告拦截检测：无头浏览器跑 test/anti-detect.html，读回断言结果并截图。

用法：
  python tools/anti-detect-run.py [页面URL] [输出目录]

默认跑 test/anti-detect.html（file:// 即可，页面不依赖网络）。
"""
import base64
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shot import CDP, http_json, start_browser, stop_browser  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = 9334


def default_url():
    p = os.path.join(ROOT, "test", "anti-detect.html").replace("\\", "/")
    return "file:///" + p


READ_DETAIL = (
    "JSON.stringify({"
    "title:document.title,"
    "err:window.__testError||null,"
    "result:window.__testResult||null,"
    "summary:(document.getElementById('summary')||{}).innerText||'',"
    "off:[].map.call(document.querySelectorAll('#tblOff tbody tr'),"
    "function(tr){return tr.innerText.replace(/\\s+/g,' | ');}),"
    "on:[].map.call(document.querySelectorAll('#tblOn tbody tr'),"
    "function(tr){return tr.innerText.replace(/\\s+/g,' | ');}),"
    "side:[].map.call(document.querySelectorAll('#tblSide tbody tr'),"
    "function(tr){return tr.innerText.replace(/\\s+/g,' | ');})})"
)


def run(port, url, out_dir):
    ver = http_json(port, "/json/version")
    cdp = CDP(ver["webSocketDebuggerUrl"])

    t = cdp.send("Target.createTarget", {"url": "about:blank"})
    tid = t["targetId"]
    sid = cdp.send("Target.attachToTarget", {"targetId": tid, "flatten": True})["sessionId"]

    cdp.send("Page.enable", {}, sid)
    cdp.send("Runtime.enable", {}, sid)
    cdp.send("Emulation.setDeviceMetricsOverride",
             {"width": 1180, "height": 900, "deviceScaleFactor": 1, "mobile": False}, sid)
    cdp.send("Page.navigate", {"url": url}, sid)

    # 等页面把结果写进 window.__testResult
    deadline = time.time() + 25
    got = False
    while time.time() < deadline:
        time.sleep(0.4)
        r = cdp.send("Runtime.evaluate",
                     {"expression": "!!(window.__testResult||window.__testError)",
                      "returnByValue": True}, sid)
        if r.get("result", {}).get("value"):
            got = True
            break
    time.sleep(0.6)

    r = cdp.send("Runtime.evaluate",
                 {"expression": READ_DETAIL, "returnByValue": True}, sid)
    raw = r.get("result", {}).get("value")
    detail = json.loads(raw) if raw else {}

    # 全页截图
    hr = cdp.send("Runtime.evaluate", {
        "expression": "Math.max(document.body.scrollHeight,"
                      "document.documentElement.scrollHeight)",
        "returnByValue": True}, sid)
    full_h = int(hr.get("result", {}).get("value") or 1200)
    full_h = max(600, min(full_h, 5000))
    shot = cdp.send("Page.captureScreenshot",
                    {"format": "png", "captureBeyondViewport": True,
                     "clip": {"x": 0, "y": 0, "width": 1180, "height": full_h, "scale": 1}}, sid)
    png = os.path.join(out_dir, "anti-detect.png")
    with open(png, "wb") as f:
        f.write(base64.b64decode(shot["data"]))

    cdp.send("Target.closeTarget", {"targetId": tid})
    cdp.close()

    # ---------- 输出 ----------
    print("页面标题: %s" % detail.get("title"))
    if detail.get("err"):
        print("!! 脚本抛错: %s" % detail["err"])
    print("")
    for label, key in (("一、检测器有效性（对照 · 关闭欺骗）", "off"),
                       ("二、防护效果（实验 · 启用欺骗）", "on"),
                       ("三、副作用检查", "side")):
        print("== %s ==" % label)
        for row in detail.get(key) or []:
            print("   " + row)
        print("")
    print(detail.get("summary", "").replace("\n", " | "))
    print("截图: %s" % png)

    res = detail.get("result") or {}
    if not got or not res:
        print("\n结论: 未能取得断言结果")
        return 2
    if res.get("ok"):
        print("\n结论: 全部通过（%d/%d）" % (res["pass"], res["total"]))
        return 0
    print("\n结论: 有 %d 项未通过" % (res["total"] - res["pass"]))
    return 1


def main():
    url = sys.argv[1] if len(sys.argv) > 1 else default_url()
    out_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.join("tools", ".tmp", "antidetect")
    os.makedirs(out_dir, exist_ok=True)
    profile = os.path.abspath(os.path.join(out_dir, "..", "cdpprofile-ad"))

    proc = start_browser(PORT, profile)
    print("browser up, pid=%d" % proc.pid)
    code = 3
    try:
        code = run(PORT, url, out_dir)
    finally:
        stop_browser(proc, profile)
    sys.exit(code)


if __name__ == "__main__":
    main()
