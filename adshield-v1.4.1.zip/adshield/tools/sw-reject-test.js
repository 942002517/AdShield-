/* =============================================================
 * AdShield - Service Worker「未处理 Promise 拒绝」回归测试
 *
 * 背景（这个测试要防住的 bug）：
 *   MV3 下 chrome.action.setBadgeText({tabId}) 在没有传回调时返回 Promise。
 *   标签页被关闭后调用它会拒绝，错误信息正是：
 *       Uncaught (in promise) Error: No tab with id: 1290735032.
 *   而这类调用通常写在 `try { ... } catch {}` 里且没有 await —— try/catch 对
 *   「微任务里发生的拒绝」完全无效，于是拒绝冒成全局未处理错误打印到控制台。
 *
 * 做法：
 *   在 vm 沙箱里加载真实的 service-worker.js，把 chrome.action.* / tabs.create /
 *   storage.session.set 全部换成一调用就返回「已拒绝 Promise」的桩，
 *   然后依次触发三条会打到这些调用的真实路径，最后断言：
 *     1) 没有任何未处理拒绝；
 *     2) 那些桩确实被调到了（否则测试是空转的，必须防住这种假通过）；
 *     3) 反向对照：把源码里的拒绝处理去掉后再跑一遍，必须**能**复现出未处理拒绝
 *        —— 证明这个测试有灵敏度，不是永远绿。
 *
 * 运行： node tools/sw-reject-test.js
 * ============================================================= */
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.dirname(__dirname);
const SW = 'src/background/service-worker.js';
const TAB_ID = 1290735032;
const NO_TAB = 'No tab with id: ' + TAB_ID;

let pass = 0;
let fail = 0;
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  \u2713 ' + name); }
  else { fail++; console.log('  \u2717 ' + name + (extra ? '  -> ' + extra : '')); }
}
function section(t) { console.log('\n' + t); }

/* ---------------- chrome.* 桩 ---------------- */

function buildSandbox() {
  const calls = {
    setBadgeText: 0, setBadgeBackgroundColor: 0, setBadgeTextColor: 0,
    tabsCreate: 0, openOptions: 0, sessionSet: 0
  };
  const listeners = { installed: [], startup: [], message: [], removed: [], updated: [], alarm: [] };
  const responses = [];
  const sessionStore = {};
  const localStore = new Map();

  function rejected(msg) { return Promise.reject(new Error(msg)); }

  const chrome = {
    runtime: {
      lastError: null,
      getURL: function (p) { return 'chrome-extension://test/' + p; },
      onInstalled: { addListener: function (fn) { listeners.installed.push(fn); } },
      onStartup: { addListener: function (fn) { listeners.startup.push(fn); } },
      onMessage: { addListener: function (fn) { listeners.message.push(fn); } },
      openOptionsPage: function () { calls.openOptions++; return rejected('窗口已关闭'); }
    },
    storage: {
      local: {
        get: function (keys, cb) {
          const res = {};
          const ks = keys === null || keys === undefined
            ? Array.from(localStore.keys())
            : (Array.isArray(keys) ? keys : (typeof keys === 'string' ? [keys] : Object.keys(keys)));
          ks.forEach(function (k) { if (localStore.has(k)) res[k] = localStore.get(k); });
          cb(JSON.parse(JSON.stringify(res)));
        },
        set: function (obj, cb) {
          const v = JSON.parse(JSON.stringify(obj));
          Object.keys(v).forEach(function (k) { localStore.set(k, v[k]); });
          if (cb) cb();
        },
        remove: function (keys, cb) {
          (Array.isArray(keys) ? keys : [keys]).forEach(function (k) { localStore.delete(k); });
          if (cb) cb();
        },
        getKeys: function (cb) { cb(Array.from(localStore.keys())); }
      },
      session: {
        get: function (keys, cb) {
          const res = {};
          (Array.isArray(keys) ? keys : [keys]).forEach(function (k) {
            if (k in sessionStore) res[k] = sessionStore[k];
          });
          cb(res);
        },
        // 每次都失败：模拟「存储配额触及」，同时验证 persistTabStats /
        // persistLogs / clearLogs 里的会话写入也会被兜住
        set: function () { calls.sessionSet++; return rejected('存储配额已满'); }
      },
      onChanged: { addListener: function () {} }
    },
    action: {
      // 全部拒绝，模拟「标签页已经关闭」
      setBadgeText: function () { calls.setBadgeText++; return rejected(NO_TAB); },
      setBadgeBackgroundColor: function () { calls.setBadgeBackgroundColor++; return rejected(NO_TAB); },
      setBadgeTextColor: function () { calls.setBadgeTextColor++; return rejected(NO_TAB); }
    },
    tabs: {
      create: function () { calls.tabsCreate++; return rejected('没有可用的窗口'); },
      query: function (q, cb) { cb([{ id: TAB_ID, url: 'https://example.com/a?b=1' }]); },
      sendMessage: function (id, msg, cb) { cb({ ok: true }); },
      get: function (id, cb) { cb({ id: id, url: 'https://example.com/' }); },
      onRemoved: { addListener: function (fn) { listeners.removed.push(fn); } },
      onUpdated: { addListener: function (fn) { listeners.updated.push(fn); } }
    },
    scripting: {
      executeScript: function (opts, cb) { if (cb) cb([]); }
    },
    alarms: {
      create: function () {},
      onAlarm: { addListener: function (fn) { listeners.alarm.push(fn); } }
    },
    declarativeNetRequest: {
      onRuleMatchedDebug: null,            // 正式安装版拿不到这个接口
      updateEnabledRulesets: function (o, cb) { if (cb) cb(); },
      updateDynamicRules: function (o, cb) { if (cb) cb(); },
      getDynamicRules: function (cb) { cb([]); },
      getMatchedRules: function (o, cb) { cb({ rulesMatchedInfo: [] }); }
    }
  };

  const sandbox = {
    chrome: chrome, console: console,
    setTimeout: setTimeout, clearTimeout: clearTimeout,
    Promise: Promise, Object: Object, Array: Array, JSON: JSON, Date: Date,
    Math: Math, String: String, Number: Number, RegExp: RegExp, Set: Set,
    Map: Map, Error: Error, URL: URL, parseInt: parseInt, isFinite: isFinite,
    Symbol: Symbol, WeakMap: WeakMap
  };
  sandbox.self = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  sandbox.importScripts = function () {
    for (let i = 0; i < arguments.length; i++) {
      const rel = String(arguments[i]).replace(/^\/+/, '');
      vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), sandbox, { filename: rel });
    }
  };
  sandbox.__t = { calls: calls, listeners: listeners, responses: responses };
  return sandbox;
}

/* ---------------- 一次完整运行 ---------------- */

async function run(swCode, label) {
  const unhandled = [];
  const onUnhandled = function (r) { unhandled.push(String((r && r.message) || r)); };
  process.on('unhandledRejection', onUnhandled);

  const sandbox = buildSandbox();
  vm.runInContext(swCode, sandbox, { filename: SW });
  const { calls, listeners, responses } = sandbox.__t;

  const reply = function (msg) {
    return new Promise(function (resolve) {
      const before = responses.length;
      listeners.message.forEach(function (fn) {
        fn(msg, { tab: { id: TAB_ID } }, function (r) { responses.push(r); });
      });
      // sendResponse 可能是同步或异步的，给一轮事件循环
      setTimeout(function () { resolve(responses[before] || null); }, 30);
    });
  };

  // 1) 标签页开始加载 —— 走到 onUpdated 里的 setBadgeText
  listeners.updated.forEach(function (fn) {
    fn(TAB_ID, { status: 'loading', url: 'https://example.com/' });
  });
  await new Promise(function (r) { setTimeout(r, 30); });

  // 2) 弹窗请求清空本站统计 —— 走到 updateBadge 里的四个 setBadge*
  await reply({ type: 'clearTabStats', tabId: TAB_ID });

  // 3) 打开控制面板读状态 —— 走到 buildState / getActiveTab / updateBadge
  await reply({ type: 'getState' });

  // 4) 清空日志 —— 走到 clearLogs 里的 storage.session.set
  await reply({ type: 'clearLogs' });

  // 5) 重新编译 —— 走到 persistTabStats 里的 storage.session.set
  await reply({ type: 'recompile' });

  // 6) 安装事件 —— 走到 chrome.tabs.create
  listeners.installed.forEach(function (fn) { fn({ reason: 'install' }); });
  await new Promise(function (r) { setTimeout(r, 60); });

  // 7) 定时任务 —— 走到 alarms 回调，确认它不会自己炸
  listeners.alarm.forEach(function (fn) { fn({ name: 'adshield-refresh' }); });
  await new Promise(function (r) { setTimeout(r, 60); });

  process.removeListener('unhandledRejection', onUnhandled);
  return { unhandled: unhandled, calls: calls, responses: responses, label: label };
}

/* ---------------- 主流程 ---------------- */

(async function main() {
  const code = fs.readFileSync(path.join(ROOT, SW), 'utf8');

  section('【一】真实源码：所有合理拒绝都应被吞掉，控制台保持干净');
  const r = await run(code, 'real');

  check('chrome.action.setBadgeText 确实被调到了（避免空转假通过）',
    r.calls.setBadgeText >= 1, '调用 ' + r.calls.setBadgeText + ' 次');
  check('chrome.action.setBadgeBackgroundColor 被调到了',
    r.calls.setBadgeBackgroundColor >= 1, '调用 ' + r.calls.setBadgeBackgroundColor + ' 次');
  check('chrome.action.setBadgeTextColor 被调到了',
    r.calls.setBadgeTextColor >= 1, '调用 ' + r.calls.setBadgeTextColor + ' 次');
  check('chrome.tabs.create 被调到了（安装后打开设置页）',
    r.calls.tabsCreate >= 1, '调用 ' + r.calls.tabsCreate + ' 次');
  check('chrome.storage.session.set 被调到了（会话写入）',
    r.calls.sessionSet >= 1, '调用 ' + r.calls.sessionSet + ' 次');
  check('没有产生任何未处理的 Promise 拒绝',
    r.unhandled.length === 0, JSON.stringify(r.unhandled));

  section('【二】错误只发生在被兜住的调用里，业务回复本身不受影响');
  const okReplies = r.responses.filter(function (x) { return x && x.ok; });
  check('消息处理仍然正常返回（说明兜底没有吞掉业务逻辑）',
    okReplies.length >= 4, '成功回复 ' + okReplies.length + ' 条');

  section('【三】反向对照：去掉兜底后必须能复现原 bug（证明测试有灵敏度）');
  const NEEDLE = 'p.then(null, function () { /* 标签页/窗口已关闭，或存储配额触及——忽略 */ });';
  const mutated = code.replace(NEEDLE, '/* 故意去掉拒绝处理 */');
  check('对照用的源码改写点还能匹配上（注释被改动时这里会失败）',
    mutated !== code, '没匹配到 swallow() 里的拒绝处理语句');
  if (mutated !== code) {
    const c = await run(mutated, 'control');
    check('去掉兜底后确实出现了未处理拒绝',
      c.unhandled.length > 0,
      c.unhandled.length ? c.unhandled.slice(0, 3).join(' | ') : '一条都没有，测试可能失效');
    check('对照组里出现了原报错文本 "No tab with id"',
      c.unhandled.some(function (m) { return m.indexOf('No tab with id') !== -1; }),
      JSON.stringify(c.unhandled.slice(0, 3)));
  }

  console.log('\n==> ' + (fail === 0 ? '全部通过' : '存在 ' + fail + ' 个问题')
    + '（' + pass + ' 通过 / ' + fail + ' 失败）');
  process.exit(fail === 0 ? 0 : 1);
})();
