# -*- coding: utf-8 -*-
"""直播推荐屏蔽：无头浏览器跑 test/live-block.html，读回断言结果并截图。

用法：
  python tools/live-run.py [页面URL] [输出目录]
"""
import base64
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shot import CDP, http_json, start_browser, stop_browser  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = 9337


def default_url():
    p = os.path.join(ROOT, "test", "live-block.html").replace("\\", "/")
    return "file:///" + p


READ_DETAIL = (
    "JSON.stringify({"
    "title:document.title,"
    "err:window.__liveTestError||null,"
    "result:window.__liveTestResult||null,"
    "summary:(document.getElementById('summary')||{}).innerText||'',"
    "rows:[].map.call(document.querySelectorAll('#tbl tbody tr'),"
    "function(tr){return tr.innerText.replace(/\\s+/g,' | ');})})"
)


def run(port, url, out_dir):
    ver = http_json(port, "/json/version")
    cdp = CDP(ver["webSocketDebuggerUrl"])

    t = cdp.send("Target.createTarget", {"url": "about:blank"})
    tid = t["targetId"]
    sid = cdp.send("Target.attachToTarget", {"targetId": tid, "flatten": True})["sessionId"]

    cdp.send("Page.enable", {}, sid)
    cdp.send("Runtime.enable", {}, sid)
    cdp.send("Emulation.setDeviceMetricsOverride",
             {"width": 1180, "height": 900, "deviceScaleFactor": 1, "mobile": False}, sid)
    cdp.send("Page.navigate", {"url": url}, sid)

    deadline = time.time() + 25
    got = False
    while time.time() < deadline:
        time.sleep(0.4)
        r = cdp.send("Runtime.evaluate",
                     {"expression": "!!(window.__liveTestResult||window.__liveTestError)",
                      "returnByValue": True}, sid)
        if r.get("result", {}).get("value"):
            got = True
            break
    time.sleep(0.6)

    r = cdp.send("Runtime.evaluate",
                 {"expression": READ_DETAIL, "returnByValue": True}, sid)
    raw = r.get("result", {}).get("value")
    detail = json.loads(raw) if raw else {}

    hr = cdp.send("Runtime.evaluate", {
        "expression": "Math.max(document.body.scrollHeight,"
                      "document.documentElement.scrollHeight)",
        "returnByValue": True}, sid)
    full_h = int(hr.get("result", {}).get("value") or 1200)
    full_h = max(600, min(full_h, 5000))
    shot = cdp.send("Page.captureScreenshot",
                    {"format": "png", "captureBeyondViewport": True,
                     "clip": {"x": 0, "y": 0, "width": 1180, "height": full_h, "scale": 1}}, sid)
    png = os.path.join(out_dir, "live-block.png")
    with open(png, "wb") as f:
        f.write(base64.b64decode(shot["data"]))

    cdp.send("Target.closeTarget", {"targetId": tid})
    cdp.close()

    print("页面标题: %s" % detail.get("title"))
    if detail.get("err"):
        print("!! 脚本抛错: %s" % detail["err"])
    print("")
    for row in detail.get("rows") or []:
        print("   " + row)
    print("")
    print(detail.get("summary", "").replace("\n", " | "))
    print("截图: %s" % png)

    res = detail.get("result") or {}
    if not got or not res:
        print("\n结论: 未能取得断言结果")
        return 2
    if res.get("ok"):
        print("\n结论: 全部通过（%d/%d）" % (res["pass"], res["total"]))
        return 0
    print("\n结论: 有 %d 项未通过" % (res["total"] - res["pass"]))
    return 1


def main():
    url = sys.argv[1] if len(sys.argv) > 1 else default_url()
    out_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.join("tools", ".tmp", "livetest")
    os.makedirs(out_dir, exist_ok=True)
    profile = os.path.abspath(os.path.join(out_dir, "..", "cdpprofile-live"))

    proc = start_browser(PORT, profile)
    print("browser up, pid=%d" % proc.pid)
    code = 3
    try:
        code = run(PORT, url, out_dir)
    finally:
        stop_browser(proc, profile)
    sys.exit(code)


if __name__ == "__main__":
    main()
