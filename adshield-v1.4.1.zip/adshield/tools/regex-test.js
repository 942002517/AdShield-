/* =============================================================
 * AdShield - 正则与文本规则专项测试
 * 覆盖：量词识别/转换、RE2 兼容性校验、规则解析、编译器接线、规则反查
 * 运行：node tools/regex-test.js
 * ============================================================= */
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.dirname(__dirname);

let pass = 0;
let fail = 0;
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (extra ? '   → ' + extra : '')); }
}

/* ---------------- 最小 chrome 模拟 ---------------- */
const store = new Map();
const storageLocal = {
  get(keys, cb) {
    const out = {};
    if (keys === null || keys === undefined) {
      for (const [k, v] of store) out[k] = v;
    } else if (typeof keys === 'string') {
      if (store.has(keys)) out[keys] = store.get(keys);
    } else if (Array.isArray(keys)) {
      keys.forEach((k) => { if (store.has(k)) out[k] = store.get(k); });
    } else {
      Object.keys(keys).forEach((k) => { out[k] = store.has(k) ? store.get(k) : keys[k]; });
    }
    cb(out);
  },
  set(obj, cb) { Object.keys(obj).forEach((k) => store.set(k, obj[k])); cb && cb(); },
  remove(keys, cb) { (Array.isArray(keys) ? keys : [keys]).forEach((k) => store.delete(k)); cb && cb(); },
  getKeys(cb) { cb([...store.keys()]); },
};

let dynamicRules = [];
const dnr = {
  MAX_NUMBER_OF_DYNAMIC_AND_SESSION_RULES: 30000,
  getDynamicRules(cb) { cb(dynamicRules.slice()); },
  updateDynamicRules(opts, cb) {
    let failure = null;
    try {
      if (opts.removeRuleIds) {
        const rm = new Set(opts.removeRuleIds);
        dynamicRules = dynamicRules.filter((r) => !rm.has(r.id));
      }
      if (opts.addRules && opts.addRules.length) {
        if (dynamicRules.length + opts.addRules.length > 30000) throw new Error('超出上限');
        const ids = new Set(dynamicRules.map((r) => r.id));
        for (const r of opts.addRules) {
          if (!r.condition || (!r.condition.urlFilter && !r.condition.regexFilter)) {
            throw new Error('规则缺少匹配条件');
          }
          if (ids.has(r.id)) throw new Error('规则 ID 重复');
          ids.add(r.id);
        }
        dynamicRules = dynamicRules.concat(JSON.parse(JSON.stringify(opts.addRules)));
      }
    } catch (e) { failure = e.message; }
    chrome.runtime.lastError = failure ? { message: failure } : null;
    cb();
    chrome.runtime.lastError = null;
  },
};

const chrome = {
  runtime: { lastError: null },
  storage: { local: storageLocal },
  declarativeNetRequest: dnr,
};

/* ---------------- 加载模块 ---------------- */
function makeSandbox() {
  const s = { chrome, self: {}, console, Promise, Object, Array, JSON, Date, Math, String, Number, RegExp, Set, Error, setTimeout, clearTimeout };
  s.self = s;
  s.globalThis = s;
  vm.createContext(s);
  return s;
}

const sandbox = makeSandbox();
['src/lib/regex-engine.js', 'src/lib/filter-parser.js', 'src/lib/storage.js', 'src/lib/compiler.js']
  .forEach((rel) => {
    vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), sandbox, { filename: rel });
  });

const RX = sandbox.AdShieldRegex;
const P = sandbox.AdShieldParser;
const S = sandbox.AdShieldStorage;
const C = sandbox.AdShieldCompiler;

/* ============================================================
 * 一、正则引擎
 * ============================================================ */
console.log('\n--- 一、正则引擎：贪梵/懒惰量词 ---');

(function testQuantifiers() {
  const st = RX.analyze('a.*b.*?c+?d+e?f{2,3}?g{1,}');
  check('贪婪量词计数正确', st.greedy === 4, 'greedy=' + st.greedy);
  check('懒惰量词计数正确', st.lazy === 3, 'lazy=' + st.lazy);
  check('量词明细带位置', st.quantifiers.length === 7 && st.quantifiers[0].index === 2,
    JSON.stringify(st.quantifiers.map((q) => q.kind + q.text)));

  const cls = RX.analyze('[a-z*+?]{2}');
  check('字符类内的 * + ? 不误判为量词', cls.quantifiers.length === 1 && cls.quantifiers[0].text === '{2}',
    JSON.stringify(cls.quantifiers));

  const esc = RX.analyze('a\\*b\\+c');
  check('转义后的量词字符不误判', esc.quantifiers.length === 0);

  const pos = RX.analyze('a*+b++c?+');
  check('占有量词被单独识别', pos.possessive === 3 && pos.greedy === 0,
    'possessive=' + pos.possessive + ' greedy=' + pos.greedy);
})();

(function testToGreedyLazy() {
  check('贪婪 -> 懒惰', RX.toLazy('a.*b+') === 'a.*?b+?', RX.toLazy('a.*b+'));
  check('懒惰 -> 贪婪', RX.toGreedy('a.*?b+?') === 'a.*b+', RX.toGreedy('a.*?b+?'));
  check('? 量词切换为 ??', RX.toLazy('colou?r') === 'colou??r', RX.toLazy('colou?r'));
  check('{n,m} 切换', RX.toLazy('a{2,3}b') === 'a{2,3}?b', RX.toLazy('a{2,3}b'));
  check('占有量词降级为贪婪', RX.toGreedy('a*+b') === 'a*b', RX.toGreedy('a*+b'));
  check('字符类内的 * 不被改写', RX.toLazy('[a*]+') === '[a*]+?', RX.toLazy('[a*]+'));
  check('无量的表达式不变', RX.toLazy('abc') === 'abc');
})();

console.log('\n--- 二、匹配与贪婪/懒惰差异 ---');

(function testMatch() {
  const m = RX.matchOne('utm_[a-z]+', 'https://x.com/?utm_source=news');
  check('基本命中', m.matched && m.hits[0].text === 'utm_source', JSON.stringify(m.hits));

  const seg = RX.matchOne('utm_[a-z]+', 'a?utm_source=b');
  check('高亮分段重组后等于原文',
    seg.highlight.map((s) => s.text).join('') === 'a?utm_source=b');
  check('高亮分段标出了命中位置', seg.highlight.some((s) => s.hit && s.text === 'utm_source'));

  const g = RX.compare('a.*b', 'aXXbYYb');
  check('贪婪版吞到最后一个 b', g.greedy.hits[0].text === 'aXXbYYb', g.greedy.hits[0].text);
  check('懒惰版止于第一个 b', g.lazy.hits[0].text === 'aXXb', g.lazy.hits[0].text);
  check('两者都命中（拦截判定一致）', g.greedy.matched === true && g.lazy.matched === true);
  check('对比结论能说明差异量', g.delta === 3, 'delta=' + g.delta);

  const same = RX.compare('^https?://x\\.com/ads', 'https://x.com/ads');
  check('后续强制内容会顶住量词，长度一致', same.sameLength === true, same.note);

  const none = RX.compare('abc', 'xyz');
  check('无法切换量词时给出说明', none.changed === false && /没有可切换的量词/.test(none.note), none.note);
})();

console.log('\n--- 三、内核（RE2）兼容性校验 ---');

(function testCompat() {
  const cases = [
    ['(?=foo)bar', false, '前瞻'],
    ['(?<=foo)bar', false, '后顾'],
    ['(a)\\1', false, '反向引用'],
    ['(?>a)b', false, '原子组'],
    ['(?#注释)a', false, '注释组'],
    ['a*+b', true, null],
    ['(?P<n>a)b', true, null],
    ['^https?://([a-z0-9-]+\\.)*ads\\.', true, null],
    ['[a-z]{2,5}?', true, null],
  ];
  cases.forEach(([pat, ok, label]) => {
    const v = RX.validate(pat);
    check('内核兼容判定：' + pat, v.dnr.ok === ok,
      'dnr.ok=' + v.dnr.ok + ' blockers=' + v.dnr.blockers.join('|'));
    if (!ok && label) {
      check('  给出了原因（' + label + '）', v.dnr.blockers.length > 0,
        JSON.stringify(v.dnr));
    }
  });

  const fixed = RX.toDnr('a*+b(?P<n>c)');
  check('占有量词被自动降级', fixed.regex === 'a*b(?<n>c)', fixed.regex);
  check('降级项有记录', fixed.repairs.length === 2, JSON.stringify(fixed.repairs));

  const bad = RX.validate('[a-z');
  check('未闭合字符类被识别为错误', !bad.ok && /未闭合/.test(bad.error), bad.error);

  const paren = RX.validate('(a(b)');
  check('括号不配对被识别', !paren.ok && /未闭合/.test(paren.error), paren.error);

  const inline = RX.validate('(?i)ADS');
  check('内联标志 (?i) 不误报括号错误', inline.ok, inline.error);

  const long = RX.validate('a'.repeat(RX.MAX_LEN + 10));
  check('超长表达式被拒绝', !long.ok && /超过/.test(long.error), long.error);

  const redos = RX.validate('(a+)+$');
  check('灾难性回溯被提示', redos.warnings.some((w) => /灾难性回溯/.test(w)),
    JSON.stringify(redos.warnings));
})();

console.log('\n--- 四、规则文本生成 ---');

(function testGenerate() {
  check('/ 被转义',
    RX.toAbp('a/b', {}) === '/a\\/b/', RX.toAbp('a/b', {}));
  check('资源类型拼接正确',
    RX.toAbp('ads\\.', { types: ['script', 'image'], thirdParty: true }) === '/ads\\./$script,image,third-party',
    RX.toAbp('ads\\.', { types: ['script', 'image'], thirdParty: true }));
  check('例外标记 @@',
    RX.toAbp('good', { exception: true }) === '@@/good/', RX.toAbp('good', { exception: true }));
  check('removeparam 正则转义 /',
    RX.toRemoveParam('a/b') === '/a\\/b/', RX.toRemoveParam('a/b'));

  check('内联正则取体：/re/i',
    RX.extractInlineRegex('/ad[s]?/i').pattern === 'ad[s]?' && RX.extractInlineRegex('/ad[s]?/i').isRegex === true);
  check('内联正则取体：纯文本',
    RX.extractInlineRegex('赞助内容').isRegex === false);
})();

/* ============================================================
 * 二、解析器接线
 * ============================================================ */
console.log('\n--- 五、解析器：正则规则与文本规则 ---');

(function testParser() {
  const ok = P.parseLine('/ads?\\d*\\.(js|gif)/$script,third-party');
  check('正则网络规则被接受', ok.kind === 'network' && ok.data.regex === true, JSON.stringify(ok.data || ok));
  check('正则规则的选项被解析',
    ok.kind === 'network' && ok.data.options.types.length === 1 && ok.data.options.types[0] === 'script');

  const incompat = P.parseLine('/(?=foo)bar/');
  check('内核不兼容的正则被拒绝', incompat.kind === 'skip' && /内核不支持/.test(incompat.reason || ''),
    JSON.stringify(incompat));

  const broken = P.parseLine('/(a/');
  check('语法错误的正则被拒绝', broken.kind === 'skip' && /语法错误/.test(broken.reason || ''),
    JSON.stringify(broken));

  const hosp = P.parseLine('/ad[s]?\\.example\\.com/');
  check('外观过滤行不会被误判为正则网络规则', hosp.kind === 'skip' || hosp.kind === 'network');

  const rm = P.parseLine('*$removeparam=/^(utm_.*|gclid)$/');
  check('removeparam 支持正则形式', rm.kind === 'network' && Array.isArray(rm.data.options.removeParams) &&
    rm.data.options.removeParams[0] === '/^(utm_.*|gclid)$/',
    JSON.stringify(rm.data && rm.data.options && rm.data.options.removeParams));

  const rmComma = P.parseLine('*$removeparam=/^x{1,3}$/');
  check('选项拆分不会在 {1,3} 上断句',
    rmComma.kind === 'network' && rmComma.data.options.removeParams[0] === '/^x{1,3}$/',
    JSON.stringify(rmComma.data && rmComma.data.options && rmComma.data.options.removeParams));

  const text1 = P.parseLine('example.com##div:has-text(/赞助|广告/i)');
  check('文本匹配规则被解析', text1.kind === 'cosmetic' && text1.data.text.length === 1,
    JSON.stringify(text1.data));
  check('基础选择器与文本条件分离',
    text1.data.selector === 'div' && text1.data.text[0].src === '赞助|广告' && text1.data.text[0].flags === 'i');

  const text2 = P.parseLine('##div:contains(Sponsored)');
  check('纯文本 :contains 转为转义后的正则',
    text2.kind === 'cosmetic' && text2.data.text[0].isRegex === false &&
    text2.data.text[0].src.indexOf('Sponsored') !== -1,
    JSON.stringify(text2.data));

  const text3 = P.parseLine('##:has-text(/^广告/)');
  check('无基础选择器时使用兜底范围',
    text3.kind === 'cosmetic' && text3.data.selector.length > 0 && text3.data.selector !== '*',
    text3.data && text3.data.selector);

  const textBad = P.parseLine('example.com##div:has-text(/(/i)');
  check('文本条件里的非法正则被拒绝', textBad.kind === 'skip', JSON.stringify(textBad));

  const js = P.parseLine('example.com##+js(set-constant, x, 1)');
  check('脚本注入规则仍被跳过', js.kind === 'skip');
})();

/* ============================================================
 * 三、编译器接线
 * ============================================================ */
(async function main() {
  console.log('\n--- 六、编译器：正则与文本规则进入产物 ---');

  store.clear();
  dynamicRules = [];
  await S.setSettings(Object.assign({}, S.DEFAULT_SETTINGS, {
    customRules: [
      '/^https?:\\/\\/([a-z0-9-]+\\.)*ads?\\./$script,image',
      '/track(ing)?[0-9]*\\.js/$script',
      '*$removeparam=/^(utm_.*|gclid|fbclid)$/',
      'example.com##div:has-text(/赞助内容|Sponsored/i)',
      'shop.example.com##.promo-block',
      '||plain-block.example.com^',
    ].join('\n'),
  }));
  await S.setLists([{ id: 'inline', name: '内联测试列表', enabled: true }]);
  await S.set({
    'listText:inline': [
      '! 内联测试',
      '||list-ad.example.com^',
      '/banner[0-9]{2,3}\\.gif/$image',
      'news.example.com##div:contains(推广)',
    ].join('\n'),
  });

  const info = await C.compileAll();
  const regexRules = dynamicRules.filter((r) => r.condition.regexFilter);

  check('正则规则进入 DNR', regexRules.length >= 3, 'count=' + regexRules.length);
  check('正则规则使用 regexFilter 而非 urlFilter',
    regexRules.every((r) => !r.condition.urlFilter));
  check('统计里含正则条数', info.network.regex >= 3, 'regex=' + info.network.regex);
  check('自定义网络规则被标记并优先保留', info.network.userRules >= 3, 'userRules=' + info.network.userRules);

  const rmRule = dynamicRules.filter((r) => r.action.type === 'redirect');
  check('removeparam 正则进入 DNR',
    rmRule.length === 1 && rmRule[0].action.redirect.transform.removeParams[0] === '/^(utm_.*|gclid|fbclid)$/',
    JSON.stringify(rmRule[0] && rmRule[0].action));

  check('文本规则未写入 CSS 选择器', (() => {
    const b = store.get('cosmeticDomain:example.com');
    if (!b) return false;
    return (b.s || []).indexOf('div') === -1 && Array.isArray(b.t) && b.t.length === 1;
  })(), JSON.stringify(store.get('cosmeticDomain:example.com')));

  check('文本规则保留了正则与标志位', (() => {
    const b = store.get('cosmeticDomain:example.com');
    const t = b && b.t && b.t[0];
    return t && t.sel === 'div' && t.src === '赞助内容|Sponsored' && t.flags === 'i';
  })(), JSON.stringify(store.get('cosmeticDomain:example.com')));

  check('纯 CSS 规则不受影响', (() => {
    const b = store.get('cosmeticDomain:shop.example.com');
    return b && (b.s || []).indexOf('.promo-block') !== -1;
  })());

  check('列表里的文本规则同样被保留', (() => {
    const b = store.get('cosmeticDomain:news.example.com');
    return b && Array.isArray(b.t) && b.t.length === 1 && b.t[0].src.indexOf('推广') !== -1;
  })(), JSON.stringify(store.get('cosmeticDomain:news.example.com')));

  check('文本规则计入编译统计', info.cosmetic.text === 2, 'text=' + info.cosmetic.text);

  console.log('\n--- 七、规则反查（拦截日志用） ---');

  check('ruleIndex 已生成', Array.isArray(info.ruleIndex) && info.ruleIndex.length > 0,
    JSON.stringify(info.ruleIndex));

  check('区间连续覆盖全部规则', (() => {
    const idx = info.ruleIndex;
    if (idx[0].from !== 1) return false;
    for (let i = 1; i < idx.length; i++) {
      if (idx[i].from !== idx[i - 1].to + 1) return false;
    }
    return idx[idx.length - 1].to === info.dynamicRules;
  })(), JSON.stringify(info.ruleIndex.map((r) => [r.name, r.from, r.to])));

  check('能按规则 id 定位到来源', (() => {
    const userRanges = info.ruleIndex.filter((r) => r.user);
    if (!userRanges.length) return false;
    return userRanges.some((r) => {
      for (let id = r.from; id <= r.to; id++) {
        const hit = dynamicRules.find((x) => x.id === id);
        if (hit && hit.condition.regexFilter) return true;
      }
      return false;
    });
  })(), JSON.stringify(info.ruleIndex.filter((r) => r.user)));

  check('userPatterns 只记录自定义规则', (() => {
    const ids = Object.keys(info.userPatterns).map(Number);
    return ids.length === info.network.userRules && ids.every((id) => {
      const r = dynamicRules.find((x) => x.id === id);
      return !!r;
    });
  })(), 'patterns=' + JSON.stringify(Object.keys(info.userPatterns)) + ' userRules=' + info.network.userRules);

  console.log('\n--- 八、内置静态规则集回归 ---');

  const builtin = JSON.parse(fs.readFileSync(path.join(ROOT, 'rules/builtin-rules.json'), 'utf8'));
  check('内置规则条数正常', builtin.length >= 200, 'count=' + builtin.length);
  check('内置规则 id 唯一', new Set(builtin.map((r) => r.id)).size === builtin.length);
  check('内置规则全部合法', builtin.every((r) =>
    r.condition && (r.condition.urlFilter || r.condition.regexFilter) &&
    Array.isArray(r.condition.resourceTypes) && r.condition.resourceTypes.length > 0));

  console.log('\n=== 结果：' + pass + ' 通过 / ' + fail + ' 失败 ===\n');
  process.exit(fail ? 1 : 0);
})();
