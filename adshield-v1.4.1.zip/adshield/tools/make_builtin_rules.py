# -*- coding: utf-8 -*-
"""生成内置静态规则集 rules/builtin-rules.json

这些规则由 Chrome 在扩展启动时直接加载（静态规则集），
无需等待用户导入订阅列表即可生效。
"""
import json
import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ALL_TYPES = [
    "main_frame", "sub_frame", "stylesheet", "script", "image", "font",
    "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket", "other",
]

# 广告联盟 / 广告交易平台
AD_NETWORKS = """
doubleclick.net
googlesyndication.com
googleadservices.com
googletagservices.com
adsafeprotected.com
adnxs.com
adsrvr.org
rubiconproject.com
pubmatic.com
openx.net
criteo.com
criteo.net
casalemedia.com
smartadserver.com
adform.net
33across.com
sharethrough.com
teads.tv
outbrain.com
taboola.com
revcontent.com
mgid.com
zergnet.com
adroll.com
bidswitch.net
sovrn.com
indexexchange.com
yieldmo.com
amazon-adsystem.com
media.net
contextweb.com
gumgum.com
lijit.com
pulsepoint.com
spotxchange.com
springserve.com
moatads.com
doubleverify.com
adcolony.com
inmobi.com
mopub.com
unityads.unity3d.com
applovin.com
vungle.com
chartboost.com
adcash.com
popads.net
popcash.net
propellerads.com
propellerpops.com
onclickads.net
clickadu.com
exoclick.com
juicyads.com
hilltopads.net
adsterra.com
adspyglass.com
trafficstars.com
bidvertiser.com
adbutler.com
advertising.com
adtech.de
adition.com
ads.kontera.com
kontera.com
vibrantmedia.com
infolinks.com
adgebra.co.in
admixer.net
adotmob.com
appnexus.com
brightcom.com
emxdgt.com
freewheel.tv
impact-ad.jp
innity.com
loopme.me
nativeads.com
nativo.com
openx.com
outbrain.com
plista.com
popin.cc
quantcast.com
quantserve.com
sekindo.com
smaato.net
tremorhub.com
triplelift.com
underdog.media
undertone.com
vidazoo.com
yieldlab.net
zedo.com
""".split()

# 国内广告 / 推广 / 流量联盟
CN_ADS = """
cm.baidu.com
pos.baidu.com
union.baidu.com
cpro.baidu.com
dup.baidustatic.com
cbjs.baidu.com
hm.baidu.com
tanx.com
alimama.com
alimama.cn
mmstat.com
simba.taobao.com
adash.m.taobao.com
adashbc.m.taobao.com
ait.taobao.com
gdt.qq.com
e.qq.com
adx.360.cn
show.360.cn
union.360.cn
mkz.360.cn
adm.koudai.com
v.admaster.com.cn
admaster.com.cn
miaozhen.com
ipinyou.com
mediav.com
duomeng.cn
u8see.com
chanet.com.cn
lingshi.com
adview.cn
mobads.baidu.com
mobads-logs.baidu.com
ad.51wnl.com
m.zhwnl.cn
51.la
cnzz.com
umeng.com
umengcloud.com
talkingdata.com
talkingdata.net
growingio.com
sensorsdata.cn
ctobsnssdk.com
ad.oceanengine.com
analytics.tiktok.com
ads.tiktok.com
pangolin-sdk-toutiao.com
ad.tencent.com
pgdt.gtimg.cn
adsmind.3g.qq.com
fx.gtimg.com
insight.qq.com
""".split()

# 追踪 / 分析 / 埋点
TRACKERS = """
google-analytics.com
googletagmanager.com
analytics.google.com
scorecardresearch.com
hotjar.com
hotjar.io
mixpanel.com
segment.io
segment.com
amplitude.com
fullstory.com
mouseflow.com
crazyegg.com
clicktale.net
statcounter.com
histats.com
matomo.cloud
newrelic.com
bugsnag.com
logrocket.com
optimizely.com
vwo.com
kissmetrics.com
heap.io
heapanalytics.com
hubspot.com/analytics
analytics.tiktok.com
pixel.facebook.com
connect.facebook.net
tr.snapchat.com
sc-static.net
ads-twitter.com
static.ads-twitter.com
analytics.twitter.com
px.ads.linkedin.com
ads.linkedin.com
bat.bing.com
clarity.ms
c.clarity.ms
mc.yandex.ru
an.yandex.ru
adfox.ru
top-fwz1.mail.ru
ad.mail.ru
ads.vk.com
rb.mail.ru
criteo.net/delivery
exelator.com
bluekai.com
demdex.net
omtrdc.net
everesttech.net
adobedtm.com
krxd.net
pinterest.com/ct
ct.pinterest.com
""".split()

# 弹窗 / 恶意推广
POPUPS = """
popmyads.com
popunderjs.com
pushnami.com
pushengage.com
cleverpush.com
izooto.com
webpushr.com
subscribers.com
notix.co
ad-maven.com
admaven.com
adf.ly
shorte.st
linkvertise.com
ouo.io
bc.vc
""".split()


# 这些域名只拦截其子资源，不拦截主文档（用户可能主动访问，例如短链服务）
NO_MAIN_FRAME = {"adf.ly", "shorte.st", "linkvertise.com", "ouo.io", "bc.vc"}


def main():
    domains = []
    seen = set()
    for block in (AD_NETWORKS, CN_ADS, TRACKERS, POPUPS):
        for d in block:
            d = d.strip().lower()
            if not d or d in seen:
                continue
            seen.add(d)
            domains.append(d)

    rules = []
    rid = 1
    for d in domains:
        # 纯域名（无路径）
        if "/" not in d:
            types = ALL_TYPES if d not in NO_MAIN_FRAME else [
                t for t in ALL_TYPES if t != "main_frame"
            ]
            rules.append({
                "id": rid,
                "priority": 1,
                "action": {"type": "block"},
                "condition": {
                    "urlFilter": "||%s^" % d,
                    "resourceTypes": types,
                },
            })
            rid += 1
        else:
            # 带路径的：只拦子资源，避免误伤主文档
            host, _, path = d.partition("/")
            rules.append({
                "id": rid,
                "priority": 1,
                "action": {"type": "block"},
                "condition": {
                    "urlFilter": "||%s/%s" % (host, path),
                    "resourceTypes": [t for t in ALL_TYPES if t != "main_frame"],
                },
            })
            rid += 1

    out = os.path.join(BASE, "rules", "builtin-rules.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(rules, fh, ensure_ascii=False, separators=(",", ":"))
    print("生成 %d 条内置规则 -> %s" % (len(rules), out))


if __name__ == "__main__":
    main()
