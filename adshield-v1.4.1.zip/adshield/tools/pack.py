# -*- coding: utf-8 -*-
"""把扩展目录打包成可分发的 zip（排除开发用临时文件）"""
import io
import json
import os
import sys
import zipfile

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.dirname(BASE)

# _metadata 是 Chrome 加载未打包扩展时自己生成的索引缓存（generated_indexed_rulesets），
# 不属于扩展源码；打进去只会把一份可能过期的索引带给用户，Chrome 反正会按 manifest 重建。
SKIP_DIRS = {'__pycache__', '.tmp', '_metadata', 'node_modules', '.git', '.workbuddy'}
SKIP_FILES = {'.smoke.js', '.rt.js', '.bench.js', '.demo0.js', '.demo1.js'}
SKIP_EXT = {'.pyc'}

man = json.load(io.open(os.path.join(BASE, 'manifest.json'), encoding='utf-8'))
OUT = os.path.join(OUT_DIR, 'adshield-v%s.zip' % man['version'])

files = []
for root, dirs, names in os.walk(BASE):
    dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
    for n in names:
        if n in SKIP_FILES or os.path.splitext(n)[1] in SKIP_EXT or n.startswith('.'):
            continue
        p = os.path.join(root, n)
        files.append((p, os.path.relpath(p, OUT_DIR)))

files.sort(key=lambda x: x[1])

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p, rel in files:
        z.write(p, rel)

size = os.path.getsize(OUT)
raw = sum(os.path.getsize(p) for p, _ in files)
print('打包完成: %s' % OUT)
print('文件数: %d   压缩包: %.1f KB   原始: %.1f KB' % (len(files), size / 1024, raw / 1024))
print('压缩率: %.1f%%' % (100.0 * size / raw))
print()

bad = zipfile.ZipFile(OUT).testzip()
print('zip 完整性: %s' % ('正常' if bad is None else ('损坏 ' + str(bad))))

for p, rel in files:
    print('  %-52s %8.1f KB' % (rel.replace('\\', '/'), os.path.getsize(p) / 1024))

sys.exit(1 if bad else 0)
