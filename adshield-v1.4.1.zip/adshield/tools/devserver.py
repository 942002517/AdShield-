# -*- coding: utf-8 -*-
"""开发用静态服务器：HTTP/1.1 长连接 + 多线程 + 禁缓存。

Python 自带的 `http.server` 默认走 HTTP/1.0（每个请求关一次连接），
浏览器并发拉取多个脚本时会偶发 "Failed to fetch"。
主题预览页要顺序加载 4 个脚本 + 3 个 CSS，必须用长连接才稳。

用法：python tools/devserver.py [port] [root]
"""
import functools
import os
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer


class Handler(SimpleHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def end_headers(self):
        # 开发期一律不缓存，改了文件刷新就能看到
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def log_message(self, fmt, *args):
        pass  # 安静点，别刷屏


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8791
    root = os.path.abspath(sys.argv[2]) if len(sys.argv) > 2 else os.getcwd()
    handler = functools.partial(Handler, directory=root)
    srv = ThreadingHTTPServer(("127.0.0.1", port), handler)
    srv.daemon_threads = True
    print("serving %s on http://127.0.0.1:%d" % (root, port), flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
